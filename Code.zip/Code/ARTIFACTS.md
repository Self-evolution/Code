# Artifact inventory

This file records the release contents and integrity checks for the official CAMPE V3 artifact.

## Checkpoints

All checkpoints were copied from `/root/autodl-tmp/tmc-stdw/tmc_project_v3/checkpoints` on the RTX 4090 experiment server and verified locally against the server-side SHA-256 values.

| File | Bytes | SHA-256 |
|---|---:|---|
| `checkpoints/sac_4auv.pt` | 316,309 | `69bb4dd0963c392f397977d6263ab2e2363d8ff87743161d8e487eba4103507a` |
| `checkpoints/td3_2auv.pt` | 314,203 | `28cc9bef6d8a9b8d89e1dca4c1e380776f9ae679defb1d3d953c227e74cd7827` |
| `checkpoints/td3_3auv.pt` | 314,203 | `9d1e8addb7ddc235b7e54030c8f2f57ecd61cc8bd304b96d3a35c7b52d1c0987` |
| `checkpoints/td3_4auv.pt` | 314,203 | `e17ccf723ffbd843f74d9de280cb6d07b1886e4e5916bca09e23a6648882c1d4` |
| `checkpoints/td3_6auv.pt` | 314,203 | `df9ab3ca5360151fca079286d8326673b2393783d1eaff32c9413eafbae0a0ac` |

## Official results

The committed `results/` tree contains 230 files totaling 16,122,468 bytes:

| Type | Count | Contents |
|---|---:|---|
| CSV | 177 | Per-seed raw records, summaries, mechanism traces, and screening records |
| JSON | 17 | Run metadata, timing, analyses, audits, and validation output |
| PNG | 19 | Official and historical figures |
| LOG | 17 | Preserved screening/provenance logs |

The six official raw result tables contain exactly 1,550 episode rows:

| File | Rows | Experiment family |
|---|---:|---|
| `results/domain_shift_raw.csv` | 80 | Isolated domain-shift diagnosis |
| `results/adaptation_raw.csv` | 240 | Online adaptation comparison |
| `results/safety_ablation_raw.csv` | 330 | Architecture and safety ablation |
| `results/control_plane_raw.csv` | 300 | USV planner/control-plane comparison |
| `results/robustness_raw.csv` | 400 | Ten-scenario OOD robustness |
| `results/sensitivity_raw.csv` | 200 | Criterion, resource, and scale sensitivity |

`results/v3_validation.json` records zero protocol errors. `results/v3_analysis.json` contains the paired-seed confidence audits used by the final report.

## Release archives

| File | Bytes | SHA-256 |
|---|---:|---|
| `CAMPE_V3_FINAL_ARTIFACTS.tar.gz` | 3,584,160 | `b26e343488153d13d2d4d7d9310968cce337cf1a5fa6882341127feecf7344b4` |
| `results.zip` | 5,335,524 | `51711d0e38decaf6de38fd3a079c0acd62d2801108bc043fd4c219caef1bd50f` |

These archives are redundant convenience bundles; the browsable source, checkpoints, and result directories are the canonical Git contents.

## Verify locally

On Linux:

```bash
sha256sum checkpoints/*.pt CAMPE_V3_FINAL_ARTIFACTS.tar.gz results.zip
```

On PowerShell:

```powershell
Get-FileHash checkpoints\*.pt,CAMPE_V3_FINAL_ARTIFACTS.tar.gz,results.zip -Algorithm SHA256
```
