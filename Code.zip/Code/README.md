# CAMPE: Communication-Aware Markov Policy Evolution

Official PyTorch research artifact for communication-aware USV-assisted multi-AUV moving-target encirclement under non-stationary dynamics, intermittent acoustic links, and online policy adaptation.

CAMPE combines a frozen TD3/SAC control backbone, a safety-constrained low-parameter online adapter, and a robust geometry-aware Full MPC communication/control plane. The repository contains the implementation, five frozen checkpoints, all official per-seed results, audit outputs, figures, and the complete experiment report.

> **Scope of the SOTA statement.** “SOTA” in this repository means best performance under the registered in-project protocol with identical observations, resource budgets, models, trajectories, and random seeds. It is not a claim of ranking on an external public leaderboard.

## Highlights

- Strict capture requires small radial error, a bounded maximum angular gap, the target inside the AUV convex enclosure, safe inter-AUV separation, and a continuous stable hold window.
- Every episode has exactly one terminal outcome: `success`, `escape`, `collision`, `border`, or `timeout`.
- Loose, medium, and strict capture criteria are evaluated on the same model, seeds, and trajectories.
- The official protocol contains **1,550 episodes** across six experiment families and passes all protocol consistency checks.
- All official runs were executed on an NVIDIA RTX 4090; raw per-seed records and 95% confidence summaries are included.

## Key results

| Registered comparison | Result | Audit condition |
|---|---:|---|
| CAMPE vs. Continual TTA, OOD utility | **+0.07734 ± 0.03454** | 95% CI lower bound `+0.04280`; wins on 9/10 seeds |
| Full MPC vs. FIM, control-plane utility | **+0.06397 ± 0.01724** | 95% CI lower bound `+0.04673`; wins on 10/10 seeds |
| Full MPC vs. FIM, mission utility | **+0.04375 ± 0.03020** | 95% CI lower bound `+0.01356`; wins on 9/10 seeds |
| Full MPC vs. FIM, AoI | **50/50 paired cases improved** | Same bandwidth, mobility budget, model, and seeds |
| Protocol validation | **0 errors** | Exclusive outcomes and `loose ≥ medium ≥ strict` verified |

The complete motivation, method, experiment list, scenario-level tables, sensitivity analysis, ablations, confidence audits, and limitations are in [EXPERIMENT_REPORT_V3.md](EXPERIMENT_REPORT_V3.md).

![Capture-criterion sensitivity](results/figures_v3/capture_sensitivity.png)

## Repository layout

```text
.
├── campe/                         # Environment, policies, configuration, experiments
├── checkpoints/                   # Frozen TD3/SAC checkpoints (Git LFS)
├── results/                       # Raw CSVs, summaries, audits, timing, and figures
│   ├── figures_v3/                # Official V3 figures
│   └── screening/                 # Architecture/planner candidate-screening records
├── run_sharded_v2.py              # Deterministic parallel official protocol runner
├── run_stage_v2.py                # Single-stage runner
├── validate_v2.py                 # Protocol and raw-result validation
├── analyze_v2.py                  # Paired-seed analysis and audit metrics
├── generate_report_v2.py          # Rebuild figures and the V3 report
├── EXPERIMENT_REPORT_V3.md         # Complete scientific report
├── ARTIFACTS.md                   # Inventory and SHA-256 checksums
└── requirements.txt               # Runtime dependencies
```

Legacy reports and screening scripts are retained for provenance and to make the architecture-selection process auditable.

## Installation

Clone with Git LFS enabled so the frozen checkpoints and release archives are downloaded correctly.

```bash
git lfs install
git clone https://github.com/Dramwig/campe-usv-auv-encirclement.git
cd campe-usv-auv-encirclement
git lfs pull

python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

The official server environment used Python 3, PyTorch `2.12.1+cu130`, CUDA `13.0`, and an NVIDIA GeForce RTX 4090. The implementation is not tied to a particular CUDA build, but reproducing the reported timings requires a comparable GPU.

## Quick verification

Validate the committed raw results and run a deterministic smoke episode:

```bash
python validate_v2.py --root .
python validate_v2.py --root . --smoke --seeds 0
```

The full validation should report zero outcome-exclusivity, capture-monotonicity, row-count, and metadata errors.

## Reproduce the official protocol

The commands below regenerate all six registered experiment families. They are intended for a CUDA server; run them from a data-disk checkout if system-disk space is constrained.

```bash
python run_sharded_v2.py \
  --root . \
  --mode full \
  --shards-per-stage 10 \
  --max-parallel 16 \
  --archive-results

python validate_v2.py --root .
python analyze_v2.py --root . --output results/v3_analysis.json
python generate_report_v2.py --root .
```

To run only selected experiment families, pass one or more stages:

```bash
python run_sharded_v2.py --root . --mode full --stages adaptation robustness
```

Available stages are `domain_shift`, `adaptation`, `safety_ablation`, `control_plane`, `robustness`, and `sensitivity`. The full run uses seeds 0–9 for the main experiments and seeds 0–4 for sensitivity experiments.

## Registered experiment matrix

| Task | Purpose | Episodes |
|---|---|---:|
| 1 | Frozen source policy under isolated domain shifts | 80 |
| 2 | Six adaptation methods under gradual, sudden, joint, and recurrent shifts | 240 |
| 3 | Full CAMPE and ten targeted architecture ablations | 330 |
| 4 | Six USV planners under communication/control stress | 300 |
| 5 | Four methods across ten OOD scenarios | 400 |
| 6 | Capture, architecture, resource, and scalability sensitivity | 200 |

## Capture protocol

For AUV-to-target ranges `r_i(t)` and desired radius `R`, capture uses the mean radial error, the largest adjacent angular gap around the target, target containment, collision clearance, and persistent stability. A single favorable time step is never counted as success.

| Criterion | Radial error | Maximum angular gap | Continuous hold | Final stable fraction | Final score |
|---|---:|---:|---:|---:|---:|
| Loose | 4.55 m | 1.56 × ideal | 5.0 s | 0.55 | 0.57 |
| Medium | 3.50 m | 1.40 × ideal | 10.0 s | 0.70 | 0.65 |
| Strict | 2.52 m | 1.22 × ideal | 15.0 s | 0.84 | 0.73 |

Collision, border violation, or escape invalidates capture. Otherwise, an episode that never establishes the required persistent capture state is a timeout.

## Artifact integrity

All five checkpoints downloaded from the experiment server were verified byte-for-byte using SHA-256. Exact hashes, sizes, result counts, and archive hashes are recorded in [ARTIFACTS.md](ARTIFACTS.md). Git LFS is used for `*.pt`, `*.zip`, and `*.tar.gz` artifacts.

## Repository design references

The release layout follows conventions used by comparable research repositories: [MarineGym](https://github.com/Marine-RL/MarineGym) for installation/quick-start/citation-oriented navigation, [MAPPO](https://github.com/marlbenchmark/on-policy) for explicit training commands and hyperparameter reproducibility, and [Tent](https://github.com/DequanWang/tent) for compact test-time-adaptation examples and result reporting.

## Citation and license

Publication metadata has not yet been finalized. Until a paper citation is available, cite the repository URL and the exact Git commit used for an experiment.

No open-source license has been assigned to this private research release. Copyright remains with the project authors; access to the repository does not grant redistribution rights.
