from __future__ import annotations

from dataclasses import asdict, replace
from pathlib import Path
import copy
import math
import time
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch

from .config import (
    ABLATIONS,
    METHODS,
    OOD_SCENARIOS,
    PLANNERS,
    DomainConfig,
    SimConfig,
    ideal_gap,
    scenario_at,
)
from .environment import PursuitEnv
from .policy import AdaptiveController, train_backbone


def checkpoint_path(root: Path, backbone: str, n_auv: int) -> Path:
    return root / "checkpoints" / f"{backbone}_{n_auv}auv.pt"


def ensure_backbone(
    root: Path,
    cfg: SimConfig,
    backbone: str,
    samples: int,
    epochs: int,
    force: bool = False,
) -> Dict[str, float]:
    path = checkpoint_path(root, backbone, cfg.n_auv)
    if path.exists() and not force:
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if int(payload.get("samples", 0)) >= samples and int(payload.get("epochs", 0)) >= epochs:
            return {
                "val_mse": float(payload.get("val_mse", float("nan"))),
                "val_mae": float(payload.get("val_mae", float("nan"))),
                "train_seconds": 0.0,
                "parameters": float(sum(v.numel() for v in payload["state_dict"].values())),
            }
    return train_backbone(path, cfg, backbone, samples=samples, epochs=epochs)


def _initial_info(env: PursuitEnv) -> Dict[str, float]:
    geom = env._geometry()
    return {
        **geom,
        "risk": env._escape_risk(geom),
        "aoi": 0.0,
        "per": 0.02,
        "control_ratio": env.control_ratio,
    }


def _domain_for(name: str, step: int, total: int, strength: float) -> DomainConfig:
    if name == "mobile_shadow":
        domain = scenario_at("joint", step, total, 1.15 * strength)
        return replace(
            domain,
            channel_shadow=max(0.72 * strength, domain.channel_shadow),
            packet_loss=max(0.16 * strength, domain.packet_loss),
            target_speed=max(1.65, domain.target_speed),
            target_evasion=max(0.78, domain.target_evasion),
        )
    if name == "relay_intercept":
        domain = scenario_at("joint", step, total, 1.35 * strength)
        return replace(
            domain,
            target_speed=max(2.30, domain.target_speed),
            target_evasion=max(0.82, domain.target_evasion),
            target_deception=max(0.24, domain.target_deception),
            channel_shadow=max(0.82, domain.channel_shadow),
            packet_loss=max(0.16, domain.packet_loss),
            current_shear=max(0.26, domain.current_shear),
        )
    if name in OOD_SCENARIOS:
        base_name, base_strength = OOD_SCENARIOS[name]
        domain = scenario_at(base_name, step, total, strength * base_strength)
        if name == "direction_switch" and step >= total // 2:
            domain = replace(domain, current_x=-1.15 * domain.current_x, current_y=-1.15 * domain.current_y)
        if name == "random_target":
            domain = replace(domain, target_deception=0.58 * strength)
        if name == "deceptive_target":
            domain = replace(domain, target_deception=0.90 * strength, target_evasion=min(1.35, domain.target_evasion))
        if name == "long_burst_loss":
            domain = replace(domain, burst_loss=min(0.92, domain.burst_loss + 0.22))
        if name == "severe_thruster":
            domain = replace(domain, thruster_health=max(0.38, domain.thruster_health - 0.10))
        if name == "adversarial_mix":
            domain = replace(
                domain,
                target_speed=min(2.55, max(2.20, domain.target_speed)),
                target_evasion=min(1.30, max(1.05, domain.target_evasion)),
                target_deception=max(0.68 * strength, domain.target_deception),
                channel_shadow=max(0.48 * strength, domain.channel_shadow),
                current_shear=max(0.34 * strength, domain.current_shear),
            )
        if name == "blackout_chase":
            domain = replace(
                domain,
                target_speed=max(1.85, domain.target_speed),
                target_evasion=max(0.82, domain.target_evasion),
                target_deception=max(0.30, domain.target_deception),
                packet_loss=max(0.32, domain.packet_loss),
                burst_loss=max(0.82, domain.burst_loss),
                channel_shadow=max(0.68, domain.channel_shadow),
            )
        return domain
    return scenario_at(name, step, total, strength)


def _recovery_time(scores: Sequence[float], scenario: str, dt: float) -> float:
    if scenario == "source":
        shift = 0
    elif scenario == "gradual":
        shift = int(0.18 * len(scores))
    elif scenario == "sudden":
        shift = int(0.35 * len(scores))
    else:
        shift = int(0.20 * len(scores))
    hold = 10
    degrade = next((i for i in range(shift, len(scores)) if scores[i] < 0.68), None)
    if degrade is None:
        return 0.0
    for i in range(degrade, max(degrade, len(scores) - hold + 1)):
        if np.mean(scores[i:i + hold]) >= 0.76:
            return float((i - degrade) * dt)
    return float((len(scores) - degrade) * dt)


def _shift_index(scenario: str, length: int) -> int:
    if scenario == "gradual":
        return int(0.70 * length)
    if scenario == "sudden":
        return int(0.35 * length)
    if scenario == "joint":
        return int(0.66 * length)
    if scenario in {"recurrent", "recurrent_shift"}:
        return int(0.60 * length)
    return 0


def _capture_profiles(env: PursuitEnv, scenario: str) -> Dict[str, object]:
    gaps = np.asarray(env.gap_history)
    radii = np.asarray(env.radius_history)
    min_pair = np.asarray(env.min_pair_history)
    inside = np.asarray(env.inside_history) > 0.5
    scores = np.asarray(env.score_history)
    shift = _shift_index(scenario, len(gaps))
    cfg = env.cfg
    specs = {
        "loose": {
            "radial": 1.30 * cfg.radial_tolerance,
            "gap": max(1.52, cfg.capture_gap_multiplier + 0.16),
            "hold": max(8, int(round(0.50 * cfg.capture_hold))),
            "fraction": 0.55,
            "score": max(0.56, cfg.capture_score_threshold - 0.08),
        },
        "medium": {
            "radial": cfg.radial_tolerance,
            "gap": cfg.capture_gap_multiplier,
            "hold": cfg.capture_hold,
            "fraction": cfg.capture_required_fraction,
            "score": cfg.capture_score_threshold,
        },
        "strict": {
            "radial": 0.72 * cfg.radial_tolerance,
            "gap": max(1.16, cfg.capture_gap_multiplier - 0.18),
            "hold": max(cfg.capture_hold + 8, int(round(1.50 * cfg.capture_hold))),
            "fraction": min(0.88, cfg.capture_required_fraction + 0.14),
            "score": min(0.82, cfg.capture_score_threshold + 0.08),
        },
    }
    result: Dict[str, object] = {}
    final_window = min(cfg.capture_final_window, len(gaps))
    safety_failure = env.collision_events > 0 or env.border_events > 0 or env.escaped
    for profile, spec in specs.items():
        stable = (
            (gaps <= float(spec["gap"]) * ideal_gap(cfg.n_auv)) &
            (radii <= float(spec["radial"])) &
            (min_pair >= cfg.collision_distance) &
            inside
        )
        hold = int(spec["hold"])
        first = None
        for i in range(shift, max(shift, len(stable) - hold + 1)):
            if bool(np.all(stable[i:i + hold])):
                first = i
                break
        final_fraction = float(np.mean(stable[-final_window:]))
        final_score = float(np.mean(scores[-final_window:]))
        success = bool(
            first is not None and
            final_fraction >= float(spec["fraction"]) and
            final_score >= float(spec["score"]) and
            not safety_failure
        )
        if env.collision_events > 0:
            outcome = "collision"
        elif env.border_events > 0:
            outcome = "border"
        elif env.escaped:
            outcome = "escape"
        elif success:
            outcome = "success"
        else:
            outcome = "timeout"
        suffix = f"_{profile}"
        result[f"capture_success{suffix}"] = float(success)
        result[f"capture_time{suffix}"] = (
            # Capture is certified only when the entire continuous window has
            # elapsed, not at the first step of that window.
            float((first + hold - 1 - shift) * cfg.dt)
            if success and first is not None
            else float((len(stable) - shift) * cfg.dt)
        )
        result[f"capture_stability{suffix}"] = final_fraction
        result[f"capture_final_score{suffix}"] = final_score
        result[f"mission_outcome{suffix}"] = outcome
        for label in ("success", "escape", "collision", "border", "timeout"):
            result[f"outcome_{label}{suffix}"] = float(outcome == label)
    result["capture_success"] = result["capture_success_medium"]
    result["capture_time"] = result["capture_time_medium"]
    result["mission_outcome"] = result["mission_outcome_medium"]
    for label in ("success", "escape", "collision", "border", "timeout"):
        result[f"outcome_{label}"] = result[f"outcome_{label}_medium"]
    return result


def run_episode(
    root: Path,
    cfg: SimConfig,
    method: str,
    scenario: str,
    seed: int,
    planner: str = "full_mpc",
    ablation: str = "full",
    backbone: str = "td3",
    strength: float = 1.0,
    retain_controller: bool = False,
) -> Tuple[Dict[str, float], Optional[AdaptiveController]]:
    env = PursuitEnv(cfg, seed=seed)
    obs = env.reset()
    info = _initial_info(env)
    controller = AdaptiveController(
        cfg=cfg,
        method=method,
        checkpoint=checkpoint_path(root, backbone, cfg.n_auv),
        seed=seed,
        ablation=ablation,
    )
    wall_start = time.perf_counter()
    while env.step_id < cfg.max_steps:
        domain = _domain_for(scenario, env.step_id, cfg.max_steps, strength)
        action = controller.act(obs, info)
        next_obs, _, done, next_info = env.step(
            action,
            domain,
            planner=planner,
            drift=controller.drift_score,
            learning_active=controller.learning_active,
        )
        controller.feedback(obs, next_obs, action, next_info)
        obs, info = next_obs, next_info
        if done:
            break
    metrics = env.summary()
    metrics.update(_capture_profiles(env, scenario))
    metrics.update(controller.summary())
    metrics.update({
        "method": method,
        "scenario": scenario,
        "seed": seed,
        "planner": planner,
        "ablation": ablation,
        "backbone": backbone,
        "n_auv": cfg.n_auv,
        "strength": strength,
        "recovery_time": _recovery_time(env.score_history, scenario, cfg.dt),
        "wall_time": time.perf_counter() - wall_start,
        "gpu": str(torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"),
        "prediction_horizon": cfg.prediction_horizon,
        "environment_window": cfg.window,
        "anchor_threshold": cfg.anchor_threshold,
        "usv_speed_budget": cfg.usv_max_speed,
        "usv_movement_budget": cfg.usv_movement_budget,
        "bandwidth": cfg.total_bandwidth,
    })
    return metrics, controller if retain_controller else None


def evaluate_retention(
    root: Path,
    cfg: SimConfig,
    controller: AdaptiveController,
    seed: int,
    backbone: str,
    reference_score: float,
    allow_recovery: bool = False,
) -> Dict[str, float]:
    env = PursuitEnv(cfg, seed=seed + 10_000)
    obs = env.reset()
    info = _initial_info(env)
    adapted = controller.copy_for_source_retention()
    for _ in range(min(cfg.max_steps, 160)):
        action = adapted.act(obs, info)
        next_obs, _, done, next_info = env.step(
            action,
            DomainConfig(),
            planner="full_mpc",
            drift=adapted.drift_score,
            learning_active=adapted.learning_active,
        )
        if allow_recovery:
            adapted.feedback(obs, next_obs, action, next_info)
        obs, info = next_obs, next_info
        if done:
            break
    retained = float(np.mean(env.score_history[-30:] or [0.0]))
    return {
        "retained_source_performance": retained,
        "old_domain_forgetting": max(0.0, reference_score - retained),
    }


def aggregate(rows: pd.DataFrame, group_columns: Sequence[str]) -> pd.DataFrame:
    numeric = [c for c in rows.columns if pd.api.types.is_numeric_dtype(rows[c]) and c != "seed"]
    grouped = rows.groupby(list(group_columns), dropna=False)
    records: List[Dict[str, float]] = []
    for keys, frame in grouped:
        keys = keys if isinstance(keys, tuple) else (keys,)
        record = dict(zip(group_columns, keys))
        n = len(frame)
        record["n"] = n
        for column in numeric:
            values = frame[column].dropna().astype(float)
            if len(values) == 0:
                continue
            record[f"{column}_mean"] = float(values.mean())
            record[f"{column}_std"] = float(values.std(ddof=1)) if len(values) > 1 else 0.0
            record[f"{column}_ci95"] = float(1.96 * values.std(ddof=1) / math.sqrt(len(values))) if len(values) > 1 else 0.0
        records.append(record)
    return pd.DataFrame.from_records(records)


def _write_stage(root: Path, stage: str, rows: List[Dict[str, float]], groups: Sequence[str]) -> pd.DataFrame:
    raw = pd.DataFrame.from_records(rows)
    result_dir = root / "results"
    result_dir.mkdir(parents=True, exist_ok=True)
    raw.to_csv(result_dir / f"{stage}_raw.csv", index=False)
    stats = aggregate(raw, groups)
    stats.to_csv(result_dir / f"{stage}_summary.csv", index=False)
    return raw


def run_domain_shift(root: Path, cfg: SimConfig, seeds: Sequence[int]) -> pd.DataFrame:
    rows = []
    for scenario in ("source", "current", "target_evasion", "burst_loss", "channel_shadow",
                     "localization", "dynamics", "thruster"):
        for seed in seeds:
            row, _ = run_episode(root, cfg, "source_only", scenario, seed, planner="fim_mobility")
            rows.append(row)
    return _write_stage(root, "domain_shift", rows, ["scenario", "method"])


def run_adaptation(root: Path, cfg: SimConfig, seeds: Sequence[int]) -> pd.DataFrame:
    rows = []
    reference = {}
    for seed in seeds:
        ref, _ = run_episode(root, cfg, "source_only", "source", seed + 30_000, planner="full_mpc")
        reference[seed] = ref["final_performance"]
    for scenario in ("gradual", "sudden", "joint", "recurrent"):
        for method in METHODS:
            for seed in seeds:
                row, controller = run_episode(root, cfg, method, scenario, seed, retain_controller=True)
                retention = evaluate_retention(root, cfg, controller, seed, "td3", reference[seed])
                row.update(retention)
                rows.append(row)
    return _write_stage(root, "adaptation", rows, ["scenario", "method"])


def run_safety_ablation(root: Path, cfg: SimConfig, seeds: Sequence[int]) -> pd.DataFrame:
    rows = []
    stress_cfg = replace(
        cfg,
        n_auv=6,
        desired_radius=10.5,
        radial_tolerance=2.8,
        capture_gap_multiplier=1.28,
        capture_hold=24,
        capture_required_fraction=0.78,
        initial_angle_jitter=0.78,
        initial_radius_offset=8.0,
        initial_radius_std=6.0,
        safety_distance=9.0,
        collision_distance=6.0,
    )
    references = {}
    for seed in seeds:
        reference, _ = run_episode(root, stress_cfg, "source_only", "source", seed + 40_000, planner="full_mpc")
        references[seed] = reference["final_performance"]
    for ablation in ABLATIONS:
        mapped = "full" if ablation == "full" else ablation
        for scenario in ("adversarial_mix", "blackout_chase", "recurrent_shift"):
            for seed in seeds:
                row, controller = run_episode(
                    root,
                    stress_cfg,
                    "campe",
                    scenario,
                    seed,
                    ablation=mapped,
                    retain_controller=True,
                )
                row.update(evaluate_retention(root, stress_cfg, controller, seed, "td3", references[seed]))
                rows.append(row)
    return _write_stage(root, "safety_ablation", rows, ["ablation"])


def run_control_plane(root: Path, cfg: SimConfig, seeds: Sequence[int]) -> pd.DataFrame:
    rows = []
    for planner in PLANNERS:
        for scenario in (
            "mobile_shadow",
            "adversarial_mix",
            "relay_intercept",
            "blackout_chase",
            "direction_switch",
        ):
            for seed in seeds:
                row, _ = run_episode(root, cfg, "campe", scenario, seed, planner=planner)
                rows.append(row)
    return _write_stage(root, "control_plane", rows, ["planner"])


def run_robustness(root: Path, cfg: SimConfig, seeds: Sequence[int]) -> pd.DataFrame:
    rows = []
    for scenario in OOD_SCENARIOS:
        for method in ("source_only", "domain_randomization", "ctta", "campe"):
            for seed in seeds:
                row, _ = run_episode(root, cfg, method, scenario, seed)
                rows.append(row)
    return _write_stage(root, "robustness", rows, ["scenario", "method"])


def run_sensitivity(root: Path, base_cfg: SimConfig, seeds: Sequence[int]) -> pd.DataFrame:
    rows: List[Dict[str, float]] = []
    settings = []
    for value in (1, 2, 4, 6, 8):
        settings.append(("prediction_horizon", value, replace(base_cfg, prediction_horizon=value), "td3", "adversarial_mix"))
    for value in (8, 12, 20, 32, 48):
        settings.append(("environment_window", value, replace(base_cfg, window=value), "td3", "adversarial_mix"))
    for value in (0.12, 0.25, 0.40, 0.60, 0.80):
        settings.append(("anchor_threshold", value, replace(base_cfg, anchor_threshold=value), "td3", "recurrent_shift"))
    for value in (0.4, 0.8, 1.5, 2.5, 4.0):
        settings.append(("usv_speed_limit", value, replace(base_cfg, usv_max_speed=value), "td3", "mobile_shadow"))
    for value in (20.0, 40.0, 70.0, 100.0, 140.0):
        settings.append(("usv_movement_budget", value, replace(base_cfg, usv_movement_budget=value), "td3", "mobile_shadow"))
    for value in (2_500.0, 4_500.0, 7_000.0, 9_000.0, 14_000.0, 22_000.0):
        settings.append(("bandwidth", value, replace(base_cfg, total_bandwidth=value), "td3", "blackout_chase"))
    for n_auv in (2, 3, 4, 6):
        settings.append(("n_auv", n_auv, replace(base_cfg, n_auv=n_auv), "td3", "adversarial_mix"))
    for backbone in ("td3", "sac"):
        settings.append(("backbone", backbone, base_cfg, backbone, "adversarial_mix"))

    # The three capture standards are evaluated on exact copies of the same
    # trajectories, models and seeds; no rerun or seed resampling is involved.
    capture_cache: Dict[int, Dict[str, object]] = {}
    for seed in seeds:
        # mobile_shadow is difficult enough to separate the three criteria but
        # still admits successful trajectories. adversarial_mix is retained as
        # the harder OOD upper-end stress test, where all profiles may fail.
        row, _ = run_episode(root, base_cfg, "campe", "mobile_shadow", seed)
        capture_cache[seed] = row
    for profile in ("loose", "medium", "strict"):
        for seed in seeds:
            row = copy.deepcopy(capture_cache[seed])
            row["capture_success"] = row[f"capture_success_{profile}"]
            row["capture_time"] = row[f"capture_time_{profile}"]
            row["mission_outcome"] = row[f"mission_outcome_{profile}"]
            for label in ("success", "escape", "collision", "border", "timeout"):
                row[f"outcome_{label}"] = row[f"outcome_{label}_{profile}"]
            row["sensitivity_parameter"] = "capture_criterion"
            row["sensitivity_value"] = profile
            rows.append(row)

    for parameter, value, cfg, backbone, scenario in settings:
        for seed in seeds:
            row, _ = run_episode(root, cfg, "campe", scenario, seed, backbone=backbone)
            row["sensitivity_parameter"] = parameter
            row["sensitivity_value"] = value
            rows.append(row)
    return _write_stage(root, "sensitivity", rows, ["sensitivity_parameter", "sensitivity_value"])
