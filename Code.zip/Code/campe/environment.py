from __future__ import annotations

import copy
import math
from typing import Dict, Optional, Tuple

import numpy as np

from .config import DomainConfig, SimConfig, ideal_gap


def _unit(x: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    return x / np.maximum(np.linalg.norm(x, axis=-1, keepdims=True), eps)


def _clip_norm(x: np.ndarray, max_norm: float) -> np.ndarray:
    norm = np.linalg.norm(x, axis=-1, keepdims=True)
    return x * np.minimum(1.0, max_norm / np.maximum(norm, 1e-8))


class PursuitEnv:
    """Communication-constrained USV-AUV target encirclement simulator.

    The controller receives noisy local motion and an acoustic-link cache. Latent
    current, actuator health, target mode, packet process, and sensing bias are
    intentionally hidden so that adaptation is a Markov-domain problem rather
    than a supervised domain label problem.
    """

    def __init__(self, cfg: SimConfig, seed: int = 0):
        self.cfg = cfg
        self.seed = seed
        self.reset()

    def reset(self) -> Dict[str, np.ndarray]:
        c = self.cfg
        streams = np.random.SeedSequence(self.seed).spawn(4)
        self.rng = np.random.default_rng(streams[0])
        channel_rng = np.random.default_rng(streams[1])
        sensor_rng = np.random.default_rng(streams[2])
        local_rng = np.random.default_rng(streams[3])
        # Counter-indexed common random numbers: changing retransmission counts
        # cannot shift later channel or sensor draws in paired planner runs.
        self.channel_draws = channel_rng.random(
            (c.max_steps + 1, c.n_auv, c.max_retransmissions, 2)
        )
        self.sensor_fault_draws = sensor_rng.random((c.max_steps + 1, c.n_auv))
        self.sensor_auv_noise = sensor_rng.normal(
            0.0, 1.0, (c.max_steps + 1, c.n_auv, 2)
        )
        self.sensor_target_noise = sensor_rng.normal(
            0.0, 1.0, (c.max_steps + 1, c.n_auv, 2)
        )
        self.sensor_aoi_jitter = sensor_rng.uniform(
            0.0, 0.333, (c.max_steps + 1, c.n_auv)
        )
        self.local_observation_noise = local_rng.normal(
            0.0, 1.0, (c.max_steps + 2, c.n_auv, 2)
        )
        self.step_id = 0
        self.target_pos = np.array([0.50, 0.50]) * c.arena_size
        target_angle = self.rng.uniform(-math.pi, math.pi)
        self.target_vel = np.array([math.cos(target_angle), math.sin(target_angle)])
        self.target_vel *= c.initial_target_speed
        angles = np.linspace(0.0, 2.0 * math.pi, c.n_auv, endpoint=False)
        angles += self.rng.normal(0.0, c.initial_angle_jitter, c.n_auv)
        radii = c.desired_radius + c.initial_radius_offset + self.rng.normal(0.0, c.initial_radius_std, c.n_auv)
        radii = np.clip(radii, c.desired_radius * 0.55, c.desired_radius * 2.35)
        self.auv_pos = self.target_pos + np.stack([np.cos(angles), np.sin(angles)], 1) * radii[:, None]
        # Reject geometrically invalid starts. A collision recorded before the
        # controller has had one action would measure initialization failure,
        # not safety-control quality, and would confound the episode outcome.
        initial_separation = c.collision_distance + 1.0
        for _ in range(32):
            pair = self.auv_pos[:, None, :] - self.auv_pos[None, :, :]
            distance = np.linalg.norm(
                pair + np.eye(c.n_auv)[:, :, None] * 1e6,
                axis=2,
            )
            close = np.argwhere(np.triu(distance < initial_separation, 1))
            if len(close) == 0:
                break
            for i, j in close:
                direction = _unit((self.auv_pos[i] - self.auv_pos[j])[None, :])[0]
                if np.linalg.norm(direction) < 1e-6:
                    direction = np.array([1.0, 0.0])
                correction = 0.55 * (initial_separation - distance[i, j] + 0.05) * direction
                self.auv_pos[i] += correction
                self.auv_pos[j] -= correction
            rel = self.auv_pos - self.target_pos
            repaired_radius = np.clip(
                np.linalg.norm(rel, axis=1),
                c.desired_radius * 0.55,
                c.desired_radius * 2.35,
            )
            self.auv_pos = self.target_pos + _unit(rel) * repaired_radius[:, None]
        self.auv_vel = np.zeros((c.n_auv, 2), dtype=np.float64)
        self.prev_cmd = np.zeros_like(self.auv_vel)
        heading = _unit(self.target_vel[None, :])[0]
        self.usv_pos = self.target_pos - 30.0 * heading + 6.0 * np.array([-heading[1], heading[0]])
        self.cached_auv = self.auv_pos.copy()
        self.cached_auv_vel = np.zeros_like(self.auv_pos)
        self.cached_target = self.target_pos.copy()
        self.prev_cached_target = self.cached_target.copy()
        self.cached_target_vel = self.target_vel.copy()
        self.last_target_measurement = self.cached_target.copy()
        self.target_measurement_age = 0
        self.aoi = np.zeros(c.n_auv, dtype=np.float64)
        self.per_ema = np.full(c.n_auv, 0.02, dtype=np.float64)
        self.burst_state = np.zeros(c.n_auv, dtype=bool)
        self.control_ratio = 0.70
        self.usv_period = c.usv_update_period
        self.last_usv_plan = -10_000
        self.usv_waypoint = self.usv_pos.copy()
        self.active_planner = "fixed"
        self.planner_target_speed_history = []
        self.usv_period_history = []
        self.full_mpc_fallback_active = False
        self.full_mpc_fallback_history = []
        self.full_mpc_residual_history = []
        self.full_mpc_terminal_link_history = []
        self.full_mpc_priority_extra_history = []
        self.capture_streak = 0
        self.captured = False
        self.escaped = False
        self.collision_events = 0
        self.border_events = 0
        self.energy = 0.0
        self.usv_distance = 0.0
        self.control_bytes = 0.0
        self.learning_bytes = 0.0
        self.packet_attempts = 0
        self.packet_losses = 0
        self.last_control_bytes_step = 0.0
        self.fim_history = []
        self.score_history = []
        self.gap_history = []
        self.radius_history = []
        self.min_pair_history = []
        self.inside_history = []
        self.aoi_history = []
        self.per_history = []
        self.control_ratio_history = []
        self.usv_history = [self.usv_pos.copy()]
        self.target_history = [self.target_pos.copy()]
        self.auv_history = [self.auv_pos.copy()]
        self.domain_history = []
        return self.observe(DomainConfig())

    def clone(self) -> "PursuitEnv":
        return copy.deepcopy(self)

    def _current(self, domain: DomainConfig) -> np.ndarray:
        t = self.step_id * self.cfg.dt
        theta = domain.current_turn_rate * t
        base = np.array([domain.current_x, domain.current_y])
        rot = np.array([[math.cos(theta), -math.sin(theta)], [math.sin(theta), math.cos(theta)]])
        gust = domain.current_gust * np.array([
            math.sin(0.075 * t + 0.4),
            math.cos(0.061 * t - 0.7),
        ])
        spatial = 0.10 * domain.current_gust * np.stack([
            np.sin(self.auv_pos[:, 1] / 19.0 + 0.03 * t),
            np.cos(self.auv_pos[:, 0] / 23.0 - 0.025 * t),
        ], axis=1)
        shear = domain.current_shear * np.stack([
            (self.auv_pos[:, 1] - 0.5 * self.cfg.arena_size) / self.cfg.arena_size,
            -(self.auv_pos[:, 0] - 0.5 * self.cfg.arena_size) / self.cfg.arena_size,
        ], axis=1)
        return (rot @ base) + gust + spatial + shear

    def _geometry(self) -> Dict[str, float]:
        rel = self.auv_pos - self.target_pos
        radii = np.linalg.norm(rel, axis=1)
        angles = np.mod(np.arctan2(rel[:, 1], rel[:, 0]), 2.0 * math.pi)
        ordered = np.sort(angles)
        gaps = np.diff(np.r_[ordered, ordered[0] + 2.0 * math.pi])
        max_gap = float(np.max(gaps))
        radius_error = float(np.mean(np.abs(radii - self.cfg.desired_radius)))
        radial_score = math.exp(-radius_error / max(self.cfg.radial_tolerance, 1e-6))
        gap_excess = max(0.0, max_gap / ideal_gap(self.cfg.n_auv) - 1.0)
        gap_score = math.exp(-1.35 * gap_excess)
        pairwise = self.auv_pos[:, None, :] - self.auv_pos[None, :, :]
        dist = np.linalg.norm(pairwise + np.eye(self.cfg.n_auv)[:, :, None] * 1e6, axis=2)
        min_pair = float(np.min(dist))
        safety_score = min(1.0, min_pair / self.cfg.safety_distance)
        score = float(0.48 * radial_score + 0.42 * gap_score + 0.10 * safety_score)
        stable_gap = max_gap <= self.cfg.capture_gap_multiplier * ideal_gap(self.cfg.n_auv)
        stable_radius = radius_error <= self.cfg.radial_tolerance
        # The target is inside the AUV convex hull iff the bearing vectors are
        # not contained in any open semicircle.  This angular test is exact for
        # a point at the origin of the relative-coordinate system.
        target_inside = bool(max_gap <= math.pi + 1e-8)
        return {
            "max_gap": max_gap,
            "radius_error": radius_error,
            "min_pair": min_pair,
            "score": score,
            "target_inside": float(target_inside),
            "stable": float(stable_gap and stable_radius and target_inside and
                            min_pair >= self.cfg.collision_distance),
        }

    def _fim(self, usv: Optional[np.ndarray] = None, auv: Optional[np.ndarray] = None) -> float:
        usv = self.usv_pos if usv is None else np.asarray(usv)
        auv = self.auv_pos if auv is None else np.asarray(auv)
        vec = auv - usv
        dist = np.linalg.norm(vec, axis=1) + 8.0
        unit = vec / dist[:, None]
        fim = np.eye(2) * 1e-5
        for i in range(len(auv)):
            fim += np.outer(unit[i], unit[i]) / (0.18 + 0.0025 * dist[i] ** 2)
        sign, logdet = np.linalg.slogdet(fim)
        return float(logdet if sign > 0 else -30.0)

    def _escape_risk(self, geom: Dict[str, float]) -> float:
        centroid_offset = np.linalg.norm(self.target_pos - np.mean(self.auv_pos, axis=0))
        gap_risk = np.clip(geom["max_gap"] / (1.8 * ideal_gap(self.cfg.n_auv)), 0.0, 1.5)
        radial_risk = np.clip(geom["radius_error"] / (2.0 * self.cfg.radial_tolerance), 0.0, 1.5)
        return float(np.clip(0.45 * gap_risk + 0.35 * radial_risk + 0.20 * centroid_offset / 18.0, 0.0, 1.5))

    def _prospective_link_quality(self, usv: np.ndarray, auv: np.ndarray) -> np.ndarray:
        """Predict successful delivery probability from observable link state.

        The predictor mirrors the packet process used by :meth:`_communicate`.
        In particular, the current PER is used only to infer unmodelled shadow
        strength; it is not subtracted a second time from every candidate link.
        """

        c = self.cfg
        distance = np.linalg.norm(auv - usv[None, :], axis=1)
        distance_loss = np.clip((distance / c.acoustic_range) ** 2, 0.0, 0.62)
        observed_loss = float(np.mean(self.per_ema))
        midpoint = 0.5 * (auv + usv[None, :])
        shadow_centers = np.array([[68.0, 118.0], [138.0, 76.0]])
        shadow_distance = np.linalg.norm(midpoint[:, None, :] - shadow_centers[None, :, :], axis=2)
        shadow = np.max(np.exp(-0.5 * (shadow_distance / 24.0) ** 2), axis=1)
        temporal_fade = 0.5 + 0.5 * math.sin(0.11 * self.step_id + 0.4 * self.seed)
        current_distance = np.linalg.norm(self.cached_auv - self.usv_pos[None, :], axis=1)
        current_acoustic = np.clip((current_distance / c.acoustic_range) ** 2, 0.0, 0.62)
        current_midpoint = 0.5 * (self.cached_auv + self.usv_pos[None, :])
        current_shadow_distance = np.linalg.norm(
            current_midpoint[:, None, :] - shadow_centers[None, :, :], axis=2
        )
        current_shadow = np.max(
            np.exp(-0.5 * (current_shadow_distance / 24.0) ** 2), axis=1
        )
        unexplained_loss = max(0.0, observed_loss - 0.03 - 0.72 * float(np.mean(current_acoustic)))
        exposure = max(0.12, temporal_fade * float(np.mean(current_shadow)))
        inferred_shadow_strength = float(np.clip(unexplained_loss / exposure, 0.0, 0.90))
        predicted_per = np.clip(
            0.03 + distance_loss + inferred_shadow_strength * shadow * temporal_fade,
            0.0,
            0.96,
        )
        packet_capacity = int(
            (c.total_bandwidth * c.dt * self.control_ratio) /
            max(c.control_packet_bytes, 1.0)
        )
        attempts = min(c.max_retransmissions, packet_capacity // max(c.n_auv, 1))
        if attempts <= 0:
            return np.zeros_like(predicted_per)
        return np.clip(1.0 - predicted_per ** attempts, 0.0, 1.0)

    def _advance_usv(
        self,
        desired_usv: np.ndarray,
        *,
        budget_paced: bool = False,
        urgency: float = 0.0,
    ) -> None:
        c = self.cfg
        remaining_budget = max(0.0, c.usv_movement_budget - self.usv_distance)
        delta_limit = min(c.usv_max_speed * c.dt, remaining_budget)
        if budget_paced and remaining_budget > 0.0:
            # Reserve relay mobility for late-domain changes instead of consuming
            # the complete mission budget during the first few MPC replans.
            remaining_steps = max(1, c.max_steps - self.step_id)
            remaining_plans = max(
                1,
                int(math.ceil(remaining_steps / max(self.usv_period, 1))),
            )
            nominal_pace = remaining_budget / remaining_plans
            urgency_scale = 0.78 + 0.72 * float(np.clip(urgency, 0.0, 1.0))
            delta_limit = min(delta_limit, max(0.04, urgency_scale * nominal_pace))
        delta = _clip_norm((np.asarray(desired_usv) - self.usv_pos)[None, :], delta_limit)[0]
        self.usv_pos += delta
        self.usv_distance += float(np.linalg.norm(delta))

    def plan_usv(self, planner: str, drift: float, geom: Dict[str, float]) -> float:
        c = self.cfg
        self.active_planner = planner
        risk = self._escape_risk(geom)
        planning_risk = risk
        target_speed_ratio = np.linalg.norm(self.cached_target_vel) / max(c.target_max_speed, 1e-6)
        self.planner_target_speed_history.append(float(target_speed_ratio))
        if planner == "full_mpc":
            planning_risk = float(np.clip(
                risk + 0.12 * target_speed_ratio + 0.08 * drift,
                0.0,
                1.5,
            ))
        if planner == "full_mpc" and c.mpc_dynamic_period:
            replanning_urgency = max(
                float(np.clip(planning_risk, 0.0, 1.25)),
                float(np.clip(target_speed_ratio, 0.0, 1.0)),
                float(np.clip(drift, 0.0, 1.0)),
            )
            self.usv_period = int(np.clip(
                round(c.usv_update_period - c.mpc_period_risk_gain * replanning_urgency),
                2,
                c.usv_update_period,
            ))
        elif planner in {"fixed", "fim", "fim_mobility", "full_mpc"}:
            self.usv_period = c.usv_update_period
        elif planner in {"dynamic_period", "dual_plane"}:
            self.usv_period = int(np.clip(round(c.usv_update_period + 5.0 * (1.0 - planning_risk) - 3.5 * drift), 2, 11))
        self.usv_period_history.append(float(self.usv_period))

        if planner == "full_mpc":
            # The safeguarded residual MPC shares FIM's execution bandwidth so
            # any gain comes from look-ahead waypoint selection, not extra bytes.
            if c.mpc_dynamic_bandwidth:
                mean_per = float(np.mean(self.per_ema))
                mean_aoi = float(np.mean(self.aoi))
                link_pressure = max(
                    float(np.clip((mean_per - 0.46) / 0.24, 0.0, 1.0)),
                    float(np.clip((mean_aoi - 1.35) / 1.25, 0.0, 1.0)),
                )
                allocation_pressure = max(
                    0.35 * float(np.clip(planning_risk, 0.0, 1.0)),
                    link_pressure,
                )
                self.control_ratio = float(np.clip(
                    c.mpc_control_ratio_min
                    + (c.mpc_control_ratio_max - c.mpc_control_ratio_min)
                    * allocation_pressure,
                    c.mpc_control_ratio_min,
                    c.mpc_control_ratio_max,
                ))
            else:
                self.control_ratio = 0.70
        elif planner == "dual_plane":
            # Control traffic dominates near escape; learning traffic dominates only
            # when the formation is stable but persistent domain drift is detected.
            self.control_ratio = float(np.clip(0.62 + 0.32 * planning_risk - 0.08 * drift * (1.0 - planning_risk), 0.55, 0.94))
        else:
            self.control_ratio = 0.70

        if planner == "fixed":
            return self.control_ratio
        if self.step_id - self.last_usv_plan < self.usv_period:
            return self.control_ratio

        self.last_usv_plan = self.step_id
        center = 0.62 * np.mean(self.cached_auv, axis=0) + 0.38 * self.cached_target
        offsets = np.array([(x, y) for x in (-16.0, -8.0, 0.0, 8.0, 16.0)
                            for y in (-16.0, -8.0, 0.0, 8.0, 16.0)])
        candidates = np.clip(center + offsets, 3.0, c.arena_size - 3.0)
        if planner == "full_mpc":
            lead_center = center + c.dt * c.prediction_horizon * self.cached_target_vel
            heading = _unit(self.cached_target_vel[None, :])[0]
            relay_point = self.cached_target - 20.0 * heading
            candidates = np.concatenate([
                candidates,
                np.clip(lead_center + offsets, 3.0, c.arena_size - 3.0),
                self.usv_pos[None, :],
                np.clip(relay_point[None, :], 3.0, c.arena_size - 3.0),
            ], axis=0)
        if planner == "fixed":
            return self.control_ratio

        scores = []
        full_components = []
        for candidate in candidates:
            move = np.linalg.norm(candidate - self.usv_pos)
            fim = self._fim(candidate, self.cached_auv)
            comm = -np.mean(np.linalg.norm(self.cached_auv - candidate, axis=1)) / 80.0
            mobility = -move / 18.0
            if planner == "fim":
                score = fim
            elif planner in {"fim_mobility", "dynamic_period", "dual_plane"}:
                score = fim + 0.45 * comm + 0.38 * mobility
            else:
                # Candidate-dependent communication-aware follower rollout.
                pred_target = self.cached_target.copy()
                pred_auv = self.cached_auv.copy()
                pred_vel = self.cached_target_vel.copy()
                future = 0.0
                for h in range(1, c.prediction_horizon + 1):
                    pred_target = pred_target + pred_vel * c.dt
                    rel_now = pred_auv - pred_target
                    angles = np.mod(np.arctan2(rel_now[:, 1], rel_now[:, 0]), 2.0 * math.pi)
                    order = np.argsort(angles)
                    unwrapped = np.unwrap(angles[order])
                    anchor = float(np.median(unwrapped - np.arange(c.n_auv) * ideal_gap(c.n_auv)))
                    desired_angles = anchor + np.arange(c.n_auv) * ideal_gap(c.n_auv)
                    desired = np.zeros_like(pred_auv)
                    desired[order] = pred_target + c.desired_radius * np.stack(
                        [np.cos(desired_angles), np.sin(desired_angles)], axis=1
                    )
                    freshness = self._prospective_link_quality(candidate, pred_auv)
                    response_gain = 0.055 + 0.285 * freshness
                    pred_auv += response_gain[:, None] * (desired - pred_auv)
                    rel = pred_auv - pred_target
                    rr = np.linalg.norm(rel, axis=1)
                    future_angles = np.sort(np.mod(np.arctan2(rel[:, 1], rel[:, 0]), 2.0 * math.pi))
                    future_gaps = np.diff(np.r_[future_angles, future_angles[0] + 2.0 * math.pi])
                    gap_excess = max(0.0, float(np.max(future_gaps) / ideal_gap(c.n_auv) - 1.0))
                    centroid_error = float(np.linalg.norm(pred_target - np.mean(pred_auv, axis=0)))
                    future -= 0.22 * float(np.mean(np.abs(rr - c.desired_radius))) / c.desired_radius
                    future -= 0.30 * gap_excess + 0.08 * centroid_error / c.desired_radius
                    future += 0.08 * self._fim(candidate, pred_auv)
                    mean_freshness = float(np.mean(freshness))
                    worst_freshness = float(np.min(freshness))
                    future += 0.34 * mean_freshness + 0.22 * worst_freshness
                    future -= 0.30 * max(0.0, 0.42 - worst_freshness)
                current_links = self._prospective_link_quality(candidate, self.cached_auv)
                current_freshness = float(np.mean(current_links))
                worst_freshness = float(np.min(current_links))
                reactive_baseline = fim + 0.45 * comm + 0.38 * mobility
                full_components.append(
                    (
                        reactive_baseline,
                        fim,
                        comm,
                        mobility,
                        future,
                        current_freshness,
                        worst_freshness,
                    )
                )
                score = 0.0
            scores.append(score)
        selected_index = None
        desired_usv_override = None
        if planner == "full_mpc":
            components = np.asarray(full_components, dtype=np.float64)
            median = np.median(components, axis=0)
            scale = np.std(components, axis=0) + 1e-6
            normalized = np.clip((components - median[None, :]) / scale[None, :], -3.0, 3.0)
            forecast_confidence = float(np.clip(
                math.exp(-float(np.mean(self.aoi)) / 2.2) *
                (1.0 - float(np.mean(self.per_ema))),
                0.0,
                1.0,
            ))
            # A FIM-anchored robust MPC: uncertain forecasts fall back toward the
            # best observable geometry, while reliable forecasts exploit the
            # multi-step formation and worst-link rollouts.
            weights = np.array([
                c.mpc_reactive_weight + 0.16 * (1.0 - forecast_confidence),
                0.08 * (1.0 - forecast_confidence),
                0.05,
                0.03,
                c.mpc_rollout_weight * forecast_confidence,
                c.mpc_mean_link_weight * forecast_confidence,
                c.mpc_worst_link_weight * forecast_confidence,
            ])
            scores = list(normalized @ weights)
            mpc_index = int(np.argmax(scores))
            # Dominance-preserving anytime fallback: under uncertain forecasts,
            # use the best FIM waypoint from the common base candidate lattice
            # unless the multi-step rollout clears a confidence-scaled margin.
            baseline_count = len(offsets)
            fim_index = int(np.argmax(components[:baseline_count, 1]))
            required_gain = c.mpc_gain_margin * (1.0 - forecast_confidence)
            fim_floor_ok = bool(
                normalized[mpc_index, 1]
                >= normalized[fim_index, 1] - max(0.0, c.mpc_fim_floor_tolerance)
            )
            gate_accepts = bool(
                forecast_confidence >= c.mpc_min_confidence
                and scores[mpc_index] >= scores[fim_index] + required_gain
                and fim_floor_ok
            )
            selected_index = mpc_index if gate_accepts else fim_index
            base_residual_gain = float(np.clip(c.mpc_residual_gain, 0.0, 1.0))
            max_residual_gain = float(np.clip(
                max(c.mpc_residual_gain_max, base_residual_gain),
                0.0,
                1.0,
            ))
            gain_evidence = float(np.clip(
                (scores[mpc_index] - scores[fim_index] - required_gain) / 0.85,
                0.0,
                1.0,
            ))
            residual_gain = base_residual_gain + (
                max_residual_gain - base_residual_gain
            ) * forecast_confidence * gain_evidence * max(0.35, planning_risk)
            residual_active = bool(
                gate_accepts and mpc_index != fim_index and residual_gain > 0.0
            )
            if gate_accepts and residual_gain < 1.0:
                desired_usv_override = (
                    candidates[fim_index]
                    + residual_gain * (candidates[mpc_index] - candidates[fim_index])
                )
            self.full_mpc_fallback_active = not gate_accepts
            self.full_mpc_fallback_history.append(float(self.full_mpc_fallback_active))
            self.full_mpc_residual_history.append(float(residual_active))
        if selected_index is None:
            selected_index = int(np.argmax(scores))
        desired_usv = (
            desired_usv_override
            if desired_usv_override is not None
            else candidates[selected_index]
        )
        terminal_link_requested = bool(
            planner == "full_mpc"
            and c.mpc_terminal_link_streak > 0
            and self.capture_streak >= c.mpc_terminal_link_streak
        )
        terminal_link_active = False
        if terminal_link_requested:
            baseline_links = components[:baseline_count, 5:7]
            baseline_move = np.linalg.norm(
                candidates[:baseline_count] - self.usv_pos[None, :], axis=1
            )
            terminal_scores = (
                0.38 * baseline_links[:, 0]
                + 0.62 * baseline_links[:, 1]
                - 0.03 * baseline_move / 18.0
            )
            fim_floor = (
                normalized[fim_index, 1]
                - max(0.0, c.mpc_terminal_fim_tolerance)
            )
            terminal_scores = np.where(
                normalized[:baseline_count, 1] >= fim_floor,
                terminal_scores,
                -np.inf,
            )
            terminal_index = int(np.argmax(terminal_scores))
            link_gain = float(
                baseline_links[terminal_index, 1] - baseline_links[fim_index, 1]
            )
            terminal_link_active = bool(
                np.isfinite(terminal_scores[terminal_index])
                and link_gain >= max(0.0, c.mpc_terminal_min_link_gain)
            )
            if terminal_link_active:
                terminal_gain = float(np.clip(c.mpc_terminal_link_gain, 0.0, 1.0))
                desired_usv = (
                    candidates[fim_index]
                    + terminal_gain * (candidates[terminal_index] - candidates[fim_index])
                )
        if planner == "full_mpc":
            self.full_mpc_terminal_link_history.append(float(terminal_link_active))
        self.usv_waypoint = desired_usv.copy()
        self._advance_usv(
            self.usv_waypoint,
            budget_paced=(planner == "full_mpc" and c.mpc_budget_pacing),
            urgency=planning_risk,
        )
        return self.control_ratio

    def _move_target(self, domain: DomainConfig) -> None:
        c = self.cfg
        rel = self.auv_pos - self.target_pos
        angles = np.mod(np.arctan2(rel[:, 1], rel[:, 0]), 2.0 * math.pi)
        order = np.argsort(angles)
        sorted_angles = angles[order]
        gaps = np.diff(np.r_[sorted_angles, sorted_angles[0] + 2.0 * math.pi])
        k = int(np.argmax(gaps))
        gap_dir = sorted_angles[k] + 0.5 * gaps[k]
        gap_vec = np.array([math.cos(gap_dir), math.sin(gap_dir)])
        away = _unit((self.target_pos - np.mean(self.auv_pos, axis=0))[None, :])[0]
        deception = domain.target_deception * np.array([
            math.sin(0.31 * self.step_id + 0.7 * self.seed),
            math.cos(0.27 * self.step_id - 0.3 * self.seed),
        ])
        desired = (1.0 - domain.target_evasion) * _unit(self.target_vel[None, :])[0]
        desired += domain.target_evasion * (0.72 * gap_vec + 0.28 * away) + deception
        target_margin = c.desired_radius + 9.0
        soft_margin = target_margin + 16.0
        boundary_steer = np.zeros(2)
        boundary_steer += np.where(self.target_pos < soft_margin,
                                   (soft_margin - self.target_pos) / 16.0, 0.0)
        boundary_steer -= np.where(self.target_pos > c.arena_size - soft_margin,
                                   (self.target_pos - (c.arena_size - soft_margin)) / 16.0, 0.0)
        desired += 1.35 * boundary_steer
        desired = _unit(desired[None, :])[0] * min(domain.target_speed, c.target_max_speed)
        turn = 0.18 + 0.22 * domain.target_evasion
        self.target_vel = (1.0 - turn) * self.target_vel + turn * desired
        self.target_vel = _clip_norm(self.target_vel[None, :], c.target_max_speed)[0]
        ambient = np.array([domain.current_x, domain.current_y]) * 0.25
        self.target_pos += (self.target_vel + ambient) * c.dt
        # Keep a full feasible encirclement annulus inside the workspace. Letting
        # the target approach the wall closer than the desired ring radius would
        # make the task geometrically impossible and confound domain adaptation
        # with an invalid benchmark state.
        hit = np.logical_or(self.target_pos < target_margin, self.target_pos > c.arena_size - target_margin)
        if np.any(hit):
            self.target_vel[hit] *= -1.0
            self.target_pos = np.clip(self.target_pos, target_margin, c.arena_size - target_margin)

    def _communicate(self, domain: DomainConfig) -> None:
        c = self.cfg
        distances = np.linalg.norm(self.auv_pos - self.usv_pos, axis=1)
        acoustic = np.clip((distances / c.acoustic_range) ** 2, 0.0, 0.62)
        midpoint = 0.5 * (self.auv_pos + self.usv_pos[None, :])
        shadow_centers = np.array([[68.0, 118.0], [138.0, 76.0]])
        shadow_distance = np.linalg.norm(midpoint[:, None, :] - shadow_centers[None, :, :], axis=2)
        shadow = np.max(np.exp(-0.5 * (shadow_distance / 24.0) ** 2), axis=1)
        temporal_fade = 0.5 + 0.5 * math.sin(0.11 * self.step_id + 0.4 * self.seed)
        base_per = np.clip(
            domain.packet_loss + acoustic + domain.channel_shadow * shadow * temporal_fade,
            0.0,
            0.96,
        )
        packet_capacity = int((c.total_bandwidth * c.dt * self.control_ratio) /
                              max(c.control_packet_bytes, 1.0))
        attempts_per_step = min(c.max_retransmissions, packet_capacity // max(c.n_auv, 1))
        attempt_budget = np.full(c.n_auv, attempts_per_step, dtype=np.int64)
        priority_extras = 0
        if (
            self.active_planner == "full_mpc"
            and c.mpc_priority_retransmission
            and packet_capacity > 0
            and (
                float(np.mean(self.per_ema)) >= c.mpc_priority_per_threshold
                or float(np.max(self.aoi)) >= c.mpc_priority_aoi_threshold
            )
        ):
            remaining = max(0, packet_capacity - int(np.sum(attempt_budget)))
            # Weak-link scheduling alone can repeatedly refresh an agent whose
            # state is not mission-critical.  Add a geometry pressure term for
            # the two agents bordering a large angular gap and for agents with
            # large radial error, while retaining PER/AoI as the main signal.
            rel = self.cached_auv - self.cached_target[None, :]
            radii = np.linalg.norm(rel, axis=1)
            angles = np.mod(np.arctan2(rel[:, 1], rel[:, 0]), 2.0 * math.pi)
            order = np.argsort(angles)
            sorted_angles = angles[order]
            gaps = np.diff(np.r_[sorted_angles, sorted_angles[0] + 2.0 * math.pi])
            angular_pressure = np.zeros(c.n_auv, dtype=np.float64)
            for rank, index in enumerate(order):
                angular_pressure[index] = max(gaps[rank - 1], gaps[rank])
            angular_pressure = np.clip(
                angular_pressure / max(ideal_gap(c.n_auv), 1e-6) - 0.75,
                0.0,
                1.5,
            ) / 1.5
            radial_pressure = np.clip(
                np.abs(radii - c.desired_radius) / max(2.0 * c.radial_tolerance, 1e-6),
                0.0,
                1.0,
            )
            geometry_priority = 0.62 * angular_pressure + 0.38 * radial_pressure
            priority_score = (
                0.52 * self.per_ema
                + 0.18 * np.clip(self.aoi / 3.0, 0.0, 1.0)
                + 0.30 * base_per
                + max(0.0, c.mpc_geometry_priority_weight) * geometry_priority
            )
            priority_order = list(np.argsort(-priority_score))
            while remaining > 0:
                assigned = False
                for index in priority_order:
                    if attempt_budget[index] >= c.max_retransmissions:
                        continue
                    attempt_budget[index] += 1
                    remaining -= 1
                    priority_extras += 1
                    assigned = True
                    if remaining <= 0:
                        break
                if not assigned:
                    break
        if self.active_planner == "full_mpc":
            self.full_mpc_priority_extra_history.append(float(priority_extras))
        step_packet_attempts = 0
        any_success = False
        noisy_targets = []
        self.aoi += c.dt
        if int(np.sum(attempt_budget)) <= 0:
            self.per_ema = 0.90 * self.per_ema + 0.10
        for i in range(c.n_auv):
            burst_draw = self.channel_draws[self.step_id, i, 0, 0]
            if self.burst_state[i]:
                self.burst_state[i] = burst_draw < (0.52 + 0.40 * domain.burst_loss)
            else:
                self.burst_state[i] = burst_draw < 0.08 * domain.burst_loss
            success = False
            for attempt in range(int(attempt_budget[i])):
                per = min(0.98, base_per[i] + (0.52 if self.burst_state[i] else 0.0))
                lost = self.channel_draws[self.step_id, i, attempt, 1] < per
                self.packet_attempts += 1
                step_packet_attempts += 1
                self.packet_losses += int(lost)
                self.per_ema[i] = 0.92 * self.per_ema[i] + 0.08 * float(lost)
                if not lost:
                    success = True
                    break
            if success:
                elapsed = max(c.dt, float(self.aoi[i]))
                fault = self.sensor_fault_draws[self.step_id, i] < domain.sensor_fault
                noise_scale = domain.localization_noise * (5.0 if fault else 1.0)
                bias = np.array([domain.localization_bias_x, domain.localization_bias_y])
                observed_auv = (
                    self.auv_pos[i]
                    + bias
                    + noise_scale * self.sensor_auv_noise[self.step_id, i]
                )
                # A successful packet is not automatically trustworthy.  The
                # innovation envelope rejects isolated sensor faults without
                # using latent domain labels or privileged simulator state.
                if (
                    self.active_planner == "full_mpc"
                    and c.mpc_robust_information_filter
                ):
                    predicted_auv = (
                        self.cached_auv[i] + self.cached_auv_vel[i] * elapsed
                    )
                    innovation_limit = (
                        max(0.0, c.mpc_innovation_slack)
                        + 1.25 * c.auv_max_speed * elapsed
                    )
                    innovation = _clip_norm(
                        (observed_auv - predicted_auv)[None, :], innovation_limit
                    )[0]
                    observed_auv = predicted_auv + innovation
                observed_velocity = (observed_auv - self.cached_auv[i]) / elapsed
                observed_velocity = _clip_norm(
                    observed_velocity[None, :], 1.25 * c.auv_max_speed
                )[0]
                self.cached_auv_vel[i] = (
                    0.78 * self.cached_auv_vel[i] + 0.22 * observed_velocity
                )
                self.cached_auv[i] = observed_auv
                noisy_targets.append(
                    self.target_pos
                    + 0.55 * bias
                    + noise_scale * self.sensor_target_noise[self.step_id, i]
                )
                self.aoi[i] = (
                    distances[i] / 1500.0
                    + 0.10
                    + self.sensor_aoi_jitter[self.step_id, i]
                )
                any_success = True
        self.target_measurement_age += 1
        if any_success and noisy_targets:
            target_samples = np.asarray(noisy_targets, dtype=np.float64)
            measurement = np.mean(target_samples, axis=0)
            if (
                self.active_planner == "full_mpc"
                and c.mpc_robust_information_filter
                and len(target_samples) >= 2
            ):
                coordinate_median = np.median(target_samples, axis=0)
                residual = np.linalg.norm(
                    target_samples - coordinate_median[None, :], axis=1
                )
                mad = float(np.median(residual))
                huber_radius = max(0.75, 2.5 * mad)
                weights = np.minimum(
                    1.0, huber_radius / np.maximum(residual, 1e-6)
                )
                measurement = np.sum(
                    weights[:, None] * target_samples, axis=0
                ) / max(float(np.sum(weights)), 1e-6)
                target_prediction = (
                    self.cached_target + self.cached_target_vel * c.dt
                )
                target_innovation_limit = (
                    max(0.0, c.mpc_innovation_slack)
                    + 1.35 * c.target_max_speed * c.dt
                )
                measurement = target_prediction + _clip_norm(
                    (measurement - target_prediction)[None, :],
                    target_innovation_limit,
                )[0]
            self.prev_cached_target = self.cached_target.copy()
            self.cached_target = 0.68 * measurement + 0.32 * self.cached_target
            velocity = (self.cached_target - self.prev_cached_target) / max(c.dt, 1e-6)
            self.cached_target_vel = 0.72 * self.cached_target_vel + 0.28 * velocity
            self.last_target_measurement = measurement.copy()
            self.target_measurement_age = 0
        self.last_control_bytes_step = step_packet_attempts * c.control_packet_bytes
        self.control_bytes += self.last_control_bytes_step

    def observe(self, domain: DomainConfig) -> Dict[str, np.ndarray]:
        c = self.cfg
        local_noise = domain.localization_noise * 0.32
        noise_index = min(self.step_id, len(self.local_observation_noise) - 1)
        own = self.auv_pos + local_noise * self.local_observation_noise[noise_index]
        return {
            "self_pos": own.astype(np.float32),
            "team_pos": self.cached_auv.astype(np.float32).copy(),
            "target_pos": self.cached_target.astype(np.float32).copy(),
            "target_vel": self.cached_target_vel.astype(np.float32).copy(),
            "auv_vel": self.auv_vel.astype(np.float32).copy(),
            "usv_pos": self.usv_pos.astype(np.float32).copy(),
            "aoi": self.aoi.astype(np.float32).copy(),
            "per": self.per_ema.astype(np.float32).copy(),
            "phase": np.array([(self.step_id % max(self.usv_period, 1)) / max(self.usv_period, 1)], dtype=np.float32),
            "control_ratio": np.array([self.control_ratio], dtype=np.float32),
        }

    def step(
        self,
        command: np.ndarray,
        domain: DomainConfig,
        planner: str,
        drift: float,
        learning_active: float = 0.0,
    ) -> Tuple[Dict[str, np.ndarray], float, bool, Dict[str, float]]:
        c = self.cfg
        geom_before = self._geometry()
        self.plan_usv(planner, drift, geom_before)
        self._move_target(domain)

        command = _clip_norm(np.asarray(command, dtype=np.float64), c.auv_max_speed)
        current = self._current(domain)
        effective = domain.dynamics_scale * domain.thruster_health
        desired_body = effective * command
        response = np.clip(0.34 * domain.dynamics_scale, 0.12, 0.48)
        previous_velocity = self.auv_vel.copy()
        self.auv_vel += response * (desired_body - self.auv_vel)
        displacement = (self.auv_vel + current) * c.dt
        proposed = self.auv_pos + displacement
        border_hit = np.logical_or(proposed < 0.0, proposed > c.arena_size)
        if np.any(border_hit):
            self.border_events += int(np.any(border_hit, axis=1).sum())
            proposed = np.clip(proposed, 0.0, c.arena_size)
            self.auv_vel[border_hit] *= -0.15
        self.auv_pos = proposed

        pair = self.auv_pos[:, None, :] - self.auv_pos[None, :, :]
        distances = np.linalg.norm(pair + np.eye(c.n_auv)[:, :, None] * 1e6, axis=2)
        collisions = np.argwhere(np.triu(distances < c.collision_distance, 1))
        self.collision_events += len(collisions)
        for i, j in collisions:
            push = _unit((self.auv_pos[i] - self.auv_pos[j])[None, :])[0]
            if np.linalg.norm(push) < 1e-6:
                push = np.array([1.0, 0.0])
            correction = 0.5 * (c.collision_distance - distances[i, j] + 0.1) * push
            self.auv_pos[i] += correction
            self.auv_pos[j] -= correction

        accel = (self.auv_vel - previous_velocity) / c.dt
        self.energy += float(np.sum(0.28 * np.linalg.norm(command, axis=1) ** 3 +
                                    0.20 * np.linalg.norm(accel, axis=1) ** 2 + 2.0) * c.dt)
        self.prev_cmd = command.copy()
        self._communicate(domain)
        if planner == "full_mpc" and c.mpc_dynamic_bandwidth:
            # Work-conserving dual control: unused retransmission reservations
            # return to adaptation in the same slot, so control + learning never
            # exceeds the common total bandwidth budget.
            available_learning = max(
                0.0,
                c.total_bandwidth * c.dt - self.last_control_bytes_step,
            )
        else:
            available_learning = c.total_bandwidth * c.dt * (1.0 - self.control_ratio)
        self.learning_bytes += min(available_learning, learning_active * c.learning_packet_bytes)

        geom = self._geometry()
        self.capture_streak = self.capture_streak + 1 if geom["stable"] > 0.5 else 0
        self.captured = self.captured or self.capture_streak >= c.capture_hold
        centroid_distance = np.linalg.norm(self.target_pos - np.mean(self.auv_pos, axis=0))
        self.escaped = self.escaped or (centroid_distance > c.escape_distance and geom["max_gap"] > 1.7 * ideal_gap(c.n_auv))
        risk = self._escape_risk(geom)
        reward = 2.5 * geom["score"] + 1.2 * geom["stable"] - 0.8 * risk
        reward -= 0.20 * len(collisions) + 0.002 * float(np.sum(np.linalg.norm(command, axis=1) ** 3))

        self.step_id += 1
        self.fim_history.append(self._fim())
        self.score_history.append(geom["score"])
        self.gap_history.append(geom["max_gap"])
        self.radius_history.append(geom["radius_error"])
        self.min_pair_history.append(geom["min_pair"])
        self.inside_history.append(geom["target_inside"])
        self.aoi_history.append(float(np.mean(self.aoi)))
        self.per_history.append(float(np.mean(self.per_ema)))
        self.control_ratio_history.append(self.control_ratio)
        self.usv_history.append(self.usv_pos.copy())
        self.target_history.append(self.target_pos.copy())
        self.auv_history.append(self.auv_pos.copy())
        self.domain_history.append(domain)
        # Escape is an evaluated safety event, not an early termination: online
        # methods must be allowed to demonstrate post-shift recovery.
        done = self.step_id >= c.max_steps
        info = {
            **geom,
            "risk": risk,
            "captured": float(self.captured),
            "escaped": float(self.escaped),
            "fim": self.fim_history[-1],
            "aoi": self.aoi_history[-1],
            "per": self.per_history[-1],
            "control_ratio": self.control_ratio,
            "current_displacement_x": float(np.mean(current[:, 0]) * c.dt),
            "current_displacement_y": float(np.mean(current[:, 1]) * c.dt),
        }
        return self.observe(domain), float(reward), done, info

    def summary(self) -> Dict[str, float]:
        scores = np.asarray(self.score_history or [0.0])
        gaps = np.asarray(self.gap_history or [2.0 * math.pi])
        radii = np.asarray(self.radius_history or [self.cfg.desired_radius])
        min_pair = np.asarray(self.min_pair_history or [0.0])
        inside = np.asarray(self.inside_history or [0.0])
        aoi = np.asarray(self.aoi_history or [0.0])
        per = np.asarray(self.per_history or [0.0])
        target_speed_ratio = np.asarray(self.planner_target_speed_history or [0.0])
        stable = np.asarray(
            (gaps <= self.cfg.capture_gap_multiplier * ideal_gap(self.cfg.n_auv)) &
            (radii <= self.cfg.radial_tolerance) &
            (min_pair >= self.cfg.collision_distance) &
            (inside > 0.5),
            dtype=float,
        )
        final_stable = float(np.mean(stable[-30:]))
        final_capture = float(final_stable >= 0.55 and not self.escaped)
        return {
            "capture_success": final_capture,
            "capture_time": float(np.argmax(stable > 0.5) * self.cfg.dt) if final_capture else float(self.cfg.max_steps * self.cfg.dt),
            "escape_rate": float(self.escaped),
            "formation_score": float(np.mean(scores)),
            "final_performance": float(np.mean(scores[-30:])),
            "min_performance": float(np.min(scores[int(0.20 * len(scores)):])),
            "radius_error": float(np.mean(radii)),
            "max_angle_gap": float(np.mean(gaps)),
            "target_inside_fraction": float(np.mean(inside)),
            "min_pair_distance": float(np.mean(min_pair)),
            "aoi": float(np.mean(aoi)),
            "per": float(np.mean(per)),
            "control_bytes": float(self.control_bytes),
            "learning_bytes": float(self.learning_bytes),
            "auv_energy": float(self.energy),
            "usv_distance": float(self.usv_distance),
            "collision_rate": float(self.collision_events / max(1, self.step_id * self.cfg.n_auv)),
            "border_rate": float(self.border_events / max(1, self.step_id * self.cfg.n_auv)),
            "fim": float(np.mean(self.fim_history or [-30.0])),
            "stability": float(np.mean(stable)),
            "final_stability": final_stable,
            "planner_target_speed_ratio_mean": float(np.mean(target_speed_ratio)),
            "planner_target_speed_ratio_p90": float(np.quantile(target_speed_ratio, 0.90)),
            "usv_period_mean": float(np.mean(self.usv_period_history or [self.cfg.usv_update_period])),
            "full_mpc_fallback_rate": float(np.mean(self.full_mpc_fallback_history or [0.0])),
            "full_mpc_residual_rate": float(np.mean(self.full_mpc_residual_history or [0.0])),
            "full_mpc_terminal_link_rate": float(np.mean(self.full_mpc_terminal_link_history or [0.0])),
            "full_mpc_priority_extras": float(np.mean(
                self.full_mpc_priority_extra_history or [0.0]
            )),
        }
