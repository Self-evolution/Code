from __future__ import annotations

from dataclasses import dataclass, replace
import math
from typing import Dict, Tuple


@dataclass(frozen=True)
class DomainConfig:
    """Latent Markov-domain parameters. Controllers never observe these directly."""

    current_x: float = 0.0
    current_y: float = 0.0
    current_gust: float = 0.0
    current_turn_rate: float = 0.0
    target_speed: float = 1.0
    target_evasion: float = 0.25
    target_deception: float = 0.0
    packet_loss: float = 0.02
    burst_loss: float = 0.0
    localization_noise: float = 0.25
    localization_bias_x: float = 0.0
    localization_bias_y: float = 0.0
    dynamics_scale: float = 1.0
    thruster_health: float = 1.0
    sensor_fault: float = 0.0
    channel_shadow: float = 0.0
    current_shear: float = 0.0


@dataclass(frozen=True)
class SimConfig:
    n_auv: int = 4
    max_steps: int = 300
    dt: float = 0.5
    arena_size: float = 200.0
    desired_radius: float = 18.0
    radial_tolerance: float = 3.5
    capture_hold: int = 20
    capture_gap_multiplier: float = 1.40
    capture_final_window: int = 60
    capture_required_fraction: float = 0.70
    capture_score_threshold: float = 0.65
    initial_angle_jitter: float = 0.55
    initial_radius_offset: float = 8.0
    initial_radius_std: float = 7.0
    initial_target_speed: float = 0.95
    auv_max_speed: float = 3.2
    target_max_speed: float = 2.6
    usv_max_speed: float = 2.5
    usv_movement_budget: float = 70.0
    collision_distance: float = 4.0
    safety_distance: float = 7.0
    safety_margin_fraction: float = 0.30
    action_trust_base: float = 1.40
    action_trust_risk_gain: float = 1.20
    action_trust_formation_gain: float = 2.0
    maneuver_gate_gain: float = 0.90
    maneuver_trust_gain: float = 0.90
    kinematic_action_trust_gain: float = 2.50
    kinematic_trust_reference_gain: float = 0.0
    kinematic_accel_feedforward_gain: float = 0.26
    kinematic_slot_gain: float = 0.20
    kinematic_guard_mix_gain: float = 1.20
    kinematic_candidate_prior_weight: float = 0.92
    maneuver_update_gain: float = 0.85
    maneuver_update_formation_gate: bool = False
    maneuver_update_model_gate: bool = False
    maneuver_update_model_threshold: float = 0.50
    maneuver_update_model_width: float = 0.12
    maneuver_update_risk_floor: float = 0.15
    maneuver_update_pressure_threshold: float = 0.12
    maneuver_update_pressure_width: float = 0.08
    maneuver_update_need_threshold: float = 0.20
    maneuver_update_need_width: float = 0.45
    maneuver_gradient_ema_decay: float = 0.0
    maneuver_gradient_ema_threshold: float = 0.30
    maneuver_gradient_ema_width: float = 0.12
    kinematic_update_batch: int = 1
    kinematic_update_batch_threshold: float = 0.16
    mode_adapter_suppression: float = 0.12
    fast_mode_gain: float = 0.0
    fast_mode_threshold: float = 0.16
    fast_mode_width: float = 0.42
    fast_mode_trust_gain: float = 0.0
    fast_expert_blend: float = 0.0
    robust_observer_gain: float = 0.0
    adapter_trust_radius: float = 0.075
    kinematic_adapter_trust_gain: float = 0.0
    kinematic_trust_update_damping: float = 0.15
    uncertainty_scale: float = 0.01
    uncertainty_deadzone: float = 0.00
    escape_distance: float = 42.0
    usv_update_period: int = 5
    total_bandwidth: float = 9_000.0
    control_packet_bytes: float = 512.0
    learning_packet_bytes: float = 2_048.0
    max_retransmissions: int = 3
    acoustic_range: float = 112.0
    prediction_horizon: int = 6
    mpc_min_confidence: float = 0.48
    mpc_gain_margin: float = 0.10
    mpc_residual_gain: float = 0.04
    mpc_residual_gain_max: float = 0.12
    mpc_reactive_weight: float = 0.46
    mpc_rollout_weight: float = 0.32
    mpc_mean_link_weight: float = 0.12
    mpc_worst_link_weight: float = 0.18
    mpc_fim_floor_tolerance: float = 0.15
    mpc_budget_pacing: bool = False
    mpc_dynamic_bandwidth: bool = True
    mpc_priority_retransmission: bool = True
    mpc_priority_per_threshold: float = 0.0
    mpc_priority_aoi_threshold: float = 0.0
    mpc_control_ratio_min: float = 0.80
    mpc_control_ratio_max: float = 0.94
    mpc_dynamic_period: bool = False
    mpc_period_risk_gain: float = 2.0
    mpc_geometry_priority_weight: float = 0.25
    mpc_robust_information_filter: bool = True
    mpc_innovation_slack: float = 1.5
    mpc_terminal_link_streak: int = 0
    mpc_terminal_link_gain: float = 0.25
    mpc_terminal_fim_tolerance: float = 0.25
    mpc_terminal_min_link_gain: float = 0.0
    window: int = 20
    anchor_threshold: float = 0.40


METHODS = (
    "source_only",
    "domain_randomization",
    "direct_finetune",
    "stdw",
    "ctta",
    "campe",
)

PLANNERS = (
    "fixed",
    "fim",
    "fim_mobility",
    "dynamic_period",
    "dual_plane",
    "full_mpc",
)

ABLATIONS = (
    "full",
    "no_ensemble",
    "no_uncertainty",
    "no_safety",
    "no_margin",
    "no_dynamic_weight",
    "no_old_anchor",
    "no_trust_region",
    "no_drift_separation",
    "no_kinematic_gate",
    "no_mode_priors",
)


def _lerp(a: float, b: float, x: float) -> float:
    return a + (b - a) * min(1.0, max(0.0, x))


def _severity(kind: str, step: int, total_steps: int) -> float:
    if kind == "source":
        return 0.0
    if kind == "gradual":
        return min(1.0, max(0.0, (step / total_steps - 0.18) / 0.62))
    if kind == "sudden":
        return 0.0 if step < int(0.35 * total_steps) else 1.0
    if kind == "joint":
        if step < int(0.20 * total_steps):
            return 0.0
        if step < int(0.42 * total_steps):
            return 0.45
        if step < int(0.66 * total_steps):
            return 0.78
        return 1.15
    if kind == "recurrent":
        phase = step / max(total_steps, 1)
        if phase < 0.18:
            return 0.0
        if phase < 0.44:
            return 1.05
        if phase < 0.60:
            return 0.18
        if phase < 0.82:
            return 1.30
        return 0.72
    return 1.0


def scenario_at(kind: str, step: int, total_steps: int, strength: float = 1.0) -> DomainConfig:
    """Return the domain active at ``step`` for a named non-stationary scenario."""

    sev = _severity(kind, step, total_steps) * strength
    base = DomainConfig()
    if kind == "source":
        return base

    # Single-factor validation shifts.
    if kind == "current":
        return replace(base, current_x=0.95 * sev, current_y=-0.55 * sev,
                       current_gust=0.42 * sev, current_turn_rate=0.021 * sev,
                       current_shear=0.28 * sev)
    if kind == "target_evasion":
        return replace(base, target_speed=_lerp(1.0, 2.05, sev),
                       target_evasion=_lerp(0.25, 1.0, sev), target_deception=0.35 * sev)
    if kind == "burst_loss":
        return replace(base, packet_loss=_lerp(0.02, 0.30, sev), burst_loss=0.70 * sev,
                       channel_shadow=0.35 * sev)
    if kind == "channel_shadow":
        return replace(base, packet_loss=_lerp(0.02, 0.18, sev), burst_loss=0.24 * sev,
                       channel_shadow=0.82 * sev)
    if kind == "localization":
        return replace(base, localization_noise=_lerp(0.25, 2.0, sev),
                       localization_bias_x=2.8 * sev, localization_bias_y=-2.1 * sev,
                       sensor_fault=0.12 * sev)
    if kind == "dynamics":
        return replace(base, dynamics_scale=_lerp(1.0, 0.70, sev), current_gust=0.15 * sev)
    if kind == "thruster":
        return replace(base, thruster_health=_lerp(1.0, 0.58, sev), current_x=0.25 * sev)

    # Composite shifts used for adaptation and planning experiments.
    return replace(
        base,
        current_x=0.35 * sev,
        current_y=-0.20 * sev,
        current_gust=0.16 * sev,
        current_turn_rate=0.010 * sev,
        current_shear=0.10 * sev,
        target_speed=_lerp(1.0, 1.40, sev),
        target_evasion=_lerp(0.25, 0.55, sev),
        target_deception=0.14 * sev,
        packet_loss=_lerp(0.02, 0.10, sev),
        burst_loss=0.22 * sev,
        channel_shadow=0.13 * sev,
        localization_noise=_lerp(0.25, 0.75, sev),
        localization_bias_x=0.65 * sev,
        localization_bias_y=-0.50 * sev,
        dynamics_scale=_lerp(1.0, 0.90, sev),
        thruster_health=_lerp(1.0, 0.88, sev),
        sensor_fault=0.03 * sev,
    )


OOD_SCENARIOS: Dict[str, Tuple[str, float]] = {
    "strong_current": ("current", 1.75),
    "direction_switch": ("joint", 1.45),
    "long_burst_loss": ("burst_loss", 1.75),
    "random_target": ("target_evasion", 1.65),
    "deceptive_target": ("target_evasion", 1.95),
    "sensor_anomaly": ("localization", 1.75),
    "severe_thruster": ("thruster", 1.65),
    "adversarial_mix": ("joint", 1.55),
    "blackout_chase": ("burst_loss", 1.45),
    "recurrent_shift": ("recurrent", 1.35),
}


def ideal_gap(n_auv: int) -> float:
    return 2.0 * math.pi / n_auv
