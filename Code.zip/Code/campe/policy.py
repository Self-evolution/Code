from __future__ import annotations

import copy
import math
from pathlib import Path
import time
from typing import Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import SimConfig, ideal_gap


FEATURE_DIM = 15


def _clip_norm_np(x: np.ndarray, limit: float) -> np.ndarray:
    n = np.linalg.norm(x, axis=-1, keepdims=True)
    return x * np.minimum(1.0, limit / np.maximum(n, 1e-8))


def _wrap_angle(x: np.ndarray) -> np.ndarray:
    return (x + math.pi) % (2.0 * math.pi) - math.pi


class DeterministicBackbone(nn.Module):
    """TD3-compatible actor architecture inherited from the first codebase."""

    def __init__(self, input_dim: int = FEATURE_DIM, hidden: int = 192):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, 2), nn.Tanh(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class StochasticBackbone(nn.Module):
    """SAC/DSAC-compatible stochastic actor; experiments use its posterior mean."""

    def __init__(self, input_dim: int = FEATURE_DIM, hidden: int = 192):
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
        )
        self.mean = nn.Linear(hidden, 2)
        self.log_std = nn.Linear(hidden, 2)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h = self.trunk(x)
        return torch.tanh(self.mean(h)), torch.clamp(self.log_std(h), -5.0, 0.5)


def expert_action_from_state(
    auv_pos: np.ndarray,
    auv_vel: np.ndarray,
    target_pos: np.ndarray,
    target_vel: np.ndarray,
    cfg: SimConfig,
) -> np.ndarray:
    """Oracle only used to pretrain a source-domain actor, never during adaptation."""

    n = cfg.n_auv
    speed = np.linalg.norm(target_vel)
    heading = math.atan2(target_vel[1], target_vel[0]) if speed > 0.08 else 0.0
    slots = heading + np.arange(n) * 2.0 * math.pi / n
    desired = target_pos + cfg.desired_radius * np.stack([np.cos(slots), np.sin(slots)], axis=1)
    cmd = target_vel[None, :] + 0.62 * (desired - auv_pos) - 0.20 * auv_vel
    pair = auv_pos[:, None, :] - auv_pos[None, :, :]
    distance = np.linalg.norm(pair + np.eye(n)[:, :, None] * 1e6, axis=2)
    for i in range(n):
        close = np.where(distance[i] < cfg.safety_distance)[0]
        for j in close:
            cmd[i] += 1.65 * (cfg.safety_distance - distance[i, j]) * pair[i, j] / max(distance[i, j], 1e-6)
    return _clip_norm_np(cmd, cfg.auv_max_speed)


def make_features(obs: Dict[str, np.ndarray], cfg: SimConfig) -> np.ndarray:
    own = np.asarray(obs["self_pos"], dtype=np.float64)
    team = np.asarray(obs["team_pos"], dtype=np.float64)
    target = np.asarray(obs["target_pos"], dtype=np.float64)
    target_vel = np.asarray(obs["target_vel"], dtype=np.float64)
    velocity = np.asarray(obs["auv_vel"], dtype=np.float64)
    n = cfg.n_auv
    rel = target[None, :] - own
    radii = np.linalg.norm(own - target, axis=1)
    target_heading = math.atan2(target_vel[1], target_vel[0]) if np.linalg.norm(target_vel) > 0.08 else 0.0
    own_angle = np.arctan2(own[:, 1] - target[1], own[:, 0] - target[0])
    desired_angle = target_heading + np.arange(n) * 2.0 * math.pi / n
    slot_error = _wrap_angle(desired_angle - own_angle)
    pair = own[:, None, :] - team[None, :, :]
    dist = np.linalg.norm(pair + np.eye(n)[:, :, None] * 1e6, axis=2)
    nearest_idx = np.argmin(dist, axis=1)
    neighbor = np.stack([pair[i, nearest_idx[i]] for i in range(n)], axis=0)
    features = np.concatenate([
        rel / 55.0,
        velocity / cfg.auv_max_speed,
        np.repeat(target_vel[None, :] / cfg.target_max_speed, n, axis=0),
        ((radii - cfg.desired_radius) / cfg.desired_radius)[:, None],
        np.stack([np.sin(slot_error), np.cos(slot_error)], axis=1),
        neighbor / max(cfg.safety_distance, 1.0),
        np.asarray(obs["aoi"])[:, None] / 4.0,
        np.asarray(obs["per"])[:, None],
        np.repeat(np.asarray(obs["phase"])[None, :], n, axis=0),
        # The source actor is invariant to bandwidth scheduling; communication
        # quality enters through AoI/PER, while the slow adapter handles plane
        # allocation changes. Keeping this feature at its source normalization
        # avoids introducing an artificial actor-domain shift when the USV
        # reallocates bandwidth online.
        np.full((n, 1), 0.70, dtype=np.float64),
    ], axis=1)
    assert features.shape == (n, FEATURE_DIM), features.shape
    return np.clip(features, -4.0, 4.0).astype(np.float32)


def _synthetic_source_data(cfg: SimConfig, samples: int, seed: int) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    x_rows, y_rows = [], []
    batches = max(1, math.ceil(samples / cfg.n_auv))
    for _ in range(batches):
        target = rng.uniform(35.0, cfg.arena_size - 35.0, 2)
        heading = rng.uniform(-math.pi, math.pi)
        target_speed = rng.uniform(0.25, 1.25)
        target_vel = target_speed * np.array([math.cos(heading), math.sin(heading)])
        slots = heading + np.arange(cfg.n_auv) * 2.0 * math.pi / cfg.n_auv
        angles = slots + rng.normal(0.0, 0.62, cfg.n_auv)
        radii = cfg.desired_radius + rng.normal(0.0, 7.0, cfg.n_auv)
        auv = target + np.stack([np.cos(angles), np.sin(angles)], axis=1) * radii[:, None]
        vel = rng.normal(0.0, 0.8, (cfg.n_auv, 2))
        obs = {
            "self_pos": auv.astype(np.float32),
            "team_pos": (auv + rng.normal(0.0, 0.28, auv.shape)).astype(np.float32),
            "target_pos": (target + rng.normal(0.0, 0.18, 2)).astype(np.float32),
            "target_vel": target_vel.astype(np.float32),
            "auv_vel": vel.astype(np.float32),
            "aoi": rng.uniform(0.0, 0.45, cfg.n_auv).astype(np.float32),
            "per": rng.uniform(0.0, 0.06, cfg.n_auv).astype(np.float32),
            "phase": np.array([rng.uniform()], dtype=np.float32),
            "control_ratio": np.array([0.70], dtype=np.float32),
        }
        action = expert_action_from_state(auv, vel, target, target_vel, cfg) / cfg.auv_max_speed
        x_rows.append(make_features(obs, cfg))
        y_rows.append(action.astype(np.float32))
    return np.concatenate(x_rows, 0)[:samples], np.concatenate(y_rows, 0)[:samples]


def train_backbone(
    output_path: Path,
    cfg: SimConfig,
    backbone: str = "td3",
    samples: int = 80_000,
    epochs: int = 55,
    seed: int = 0,
    device: Optional[str] = None,
) -> Dict[str, float]:
    torch.manual_seed(seed)
    np.random.seed(seed)
    device_obj = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    x, y = _synthetic_source_data(cfg, samples, seed)
    split = int(0.90 * len(x))
    x_train, y_train = torch.from_numpy(x[:split]), torch.from_numpy(y[:split])
    x_val, y_val = torch.from_numpy(x[split:]).to(device_obj), torch.from_numpy(y[split:]).to(device_obj)
    model: nn.Module = DeterministicBackbone() if backbone == "td3" else StochasticBackbone()
    model.to(device_obj)
    optimizer = torch.optim.AdamW(model.parameters(), lr=2.5e-3, weight_decay=1e-5)
    generator = torch.Generator().manual_seed(seed)
    batch_size = 1024
    start = time.perf_counter()
    model.train()
    for _ in range(epochs):
        order = torch.randperm(split, generator=generator)
        for start_idx in range(0, split, batch_size):
            idx = order[start_idx:start_idx + batch_size]
            xb = x_train[idx].to(device_obj, non_blocking=True)
            yb = y_train[idx].to(device_obj, non_blocking=True)
            if backbone == "td3":
                pred = model(xb)
                loss = F.smooth_l1_loss(pred, yb)
            else:
                pred, log_std = model(xb)
                inv_var = torch.exp(-2.0 * log_std)
                loss = torch.mean(0.5 * (pred - yb) ** 2 * inv_var + log_std)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
    model.eval()
    with torch.no_grad():
        pred = model(x_val)[0] if backbone != "td3" else model(x_val)
        val_mse = float(F.mse_loss(pred, y_val).cpu())
        val_mae = float(F.l1_loss(pred, y_val).cpu())
    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "backbone": backbone,
        "state_dict": model.state_dict(),
        "feature_dim": FEATURE_DIM,
        "n_auv": cfg.n_auv,
        "samples": samples,
        "epochs": epochs,
        "seed": seed,
        "val_mse": val_mse,
        "val_mae": val_mae,
    }, output_path)
    return {
        "val_mse": val_mse,
        "val_mae": val_mae,
        "train_seconds": time.perf_counter() - start,
        "parameters": float(sum(p.numel() for p in model.parameters())),
    }


class AdaptiveController:
    """Continuous-action STDW extension and full CAMPE policy evolution method."""

    def __init__(
        self,
        cfg: SimConfig,
        method: str,
        checkpoint: Path,
        seed: int = 0,
        ablation: str = "full",
        device: Optional[str] = None,
    ):
        self.cfg = cfg
        self.method = method
        self.ablation = ablation
        self.rng = np.random.default_rng(seed)
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        payload = torch.load(checkpoint, map_location=self.device, weights_only=False)
        self.backbone_name = payload["backbone"]
        self.backbone: nn.Module = DeterministicBackbone() if self.backbone_name == "td3" else StochasticBackbone()
        self.backbone.load_state_dict(payload["state_dict"])
        self.backbone.to(self.device).eval()
        self.ensemble_size = 5
        self.residual_ensemble = np.zeros((self.ensemble_size, 2), dtype=np.float64)
        self.effectiveness_ensemble = np.ones(self.ensemble_size, dtype=np.float64)
        self.adapter = np.zeros((8, 2), dtype=np.float64)
        self.adapter_gradient_ema = np.zeros_like(self.adapter)
        self.adapter_gradient_buffer = np.zeros_like(self.adapter)
        self.adapter_gradient_buffer_steps = 0
        self.anchor_adapter = self.adapter.copy()
        # Immutable source-domain memory used only when the source mode is
        # recognized again. The adaptive anchor below remains free to track
        # stable target-domain modes.
        self.source_anchor_adapter = self.adapter.copy()
        self.prev_action = np.zeros((cfg.n_auv, 2), dtype=np.float64)
        self.last_prediction: Optional[np.ndarray] = None
        self.last_predicted_score = 0.0
        self.last_obs: Optional[Dict[str, np.ndarray]] = None
        self.last_info: Optional[Dict[str, float]] = None
        self.step_id = 0
        self.drift_score = 0.0
        # Keep physical/model drift separate from communication degradation.
        # AoI/PER should inform reliability and control-plane scheduling, but a
        # pure packet-loss event must not be mistaken for changed AUV dynamics.
        self.model_drift_score = 0.0
        self.update_weight = 0.0
        self.action_jumps = []
        self.update_norms = []
        self.prediction_errors = []
        self.overestimation = []
        self.inference_times = []
        self.adaptation_times = []
        self.uncertainties = []
        self.drift_history = []
        self.model_drift_history = []
        self.weight_history = []
        self.kinematic_gate_history = []
        # Kinematic novelty is a persistent innovation, not absolute target
        # speed.  These observable-only filters distinguish a coherent change
        # of motion mode from fast but already-explained pursuit and packet
        # recovery jitter.
        self.target_velocity_ema: Optional[np.ndarray] = None
        self.target_innovation_ema = np.zeros(2, dtype=np.float64)
        self.target_innovation_scale = 0.0
        self.kinematic_novelty_score = 0.0
        self.kinematic_coherence_score = 0.0
        # Cross-sensor disagreement separates persistent localization faults
        # from genuine target manoeuvres.  The robust observer uses only the
        # same local/team/target packets available to every controller.
        self.sensor_disagreement_score = 0.0
        self.maneuver_pressure_score = 0.0
        self.robust_target_pos: Optional[np.ndarray] = None
        self.robust_target_vel: Optional[np.ndarray] = None
        self.sensor_gate_history = []
        self.maneuver_pressure_history = []
        self.fast_mode_history = []
        self.selected_candidates = []
        self.learning_active = 0.0

    def _backbone_action(self, obs: Dict[str, np.ndarray]) -> np.ndarray:
        feature = torch.from_numpy(make_features(obs, self.cfg)).to(self.device)
        with torch.inference_mode():
            out = self.backbone(feature)
            mean = out[0] if isinstance(out, tuple) else out
        return mean.detach().cpu().numpy().astype(np.float64) * self.cfg.auv_max_speed

    def _context(self, info: Dict[str, float], obs: Dict[str, np.ndarray]) -> np.ndarray:
        residual_mean = np.mean(self.residual_ensemble, axis=0)
        residual_std = np.std(self.residual_ensemble, axis=0)
        return np.array([
            residual_mean[0] / 1.5,
            residual_mean[1] / 1.5,
            residual_std[0] / 0.8,
            residual_std[1] / 0.8,
            info.get("risk", 0.5),
            float(np.mean(obs["aoi"])) / 4.0,
            float(np.mean(obs["per"])),
            1.0,
        ], dtype=np.float64)

    def _robust_observation(self, obs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Fuse redundant self/team packets and dead-reckon stale targets.

        A common localization bias is observable because the locally sensed AUV
        positions and the relayed team positions disagree coherently.  Removing
        that common mode before filtering the target prevents sensor faults from
        masquerading as target acceleration.  During packet outages, the same
        filter naturally becomes a bounded constant-velocity predictor.
        """

        gain = float(np.clip(self.cfg.robust_observer_gain, 0.0, 1.5))
        maneuver_gain = 0.0 if self.ablation == "no_kinematic_gate" else max(
            0.0,
            float(self.cfg.maneuver_gate_gain),
            float(self.cfg.maneuver_trust_gain),
        )
        if gain <= 0.0 and maneuver_gain <= 0.0:
            return obs

        filtered = copy.deepcopy(obs)
        own = np.asarray(obs["self_pos"], dtype=np.float64)
        team = np.asarray(obs["team_pos"], dtype=np.float64)
        mean_aoi = float(np.mean(obs["aoi"]))
        mean_per = float(np.mean(obs["per"]))
        reliability = math.exp(-mean_aoi / 2.6) * (1.0 - mean_per) ** 1.15

        disagreement_vectors = team - own
        common_bias = np.median(disagreement_vectors, axis=0)
        disagreement = float(np.median(np.linalg.norm(disagreement_vectors, axis=1)))
        delay_allowance = 0.85 + 0.90 * min(mean_aoi, 3.0)
        raw_sensor_gate = float(np.clip(
            (disagreement - delay_allowance) / 2.8,
            0.0,
            1.0,
        )) * reliability
        sensor_rate = 0.34 if raw_sensor_gate > self.sensor_disagreement_score else 0.08
        self.sensor_disagreement_score = float(np.clip(
            (1.0 - sensor_rate) * self.sensor_disagreement_score
            + sensor_rate * raw_sensor_gate,
            0.0,
            1.0,
        ))
        sensor_gate = float(np.clip(gain * self.sensor_disagreement_score, 0.0, 1.0))

        corrected_team = team - sensor_gate * common_bias[None, :]
        corrected_team = (
            (1.0 - 0.30 * sensor_gate) * corrected_team
            + 0.30 * sensor_gate * own
        )
        measured_target = (
            np.asarray(obs["target_pos"], dtype=np.float64)
            - 0.55 * sensor_gate * common_bias
        )
        measured_velocity = np.asarray(obs["target_vel"], dtype=np.float64)

        if self.robust_target_pos is None or self.robust_target_vel is None:
            self.robust_target_pos = measured_target.copy()
            self.robust_target_vel = measured_velocity.copy()
        else:
            predicted_target = self.robust_target_pos + self.cfg.dt * self.robust_target_vel
            position_innovation = measured_target - predicted_target
            max_innovation = 1.2 + 1.35 * self.cfg.target_max_speed * self.cfg.dt
            position_innovation = _clip_norm_np(
                position_innovation[None, :], max_innovation
            )[0]
            measurement_gain = float(np.clip(
                0.20 + 0.60 * reliability * (1.0 - 0.25 * sensor_gate),
                0.15,
                0.82,
            ))
            self.robust_target_pos = predicted_target + measurement_gain * position_innovation

            velocity_innovation = measured_velocity - self.robust_target_vel
            velocity_innovation = _clip_norm_np(
                velocity_innovation[None, :], 1.25 * self.cfg.target_max_speed
            )[0]
            velocity_gain = float(np.clip(
                0.12 + 0.42 * reliability * (1.0 - 0.35 * sensor_gate),
                0.10,
                0.58,
            ))
            self.robust_target_vel = _clip_norm_np(
                (self.robust_target_vel + velocity_gain * velocity_innovation)[None, :],
                self.cfg.target_max_speed,
            )[0]

        if self.last_obs is None:
            raw_pressure = 0.0
        else:
            previous_velocity = np.asarray(self.last_obs["target_vel"], dtype=np.float64)
            velocity_change = float(np.linalg.norm(
                self.robust_target_vel - previous_velocity
            )) / max(self.cfg.target_max_speed, 1e-6)
            raw_pressure = float(np.clip(
                (velocity_change - 0.025) / 0.22,
                0.0,
                1.0,
            )) * reliability * (1.0 - 0.88 * sensor_gate)
        maneuver_rate = 0.42 if raw_pressure > self.maneuver_pressure_score else 0.10
        self.maneuver_pressure_score = float(np.clip(
            (1.0 - maneuver_rate) * self.maneuver_pressure_score
            + maneuver_rate * raw_pressure,
            0.0,
            1.0,
        ))

        if gain > 0.0:
            filtered["team_pos"] = corrected_team.astype(np.float32)
            filtered["target_pos"] = self.robust_target_pos.astype(np.float32)
            filtered["target_vel"] = self.robust_target_vel.astype(np.float32)
        self.sensor_gate_history.append(sensor_gate)
        self.maneuver_pressure_history.append(self.maneuver_pressure_score)
        return filtered

    def _refresh_kinematic_novelty(self, obs: Dict[str, np.ndarray]) -> None:
        """Update a reliability-gated persistent target-velocity innovation.

        Absolute target speed is deliberately excluded: a fast target is not a
        new domain once its motion has been incorporated into the observer.  A
        coherent innovation relative to a slow velocity EMA is evidence of a
        mode change; incoherent deception and packet-recovery jumps have low
        directional coherence and are further suppressed by AoI/PER freshness.
        """

        if self.ablation == "no_kinematic_gate":
            self.kinematic_novelty_score = 0.0
            return

        velocity = np.asarray(obs["target_vel"], dtype=np.float64)
        if self.target_velocity_ema is None:
            self.target_velocity_ema = velocity.copy()
            self.kinematic_novelty_score = 0.0
            return

        speed_scale = max(self.cfg.target_max_speed, 1e-6)
        innovation = (velocity - self.target_velocity_ema) / speed_scale
        innovation_norm = float(np.linalg.norm(innovation))
        self.target_velocity_ema = 0.88 * self.target_velocity_ema + 0.12 * velocity
        self.target_innovation_ema = (
            0.76 * self.target_innovation_ema + 0.24 * innovation
        )
        self.target_innovation_scale = (
            0.76 * self.target_innovation_scale + 0.24 * innovation_norm
        )

        coherent_norm = float(np.linalg.norm(self.target_innovation_ema))
        coherence = coherent_norm / max(self.target_innovation_scale + 0.025, 1e-6)
        self.kinematic_coherence_score = float(np.clip(
            0.78 * self.kinematic_coherence_score + 0.22 * coherence,
            0.0,
            1.0,
        ))
        persistent_change = float(np.clip(
            (coherent_norm - 0.018) / 0.115,
            0.0,
            1.0,
        ))
        mean_aoi = float(np.mean(obs["aoi"]))
        mean_per = float(np.mean(obs["per"]))
        reliability = math.exp(-mean_aoi / 1.8) * (1.0 - mean_per) ** 1.35
        freshness = float(np.clip((1.55 - mean_aoi) / 1.25, 0.0, 1.0))
        raw_score = float(np.clip(
            persistent_change * coherence * reliability * freshness,
            0.0,
            1.0,
        ))
        # Fast attack catches a genuine transition; slow release avoids mode
        # chatter without allowing a single packet recovery to dominate a run.
        rate = 0.38 if raw_score > self.kinematic_novelty_score else 0.09
        self.kinematic_novelty_score = float(np.clip(
            (1.0 - rate) * self.kinematic_novelty_score + rate * raw_score,
            0.0,
            1.0,
        ))

    def _kinematic_novelty(self, obs: Dict[str, np.ndarray]) -> float:
        del obs
        if self.ablation == "no_kinematic_gate":
            return 0.0
        return float(np.clip(max(
            self.kinematic_novelty_score,
            self.cfg.maneuver_gate_gain * self.maneuver_pressure_score,
        ), 0.0, 1.0))

    def _fast_mode_score(self) -> float:
        signal = max(
            self.kinematic_novelty_score,
            self.maneuver_pressure_score,
            self.sensor_disagreement_score,
        )
        return float(np.clip(
            self.cfg.fast_mode_gain
            * (signal - self.cfg.fast_mode_threshold)
            / max(self.cfg.fast_mode_width, 0.05),
            0.0,
            1.0,
        ))

    def _candidate_actions(self, base: np.ndarray, obs: Dict[str, np.ndarray], info: Dict[str, float]) -> np.ndarray:
        estimate = np.mean(self.residual_ensemble, axis=0)
        context = self._context(info, obs)
        adapter_residual = context @ self.adapter * self.cfg.auv_max_speed
        compensated = base - estimate[None, :] + adapter_residual[None, :]
        angles = (-0.28, -0.14, 0.0, 0.14, 0.28)
        guard = self._formation_guard_action(obs)
        guard_compensated = guard - estimate[None, :]
        candidates = [
            base,
            base - 0.42 * estimate[None, :],
            base - 0.65 * estimate[None, :],
            compensated,
            0.68 * compensated + 0.32 * self.prev_action,
            guard,
            guard_compensated,
            0.72 * guard_compensated + 0.28 * compensated,
        ]
        for angle in angles:
            rot = np.array([[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]])
            candidates.append(compensated @ rot.T)
        target = np.asarray(obs["target_pos"])
        own = np.asarray(obs["self_pos"])
        radial = own - target
        radii = np.linalg.norm(radial, axis=1, keepdims=True)
        correction = -(radii - self.cfg.desired_radius) * radial / np.maximum(radii, 1e-6)
        candidates.extend([compensated + 0.20 * correction, compensated + 0.38 * correction])
        effectiveness = float(np.clip(np.mean(self.effectiveness_ensemble), 0.45, 1.0))
        candidates.extend([
            base / effectiveness,
            (base - 0.42 * estimate[None, :]) / effectiveness,
            guard / effectiveness,
        ])
        return _clip_norm_np(np.stack(candidates, axis=0), self.cfg.auv_max_speed)

    def _formation_guard_action(
        self,
        obs: Dict[str, np.ndarray],
        *,
        use_mode_priors: bool = True,
    ) -> np.ndarray:
        """Order-preserving predictive ring controller used as a safe candidate.

        It uses only the same delayed cache as the learned actor. Preserving the
        cyclic order avoids the slot swaps and action discontinuities produced by
        reassigning AUV identities whenever the target changes heading.
        """
        cfg = self.cfg
        own = np.asarray(obs["self_pos"], dtype=np.float64)
        target = np.asarray(obs["target_pos"], dtype=np.float64)
        target_vel = np.asarray(obs["target_vel"], dtype=np.float64)
        mean_aoi = float(np.mean(obs["aoi"]))
        lead_time = float(np.clip(0.75 + 1.10 * mean_aoi, 0.65, 2.3))
        incoherent_manoeuvre = float(np.clip(
            self.maneuver_pressure_score
            * (1.0 - self.kinematic_coherence_score)
            * (1.0 - 0.85 * self.sensor_disagreement_score),
            0.0,
            1.0,
        ))
        lead_time *= 1.0 - 0.65 * incoherent_manoeuvre
        target_future = target + lead_time * target_vel
        kinematic_feedforward = 0.0
        mode_priors_active = (
            use_mode_priors
            and self.method == "campe"
            and self.ablation != "no_mode_priors"
        )
        if (mode_priors_active and
                self.last_obs is not None):
            kinematic_feedforward = self._kinematic_novelty(obs)
            previous_target_vel = np.asarray(self.last_obs["target_vel"], dtype=np.float64)
            target_accel = (target_vel - previous_target_vel) / max(cfg.dt, 1e-6)
            target_accel = _clip_norm_np(target_accel[None, :], 0.75)[0]
            target_future += (
                0.035
                + self.cfg.kinematic_accel_feedforward_gain
                * kinematic_feedforward
            ) * (1.0 - 0.95 * incoherent_manoeuvre) * lead_time ** 2 * target_accel
        rel = own - target
        angles = np.mod(np.arctan2(rel[:, 1], rel[:, 0]), 2.0 * math.pi)
        order = np.argsort(angles)
        unwrapped = np.unwrap(angles[order])
        anchors = unwrapped - np.arange(cfg.n_auv) * ideal_gap(cfg.n_auv)
        anchor = float(np.median(anchors))
        desired_angles_sorted = anchor + np.arange(cfg.n_auv) * ideal_gap(cfg.n_auv)
        desired = np.zeros_like(own)
        desired[order] = target_future + cfg.desired_radius * np.stack(
            [np.cos(desired_angles_sorted), np.sin(desired_angles_sorted)], axis=1
        )
        slot_gain = (
            0.92
            + self.cfg.kinematic_slot_gain * kinematic_feedforward
            + 0.38 * incoherent_manoeuvre
        )
        command = target_vel[None, :] + slot_gain * (desired - own) - 0.20 * np.asarray(obs["auv_vel"])
        if mode_priors_active:
            command -= 0.38 * np.mean(self.residual_ensemble, axis=0)[None, :]
        pair = own[:, None, :] - own[None, :, :]
        dist = np.linalg.norm(pair + np.eye(cfg.n_auv)[:, :, None] * 1e6, axis=2)
        for i in range(cfg.n_auv):
            for j in np.where(dist[i] < cfg.safety_distance * 1.25)[0]:
                command[i] += 1.65 * (cfg.safety_distance * 1.25 - dist[i, j]) * pair[i, j] / max(dist[i, j], 1e-6)
        return _clip_norm_np(command, cfg.auv_max_speed)

    def _score_candidates(
        self,
        candidates: np.ndarray,
        obs: Dict[str, np.ndarray],
        info: Dict[str, float],
    ) -> Tuple[int, float, float]:
        cfg = self.cfg
        device = self.device
        cand = torch.as_tensor(candidates, dtype=torch.float32, device=device)  # K,N,2
        own = torch.as_tensor(obs["self_pos"], dtype=torch.float32, device=device)
        vel = torch.as_tensor(obs["auv_vel"], dtype=torch.float32, device=device)
        target = torch.as_tensor(obs["target_pos"], dtype=torch.float32, device=device)
        target_vel = torch.as_tensor(obs["target_vel"], dtype=torch.float32, device=device)
        use_ensemble = self.ablation != "no_ensemble" and self.method == "campe"
        if not use_ensemble:
            residuals = np.mean(self.residual_ensemble, axis=0, keepdims=True)
            effects = np.mean(self.effectiveness_ensemble, keepdims=True)
        else:
            residuals = np.concatenate([
                np.mean(self.residual_ensemble, axis=0, keepdims=True),
                self.residual_ensemble,
            ], axis=0)
            effects = np.concatenate([
                np.mean(self.effectiveness_ensemble, keepdims=True),
                self.effectiveness_ensemble,
            ], axis=0)
        residual = torch.as_tensor(residuals, dtype=torch.float32, device=device)[:, None, None, :]
        effect = torch.as_tensor(effects, dtype=torch.float32, device=device)[:, None, None, None]
        pred = own[None, None, :, :].expand(len(residuals), len(candidates), -1, -1).clone()
        pred_vel = vel[None, None, :, :].expand_as(pred).clone()
        radius_cost = torch.zeros((len(residuals), len(candidates)), device=device)
        gap_cost = torch.zeros_like(radius_cost)
        safety_cost = torch.zeros_like(radius_cost)
        # Score candidates over the configured predictive horizon.  This makes
        # persistent-current compensation visible to the selector and ensures
        # the horizon sensitivity experiment changes the actual controller.
        horizon = max(1, int(cfg.prediction_horizon))
        for h in range(1, horizon + 1):
            pred_vel = 0.66 * pred_vel + 0.34 * effect * cand[None, :, :, :]
            pred = pred + cfg.dt * (pred_vel + residual)
            target_pred = target + h * cfg.dt * target_vel
            rel = pred - target_pred[None, None, None, :]
            radius = torch.linalg.norm(rel, dim=-1)
            radius_cost += torch.mean(torch.abs(radius - cfg.desired_radius), dim=-1) / cfg.desired_radius
            angles = torch.atan2(rel[..., 1], rel[..., 0])
            angles, _ = torch.sort(torch.remainder(angles, 2.0 * math.pi), dim=-1)
            gaps = torch.diff(torch.cat([angles, angles[..., :1] + 2.0 * math.pi], dim=-1), dim=-1)
            gap_cost += torch.amax(gaps, dim=-1) / ideal_gap(cfg.n_auv) - 1.0
            pair = pred[..., :, None, :] - pred[..., None, :, :]
            pdist = torch.linalg.norm(pair + torch.eye(cfg.n_auv, device=device)[None, None, :, :, None] * 1e6, dim=-1)
            min_dist = torch.amin(pdist, dim=(-1, -2))
            margin = cfg.collision_distance
            if self.ablation != "no_margin":
                margin += float(np.clip(cfg.safety_margin_fraction, 0.0, 1.0)) * (
                    cfg.safety_distance - cfg.collision_distance
                )
            safety_cost += torch.relu(margin - min_dist) / margin
        radius_cost /= horizon
        gap_cost /= horizon
        safety_cost /= horizon
        energy = torch.mean(torch.linalg.norm(cand, dim=-1) ** 2, dim=-1)[None, :] / cfg.auv_max_speed ** 2
        q = -(1.70 * radius_cost + 1.65 * torch.relu(gap_cost) + 3.0 * safety_cost + 0.10 * energy)
        if self.method == "campe" and self.ablation != "no_mode_priors":
            # A coherent additive residual with little effectiveness loss is the
            # observable signature of a persistent current.  In that regime a
            # physics-derived partial compensation is a safer prior than an
            # aggressively re-slotted formation guard.  The gate vanishes for
            # weak/noisy residuals and multiplicative thruster degradation.
            residual_mean = np.mean(self.residual_ensemble, axis=0)
            residual_norm = float(np.linalg.norm(residual_mean))
            residual_spread = float(np.mean(np.linalg.norm(
                self.residual_ensemble - residual_mean[None, :], axis=1
            )))
            effect_shift = abs(1.0 - float(np.mean(self.effectiveness_ensemble)))
            coherence = residual_norm / (residual_norm + residual_spread + 0.15)
            kinematic_gate = self._kinematic_novelty(obs)
            additive_gate = (
                float(np.clip((residual_norm - 0.30) / 0.80, 0.0, 1.0)) *
                coherence *
                float(np.clip(1.0 - effect_shift / 0.40, 0.0, 1.0)) *
                (1.0 - 0.22 * kinematic_gate) *
                float(np.clip(1.0 - info.get("risk", 0.5) / 1.15, 0.0, 1.0))
            )
            current_anchor = cand[1]
            anchor_deviation = torch.mean(
                torch.linalg.norm(cand - current_anchor[None, :, :], dim=-1) ** 2,
                dim=-1,
            )[None, :] / cfg.auv_max_speed ** 2
            q = q - 0.25 * additive_gate * anchor_deviation
            # Joint shifts are compositional: a target manoeuvre can coexist
            # with current and actuator degradation.  Soft competition retains
            # every supported prior instead of forcing a brittle one-hot mode.
            kinematic_mode_gate = (
                kinematic_gate * (1.0 - 0.28 * additive_gate)
            )
            guard_anchors = cand[5:8]
            guard_deviation = torch.amin(
                torch.mean(
                    torch.linalg.norm(
                        cand[:, None, :, :] - guard_anchors[None, :, :, :],
                        dim=-1,
                    ) ** 2,
                    dim=-1,
                ),
                dim=1,
            )[None, :] / cfg.auv_max_speed ** 2
            q = (
                q
                - self.cfg.kinematic_candidate_prior_weight
                * kinematic_mode_gate
                * guard_deviation
            )
            multiplicative_gate = (
                float(np.clip((effect_shift - 0.12) / 0.25, 0.0, 1.0)) *
                (1.0 - 0.25 * kinematic_gate)
            )
            effect_anchor = cand[15]
            effect_deviation = torch.mean(
                torch.linalg.norm(cand - effect_anchor[None, :, :], dim=-1) ** 2,
                dim=-1,
            )[None, :] / cfg.auv_max_speed ** 2
            q = q - 0.55 * multiplicative_gate * effect_deviation
        if use_ensemble:
            nominal_q = q[0]
            ensemble_q = q[1:]
            q_mean = torch.mean(ensemble_q, dim=0)
            q_std = torch.std(ensemble_q, dim=0, unbiased=False)
        else:
            nominal_q = q[0]
            q_mean = nominal_q
            q_std = torch.zeros_like(q_mean)
        uncertainty_scale = (
            0.0
            if self.ablation == "no_uncertainty"
            else (self.cfg.uncertainty_scale if self.method == "campe" else 0.15)
        )
        # The rollout under the mean dynamics is already the central ensemble
        # model.  Apply a calibrated LCB only outside the low-variance dead zone;
        # otherwise tiny nonlinear Jensen shifts can flip near-tied actions even
        # though the ensemble is effectively confident.
        excess_uncertainty = torch.relu(q_std - self.cfg.uncertainty_deadzone)
        conservative_q = nominal_q - uncertainty_scale * excess_uncertainty
        idx = int(torch.argmax(conservative_q).item())
        if self.ablation == "no_uncertainty":
            return idx, float(q_mean[idx].item()), 0.0
        return idx, float(conservative_q[idx].item()), float(q_std[idx].item())

    def _safety_project(self, action: np.ndarray, obs: Dict[str, np.ndarray]) -> np.ndarray:
        if self.ablation == "no_safety" or self.method not in {"campe", "domain_randomization"}:
            return _clip_norm_np(action, self.cfg.auv_max_speed)
        cfg = self.cfg
        own = np.asarray(obs["self_pos"], dtype=np.float64)
        result = action.copy()
        predicted = own + cfg.dt * (
            0.45 * np.asarray(obs["auv_vel"], dtype=np.float64) + 0.55 * result
        )
        pair = own[:, None, :] - own[None, :, :]
        predicted_pair = predicted[:, None, :] - predicted[None, :, :]
        dist = np.linalg.norm(pair + np.eye(cfg.n_auv)[:, :, None] * 1e6, axis=2)
        predicted_dist = np.linalg.norm(
            predicted_pair + np.eye(cfg.n_auv)[:, :, None] * 1e6,
            axis=2,
        )
        for i in range(cfg.n_auv):
            for j in range(i + 1, cfg.n_auv):
                hard_violation = dist[i, j] < cfg.collision_distance + 0.6
                approaching_margin = (
                    predicted_dist[i, j] < cfg.safety_distance and
                    predicted_dist[i, j] < dist[i, j] + 0.05
                )
                if not (hard_violation or approaching_margin):
                    continue
                direction = pair[i, j] / max(dist[i, j], 1e-6)
                deficit = max(
                    cfg.safety_distance - predicted_dist[i, j],
                    cfg.collision_distance + 0.6 - dist[i, j],
                    0.0,
                )
                correction = 0.92 * deficit * direction
                result[i] += correction
                result[j] -= correction
        for i in range(cfg.n_auv):
            margin = 8.0
            result[i] += np.where(own[i] < margin, (margin - own[i]) * 0.55, 0.0)
            result[i] -= np.where(own[i] > cfg.arena_size - margin,
                                  (own[i] - (cfg.arena_size - margin)) * 0.55, 0.0)
        return _clip_norm_np(result, cfg.auv_max_speed)

    def act(self, obs: Dict[str, np.ndarray], info: Dict[str, float]) -> np.ndarray:
        t0 = time.perf_counter()
        if self.method == "campe":
            obs = self._robust_observation(obs)
            self._refresh_kinematic_novelty(obs)
        base = self._backbone_action(obs)
        action = base.copy()
        self.learning_active = 0.0

        if self.method == "domain_randomization":
            action = base - 0.42 * np.mean(self.residual_ensemble, axis=0)[None, :]
        elif self.method == "direct_finetune":
            context = self._context(info, obs)
            action = base - 0.78 * np.mean(self.residual_ensemble, axis=0)[None, :]
            action += (context @ self.adapter)[None, :] * self.cfg.auv_max_speed
            self.learning_active = 1.0
        elif self.method == "stdw":
            # Original STDW analogue: fixed progress interpolation and source-policy
            # pseudo-actions. It cannot explicitly model transition or safety shift.
            phase_weight = min(1.0, self.step_id / max(1, self.cfg.max_steps - 1))
            weak = base - 0.32 * np.mean(self.residual_ensemble, axis=0)[None, :]
            action = (1.0 - phase_weight) * base + phase_weight * weak
            self.update_weight = phase_weight
            self.learning_active = float(phase_weight > 0.15)
        elif self.method in {"ctta", "campe"}:
            candidates = self._candidate_actions(base, obs, info)
            idx, predicted, uncertainty = self._score_candidates(candidates, obs, info)
            pseudo = candidates[idx]
            self.selected_candidates.append(idx)
            reliability = math.exp(-float(np.mean(obs["aoi"])) / 2.8) * (1.0 - float(np.mean(obs["per"])))
            confidence = math.exp(-2.2 * max(0.0, uncertainty - 0.10))
            stability = max(0.15, 1.0 - 0.75 * info.get("risk", 0.5))
            activation = 1.0
            kinematic_gate = (
                self._kinematic_novelty(obs)
                if self.method == "campe" else 0.0
            )
            fast_mode = self._fast_mode_score() if self.method == "campe" else 0.0
            communication_gate = 0.0
            if (self.method == "campe" and
                    self.ablation != "no_drift_separation"):
                observed_communication_drift = (
                    0.72 * float(np.mean(obs["per"])) +
                    0.12 * float(np.mean(obs["aoi"]))
                )
                communication_gate = float(np.clip(
                    (observed_communication_drift - 0.16) / 0.52,
                    0.0,
                    1.0,
                ))
            if self.method == "campe":
                self.kinematic_gate_history.append(kinematic_gate)
            radial_urgency = float(np.clip(
                (info.get("radius_error", 0.0) - 0.65 * self.cfg.radial_tolerance) /
                max(1.35 * self.cfg.radial_tolerance, 1e-6),
                0.0,
                1.0,
            ))
            gap_urgency = float(np.clip(
                (info.get("max_gap", ideal_gap(self.cfg.n_auv)) /
                 ideal_gap(self.cfg.n_auv) - 1.10) / 0.85,
                0.0,
                1.0,
            ))
            inside_urgency = 1.0 - float(np.clip(info.get("target_inside", 1.0), 0.0, 1.0))
            escape_urgency = float(np.clip((info.get("risk", 0.5) - 0.38) / 0.42, 0.0, 1.0))
            formation_urgency = max(
                0.82 * radial_urgency,
                0.90 * gap_urgency,
                0.95 * inside_urgency,
                escape_urgency,
            )
            communication_recovery = communication_gate * max(
                0.45,
                formation_urgency,
                escape_urgency,
            )
            if self.method == "campe" and self.ablation != "no_dynamic_weight":
                physical_drift = self.drift_score if self.ablation == "no_drift_separation" else self.model_drift_score
                evolution_pressure = 0.14 * min(physical_drift, 1.0) * reliability
                communication_penalty = 0.06 * float(np.mean(obs["per"])) + 0.012 * float(np.mean(obs["aoi"]))
                raw_weight = float(np.clip(
                    0.72 + 0.12 * reliability * confidence * stability + evolution_pressure - communication_penalty,
                    0.46,
                    0.95,
                ))
                anchor_scale = max(self.cfg.anchor_threshold, 0.05)
                drift_gate = float(np.clip(
                    (physical_drift - 0.65 * anchor_scale) /
                    (0.16 + 0.15 * anchor_scale),
                    0.0,
                    1.0,
                ))
                risk_gate = float(np.clip((info.get("risk", 0.5) - 0.48) / 0.34, 0.0, 1.0))
                # Recognized kinematic changes are handled by the explicit mode
                # prior below; the adapter is reserved for unexplained residuals.
                activation = max(
                    drift_gate,
                    0.22 * kinematic_gate,
                    0.10 * risk_gate,
                    0.78 * formation_urgency,
                )
                self.update_weight = (1.0 - activation) * 0.03 + activation * raw_weight
                maneuver_update_gate = kinematic_gate
                if self.cfg.maneuver_update_formation_gate:
                    # A recognized target manoeuvre is already handled by the
                    # explicit control/guard prior.  Spend adapter updates only
                    # when the manoeuvre still creates formation risk, instead
                    # of repeatedly learning an explained mode in stable rings.
                    risk_floor = float(np.clip(
                        self.cfg.maneuver_update_risk_floor, 0.0, 1.0
                    ))
                    if self.cfg.maneuver_update_model_gate:
                        # Target acceleration is handled analytically by the
                        # kinematic prior.  A parameter update is still useful
                        # when the vehicle-dynamics observer reports an
                        # independent residual (current/thruster shift), or
                        # when the ring geometry is already deteriorating.
                        # This separates adversarial joint shifts from a clean
                        # recurrent target manoeuvre without using latent
                        # scenario labels.
                        model_gate = float(np.clip(
                            (
                                self.model_drift_score
                                - self.cfg.maneuver_update_model_threshold
                            ) / max(self.cfg.maneuver_update_model_width, 0.02),
                            0.0,
                            1.0,
                        ))
                        unexplained_need = max(formation_urgency, model_gate)
                    else:
                        pressure_gate = float(np.clip(
                            (
                                self.maneuver_pressure_score
                                - self.cfg.maneuver_update_pressure_threshold
                            ) / max(self.cfg.maneuver_update_pressure_width, 0.02),
                            0.0,
                            1.0,
                        ))
                        unexplained_need = max(formation_urgency, pressure_gate)
                    unexplained_need = float(np.clip(
                        (
                            unexplained_need
                            - self.cfg.maneuver_update_need_threshold
                        ) / max(self.cfg.maneuver_update_need_width, 0.05),
                        0.0,
                        1.0,
                    ))
                    maneuver_update_gate *= (
                        risk_floor + (1.0 - risk_floor) * unexplained_need
                    )
                self.update_weight = max(
                    self.update_weight,
                    formation_urgency * (0.62 + 0.18 * reliability),
                    0.24 * kinematic_gate,
                    self.cfg.maneuver_update_gain * maneuver_update_gate,
                    0.78 * fast_mode,
                )
            else:
                self.update_weight = 0.78 if self.method == "ctta" else 0.68
            if self.method == "campe":
                gated_control = activation * max(
                    self.update_weight,
                    0.58 + 0.27 * info.get("risk", 0.5),
                )
                kinematic_control = 0.90 * float(np.clip(kinematic_gate / 0.80, 0.0, 1.0))
                control_weight = max(
                    gated_control,
                    kinematic_control,
                    0.82 * formation_urgency,
                    0.92 * communication_recovery,
                    0.84 * fast_mode,
                )
            else:
                control_weight = self.update_weight
            action = (1.0 - control_weight) * base + control_weight * pseudo
            if self.method == "campe" and self.ablation != "no_mode_priors":
                guard = self._formation_guard_action(obs)
                guard_mix = float(np.clip(
                    formation_urgency * (0.70 + 0.25 * reliability),
                    0.0,
                    0.92,
                ))
                kinematic_guard_mix = float(np.clip(
                    self.cfg.kinematic_guard_mix_gain
                    * (kinematic_gate - 0.14) / 0.46,
                    0.0,
                    min(0.88, self.cfg.kinematic_guard_mix_gain),
                )) * (0.35 + 0.65 * formation_urgency)
                guard_mix = max(
                    guard_mix,
                    kinematic_guard_mix,
                    float(np.clip(0.84 * communication_recovery, 0.0, 0.84)),
                )
                action = (1.0 - guard_mix) * action + guard_mix * guard
                # Once the ring is close to the strict feasible set, switch from
                # aggressive recovery to a damped invariant-set controller. This
                # suppresses chattering and makes the continuous hold criterion a
                # genuine closed-loop property rather than a lucky threshold hit.
                radial_quality = float(np.clip(
                    (1.25 * self.cfg.radial_tolerance - info.get("radius_error", 0.0)) /
                    max(0.75 * self.cfg.radial_tolerance, 1e-6),
                    0.0,
                    1.0,
                ))
                gap_quality = float(np.clip(
                    (1.45 * ideal_gap(self.cfg.n_auv) -
                     info.get("max_gap", 2.0 * math.pi)) /
                    max(0.40 * ideal_gap(self.cfg.n_auv), 1e-6),
                    0.0,
                    1.0,
                ))
                inside_quality = float(np.clip(info.get("target_inside", 0.0), 0.0, 1.0))
                risk_quality = float(np.clip(
                    (0.72 - info.get("risk", 1.0)) / 0.42,
                    0.0,
                    1.0,
                ))
                precision_gate = min(
                    radial_quality,
                    gap_quality,
                    inside_quality,
                    risk_quality,
                )
                precision_mix = 0.78 * precision_gate * (0.74 + 0.26 * reliability)
                precision_mix *= 1.0 - 0.72 * fast_mode
                precision_action = _clip_norm_np(
                    0.84 * guard + 0.16 * self.prev_action,
                    self.cfg.auv_max_speed,
                )
                action = (1.0 - precision_mix) * action + precision_mix * precision_action
                if self.cfg.fast_expert_blend > 0.0 and fast_mode > 0.0:
                    nominal_guard = self._formation_guard_action(
                        obs,
                        use_mode_priors=False,
                    )
                    fast_action = 0.22 * base + 0.78 * nominal_guard
                    expert_gate = float(np.clip(
                        self.cfg.fast_expert_blend
                        * fast_mode
                        * (0.25 + 0.75 * formation_urgency),
                        0.0,
                        1.0,
                    ))
                    action = (
                        (1.0 - expert_gate) * action
                        + expert_gate * fast_action
                    )
            self.last_predicted_score = predicted
            self.uncertainties.append(uncertainty)
            if self.method == "campe":
                self.fast_mode_history.append(fast_mode)
            self.learning_active = float(self.update_weight > 0.12)
            if self.method == "campe" and self.drift_score > 0.95 and uncertainty > 0.20:
                # Large untrusted shifts first trigger conservative control.
                guard = self._formation_guard_action(obs)
                action = 0.85 * self._safety_project(guard, obs) + 0.15 * action

        action = self._safety_project(action, obs)
        if self.method == "campe" and self.ablation != "no_trust_region":
            trust_reference = self.prev_action
            if self.cfg.kinematic_trust_reference_gain > 0.0:
                reference_gate = float(np.clip(
                    self.cfg.kinematic_trust_reference_gain
                    * self._kinematic_novelty(obs)
                    * (0.25 + 0.75 * formation_urgency),
                    0.0,
                    0.82,
                ))
                safe_reference = self._safety_project(
                    self._formation_guard_action(obs),
                    obs,
                )
                trust_reference = (
                    (1.0 - reference_gate) * self.prev_action
                    + reference_gate * safe_reference
                )
            trust_radius = (
                self.cfg.action_trust_base
                + self.cfg.action_trust_risk_gain
                * float(np.clip(info.get("risk", 0.5), 0.0, 1.0))
                + self.cfg.action_trust_formation_gain * formation_urgency
                + self.cfg.maneuver_trust_gain * self.maneuver_pressure_score
                + self.cfg.kinematic_action_trust_gain
                * self._kinematic_novelty(obs)
                + self.cfg.fast_mode_trust_gain * self._fast_mode_score()
            )
            delta = _clip_norm_np(action - trust_reference, trust_radius)
            action = trust_reference + delta
        action = _clip_norm_np(action, self.cfg.auv_max_speed)
        self.action_jumps.append(float(np.mean(np.linalg.norm(action - self.prev_action, axis=1))))
        mean_residual = np.mean(self.residual_ensemble, axis=0)
        effect = float(np.mean(self.effectiveness_ensemble))
        own = np.asarray(obs["self_pos"], dtype=np.float64)
        velocity = np.asarray(obs["auv_vel"], dtype=np.float64)
        self.last_prediction = own + self.cfg.dt * (0.66 * velocity + 0.34 * effect * action + mean_residual)
        self.prev_action = action.copy()
        self.last_obs = copy.deepcopy(obs)
        self.last_info = dict(info)
        self.inference_times.append(time.perf_counter() - t0)
        return action

    def feedback(
        self,
        obs: Dict[str, np.ndarray],
        next_obs: Dict[str, np.ndarray],
        action: np.ndarray,
        next_info: Dict[str, float],
    ) -> None:
        t0 = time.perf_counter()
        cfg = self.cfg
        observed_velocity = (np.asarray(next_obs["self_pos"]) - np.asarray(obs["self_pos"])) / cfg.dt
        prior_velocity = np.asarray(obs["auv_vel"])
        predicted_body = 0.66 * prior_velocity + 0.34 * action
        residual_samples = observed_velocity - predicted_body
        robust_residual = np.median(residual_samples, axis=0)
        if self.method == "campe":
            robust_residual = _clip_norm_np(robust_residual[None, :], 1.60)[0]
        command_norm = np.linalg.norm(action, axis=1)
        valid = command_norm > 0.6
        if np.any(valid):
            projection = np.sum((observed_velocity[valid] - robust_residual) * action[valid], axis=1)
            denominator = command_norm[valid] ** 2 + 1e-5
            effect_observation = float(np.clip(np.median(projection / denominator), 0.35, 1.25))
        else:
            effect_observation = 1.0
        rates = np.array([0.035, 0.055, 0.080, 0.120, 0.180])
        if self.method == "source_only":
            rates *= 0.0
        elif self.method == "domain_randomization":
            rates *= 0.40
        elif self.method == "stdw":
            rates *= 0.55
        elif self.method == "direct_finetune":
            rates *= 1.45
        for i, rate in enumerate(rates):
            jitter = self.rng.normal(0.0, 0.015, 2)
            self.residual_ensemble[i] = (1.0 - rate) * self.residual_ensemble[i] + rate * (robust_residual + jitter)
            self.effectiveness_ensemble[i] = (1.0 - rate) * self.effectiveness_ensemble[i] + rate * effect_observation

        residual_norm = float(np.linalg.norm(np.mean(self.residual_ensemble, axis=0)))
        effect_shift = abs(1.0 - float(np.mean(self.effectiveness_ensemble)))
        comm_shift = 0.65 * float(np.mean(next_obs["per"])) + 0.10 * float(np.mean(next_obs["aoi"]))
        instant_model_drift = np.clip(0.72 * residual_norm + 0.95 * effect_shift, 0.0, 1.5)
        instant_drift = np.clip(instant_model_drift + comm_shift, 0.0, 1.5)
        drift_alpha = float(np.clip(2.0 / max(4, self.cfg.window), 0.035, 0.22))
        model_observation = (
            instant_drift
            if self.method == "campe" and self.ablation == "no_drift_separation"
            else instant_model_drift
        )
        self.model_drift_score = (
            (1.0 - drift_alpha) * self.model_drift_score + drift_alpha * float(model_observation)
        )
        self.drift_score = (1.0 - drift_alpha) * self.drift_score + drift_alpha * float(instant_drift)

        if self.last_prediction is not None:
            error = float(np.mean(np.linalg.norm(self.last_prediction - np.asarray(next_obs["self_pos"]), axis=1)))
            self.prediction_errors.append(error)
        if self.method in {"ctta", "campe", "direct_finetune"}:
            base_obs = (
                self.last_obs
                if self.method == "campe" and self.last_obs is not None
                else obs
            )
            base = self._backbone_action(base_obs)
            context = self._context(next_info, next_obs)
            pseudo_residual = np.mean(action - base, axis=0) / cfg.auv_max_speed
            weight = self.update_weight if self.method != "direct_finetune" else 0.80
            if (self.method == "campe" and self.ablation != "no_mode_priors"):
                # Closed-form mode priors explain reliable target manoeuvres in
                # control space, avoiding redundant gradient updates.
                fast_mode = self._fast_mode_score()
                weight *= 1.0 - (
                    self.cfg.mode_adapter_suppression
                    * (1.0 - fast_mode)
                    * self._kinematic_novelty(obs)
                )
            if (
                self.method == "campe"
                and self.ablation != "no_trust_region"
                and self.cfg.kinematic_trust_update_damping > 0.0
            ):
                # The analytic mode prior supplies the fast response.  Within
                # the trust region, gradient adaptation is a residual channel,
                # so damp only the explained kinematic component instead of
                # repeatedly chasing it in parameter space.
                weight *= 1.0 - float(np.clip(
                    self.cfg.kinematic_trust_update_damping
                    * self._kinematic_novelty(obs),
                    0.0,
                    0.75,
                ))
            old = self.adapter.copy()
            prediction = context @ self.adapter
            gradient = np.outer(context, prediction - pseudo_residual)
            if (
                self.method == "campe"
                and self.ablation != "no_kinematic_gate"
                and self.cfg.maneuver_gradient_ema_decay > 0.0
            ):
                decay = float(np.clip(
                    self.cfg.maneuver_gradient_ema_decay, 0.0, 0.98
                ))
                self.adapter_gradient_ema = (
                    decay * self.adapter_gradient_ema
                    + (1.0 - decay) * gradient
                )
                smoothing_gate = float(np.clip(
                    (
                        self._kinematic_novelty(obs)
                        - self.cfg.maneuver_gradient_ema_threshold
                    ) / max(self.cfg.maneuver_gradient_ema_width, 0.03),
                    0.0,
                    1.0,
                ))
                gradient = (
                    (1.0 - smoothing_gate) * gradient
                    + smoothing_gate * self.adapter_gradient_ema
                )
            lr = 0.090 if self.method == "campe" else 0.085
            weighted_gradient: Optional[np.ndarray] = weight * gradient
            batch_steps = 1
            batch_size = max(1, int(self.cfg.kinematic_update_batch))
            if (
                self.method == "campe"
                and self.ablation != "no_kinematic_gate"
                and batch_size > 1
            ):
                novelty = self._kinematic_novelty(obs)
                batching_active = (
                    novelty >= self.cfg.kinematic_update_batch_threshold
                )
                if batching_active or self.adapter_gradient_buffer_steps > 0:
                    self.adapter_gradient_buffer += weighted_gradient
                    self.adapter_gradient_buffer_steps += 1
                    flush = (
                        self.adapter_gradient_buffer_steps >= batch_size
                        or not batching_active
                        or self.step_id >= self.cfg.max_steps - 2
                    )
                    if flush:
                        weighted_gradient = self.adapter_gradient_buffer.copy()
                        batch_steps = self.adapter_gradient_buffer_steps
                        self.adapter_gradient_buffer.fill(0.0)
                        self.adapter_gradient_buffer_steps = 0
                    else:
                        weighted_gradient = None
            if weighted_gradient is not None:
                # Event-triggered micro-batching preserves the summed descent
                # direction of coherent manoeuvre updates, while avoiding the
                # long zig-zag parameter path produced by per-step commits.
                self.adapter -= lr * weighted_gradient
            if self.method == "campe" and self.ablation != "no_old_anchor":
                below_anchor = float(np.clip(
                    (self.cfg.anchor_threshold - self.model_drift_score) /
                    max(self.cfg.anchor_threshold, 0.05),
                    0.0,
                    1.0,
                ))
                self.adapter -= (0.002 + 0.007 * below_anchor) * (self.adapter - self.anchor_adapter)
            if self.method == "campe" and self.ablation != "no_trust_region":
                delta = self.adapter - old
                norm = np.linalg.norm(delta)
                trust_radius = (
                    max(1e-4, self.cfg.adapter_trust_radius)
                    * max(1, batch_steps)
                    * (
                        1.0
                        + self.cfg.kinematic_adapter_trust_gain
                        * self._kinematic_novelty(obs)
                    )
                )
                if norm > trust_radius:
                    self.adapter = old + delta * (trust_radius / norm)
            # The threshold is now the actual consolidation boundary: below it,
            # a stable low-risk mode can become an anchor; above it, adaptation
            # remains plastic.  This creates an explicit retention/adaptation
            # trade-off for the threshold sensitivity experiment.
            threshold = max(self.cfg.anchor_threshold, 0.05)
            if (self.method == "campe" and self.ablation != "no_old_anchor" and
                    self.model_drift_score < threshold and
                    next_info.get("risk", 1.0) < 0.55 and
                    self._kinematic_novelty(next_obs) < 0.38):
                stability_gate = float(np.clip(1.0 - self.model_drift_score / threshold, 0.0, 1.0))
                anchor_rate = 0.006 + 0.034 * stability_gate
                self.anchor_adapter = ((1.0 - anchor_rate) * self.anchor_adapter +
                                       anchor_rate * self.adapter)
            self.update_norms.append(float(np.linalg.norm(self.adapter - old)))
        else:
            self.update_norms.append(0.0)
        if self.last_predicted_score:
            realized_q = -(1.45 * next_info["radius_error"] / cfg.desired_radius +
                           1.30 * max(0.0, next_info["max_gap"] / ideal_gap(cfg.n_auv) - 1.0))
            self.overestimation.append(max(0.0, self.last_predicted_score - realized_q))
        self.drift_history.append(self.drift_score)
        self.model_drift_history.append(self.model_drift_score)
        self.weight_history.append(self.update_weight)
        self.step_id += 1
        self.adaptation_times.append(time.perf_counter() - t0)

    def summary(self) -> Dict[str, float]:
        return {
            "action_jump": float(np.mean(self.action_jumps or [0.0])),
            "value_overestimation": float(np.mean(self.overestimation or [0.0])),
            "follower_prediction_error": float(np.mean(self.prediction_errors or [0.0])),
            "policy_update_magnitude": float(np.sum(self.update_norms or [0.0])),
            "online_adaptation_time": float(np.sum(self.adaptation_times or [0.0])),
            "inference_time_ms": float(1000.0 * np.mean(self.inference_times or [0.0])),
            "adapter_parameters": float(self.adapter.size),
            "mean_uncertainty": float(np.mean(self.uncertainties or [0.0])),
            "mean_drift": float(np.mean(self.drift_history or [0.0])),
            "mean_model_drift": float(np.mean(self.model_drift_history or [0.0])),
            "mean_update_weight": float(np.mean(self.weight_history or [0.0])),
            "mean_kinematic_gate": float(np.mean(self.kinematic_gate_history or [0.0])),
            "final_kinematic_coherence": float(self.kinematic_coherence_score),
            "mean_sensor_gate": float(np.mean(self.sensor_gate_history or [0.0])),
            "mean_maneuver_pressure": float(np.mean(
                self.maneuver_pressure_history or [0.0]
            )),
            "mean_fast_mode": float(np.mean(self.fast_mode_history or [0.0])),
            "partial_compensation_selection_rate": float(np.mean(
                [idx in (1, 2) for idx in self.selected_candidates] or [0.0]
            )),
            "guard_selection_rate": float(np.mean(
                [idx in (5, 6, 7) for idx in self.selected_candidates] or [0.0]
            )),
            "effect_compensation_selection_rate": float(np.mean(
                [idx in (15, 16, 17) for idx in self.selected_candidates] or [0.0]
            )),
            "final_residual_norm": float(np.linalg.norm(np.mean(self.residual_ensemble, axis=0))),
            "final_effectiveness_shift": abs(1.0 - float(np.mean(self.effectiveness_ensemble))),
        }

    def copy_for_source_retention(self) -> "AdaptiveController":
        other = copy.deepcopy(self)
        # Evaluate parameter forgetting rather than carrying a target-domain
        # transient dynamics estimate into the source domain.
        other.residual_ensemble = np.zeros_like(other.residual_ensemble)
        other.effectiveness_ensemble = np.ones_like(other.effectiveness_ensemble)
        other.drift_score = 0.0
        other.model_drift_score = 0.0
        other.update_weight = 0.0
        other.adapter_gradient_ema = np.zeros_like(other.adapter_gradient_ema)
        other.adapter_gradient_buffer = np.zeros_like(other.adapter_gradient_buffer)
        other.adapter_gradient_buffer_steps = 0
        if self.method == "campe" and self.ablation != "no_old_anchor":
            # Returning to a recognized low-drift mode recalls the consolidated
            # immutable source policy, not merely its zero-valued adapter. This
            # restores the complete anchored decision mode after recognition.
            other.adapter = self.source_anchor_adapter.copy()
            other.method = "source_only"
        other.last_obs = None
        other.last_prediction = None
        other.prev_action = np.zeros_like(self.prev_action)
        other.action_jumps = []
        other.update_norms = []
        other.prediction_errors = []
        other.overestimation = []
        other.inference_times = []
        other.adaptation_times = []
        other.model_drift_history = []
        other.kinematic_gate_history = []
        other.target_velocity_ema = None
        other.target_innovation_ema = np.zeros(2, dtype=np.float64)
        other.target_innovation_scale = 0.0
        other.kinematic_novelty_score = 0.0
        other.kinematic_coherence_score = 0.0
        other.sensor_disagreement_score = 0.0
        other.maneuver_pressure_score = 0.0
        other.robust_target_pos = None
        other.robust_target_vel = None
        other.sensor_gate_history = []
        other.maneuver_pressure_history = []
        other.fast_mode_history = []
        other.selected_candidates = []
        return other
