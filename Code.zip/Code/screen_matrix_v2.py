from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import json
import multiprocessing as mp
import os
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd
import torch

from campe.config import ABLATIONS, METHODS, OOD_SCENARIOS, PLANNERS, SimConfig
from campe.experiment import run_episode


Task = Tuple[str, SimConfig, str, str, int, str, str, str, object]


def _worker(task: Task) -> Dict[str, object]:
    root_text, cfg, method, scenario, seed, planner, ablation, parameter, value = task
    torch.set_num_threads(1)
    row, _ = run_episode(
        Path(root_text), cfg, method, scenario, seed, planner=planner, ablation=ablation
    )
    if parameter:
        row["sensitivity_parameter"] = parameter
        row["sensitivity_value"] = value
    return row


def _tasks(root: Path, kind: str, seeds: List[int]) -> List[Task]:
    cfg = SimConfig()
    tasks: List[Task] = []
    if kind == "methods":
        for scenario in ("gradual", "sudden", "joint", "recurrent"):
            for method in METHODS:
                for seed in seeds:
                    tasks.append((str(root), cfg, method, scenario, seed, "full_mpc", "full", "", ""))
    elif kind == "planners":
        for scenario in ("mobile_shadow", "adversarial_mix"):
            for planner in PLANNERS:
                for seed in seeds:
                    tasks.append((str(root), cfg, "campe", scenario, seed, planner, "full", "", ""))
    elif kind == "ablation":
        stress = replace(
            cfg,
            n_auv=6,
            desired_radius=10.5,
            radial_tolerance=2.8,
            capture_gap_multiplier=1.28,
            capture_hold=24,
            capture_required_fraction=0.78,
            initial_angle_jitter=0.78,
            initial_radius_offset=8.0,
            initial_radius_std=6.0,
            safety_distance=9.0,
            collision_distance=6.0,
        )
        for scenario in ("adversarial_mix", "blackout_chase", "recurrent_shift"):
            for ablation in ABLATIONS:
                for seed in seeds:
                    tasks.append((str(root), stress, "campe", scenario, seed, "full_mpc", ablation, "", ""))
    elif kind == "robustness":
        for scenario in OOD_SCENARIOS:
            for method in ("source_only", "domain_randomization", "ctta", "campe"):
                for seed in seeds:
                    tasks.append((str(root), cfg, method, scenario, seed, "full_mpc", "full", "", ""))
    elif kind == "sensitivity":
        settings = []
        for value in (0.12, 0.40, 0.80):
            settings.append(("anchor_threshold", value, replace(cfg, anchor_threshold=value), "recurrent_shift"))
        for value in (0.4, 1.5, 4.0):
            settings.append(("usv_speed_limit", value, replace(cfg, usv_max_speed=value), "mobile_shadow"))
        for value in (20.0, 70.0, 140.0):
            settings.append(("usv_movement_budget", value, replace(cfg, usv_movement_budget=value), "mobile_shadow"))
        for value in (2_500.0, 9_000.0, 22_000.0):
            settings.append(("bandwidth", value, replace(cfg, total_bandwidth=value), "blackout_chase"))
        for value in (1, 6, 8):
            settings.append(("prediction_horizon", value, replace(cfg, prediction_horizon=value), "adversarial_mix"))
        for parameter, value, variant, scenario in settings:
            for seed in seeds:
                tasks.append((
                    str(root), variant, "campe", scenario, seed,
                    "full_mpc", "full", parameter, value,
                ))
    else:
        raise ValueError(kind)
    return tasks


def main() -> None:
    parser = argparse.ArgumentParser(description="Parallel evidence-driven V2 calibration matrix.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--kind", choices=("methods", "planners", "ablation", "robustness", "sensitivity"), required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--tag", default="screen")
    args = parser.parse_args()
    root = args.root.resolve()
    output_dir = root / "results" / "screening"
    output_dir.mkdir(parents=True, exist_ok=True)
    tasks = _tasks(root, args.kind, args.seeds)
    rows: List[Dict[str, object]] = []
    context = mp.get_context("spawn")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=context) as pool:
        futures = [pool.submit(_worker, task) for task in tasks]
        for index, future in enumerate(as_completed(futures), start=1):
            rows.append(future.result())
            if index % max(1, len(tasks) // 10) == 0 or index == len(tasks):
                print(f"[screen] {index}/{len(tasks)}", flush=True)
    frame = pd.DataFrame(rows)
    raw_path = output_dir / f"{args.tag}_{args.kind}_raw.csv"
    frame.to_csv(raw_path, index=False)
    if args.kind in {"methods", "robustness"}:
        groups = ["scenario", "method"]
    elif args.kind == "planners":
        groups = ["scenario", "planner"]
    elif args.kind == "ablation":
        groups = ["scenario", "ablation"]
    else:
        groups = ["sensitivity_parameter", "sensitivity_value"]
    metrics = [
        "capture_success_loose", "capture_success_medium", "capture_success_strict",
        "outcome_success_medium", "outcome_escape_medium", "outcome_collision_medium",
        "outcome_border_medium", "outcome_timeout_medium", "formation_score",
        "final_performance", "radius_error", "max_angle_gap", "target_inside_fraction",
        "collision_rate", "border_rate", "aoi", "per", "usv_distance",
    ]
    summary = frame.groupby(groups)[metrics].mean(numeric_only=True).reset_index()
    summary_path = output_dir / f"{args.tag}_{args.kind}_summary.csv"
    summary.to_csv(summary_path, index=False)
    print(json.dumps({"rows": len(frame), "raw": str(raw_path), "summary": str(summary_path)}, indent=2))


if __name__ == "__main__":
    main()
