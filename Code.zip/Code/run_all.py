from __future__ import annotations

import argparse
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
import torch

from campe.config import SimConfig
from campe.experiment import (
    ensure_backbone,
    run_adaptation,
    run_control_plane,
    run_domain_shift,
    run_robustness,
    run_safety_ablation,
    run_sensitivity,
)


STAGES = ("domain_shift", "adaptation", "safety_ablation", "control_plane", "robustness", "sensitivity")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the complete CAMPE TMC simulation suite.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--mode", choices=("quick", "full"), default="full")
    parser.add_argument("--stages", nargs="+", choices=STAGES, default=list(STAGES))
    parser.add_argument("--force-backbone", action="store_true")
    parser.add_argument("--seed-offset", type=int, default=0)
    args = parser.parse_args()

    root = args.root.resolve()
    (root / "results").mkdir(parents=True, exist_ok=True)
    (root / "checkpoints").mkdir(parents=True, exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError("The requested experiment protocol requires a CUDA GPU.")
    torch.set_float32_matmul_precision("high")
    cfg = SimConfig()
    if args.mode == "quick":
        train_samples, train_epochs = 18_000, 10
        main_seeds = list(range(args.seed_offset, args.seed_offset + 3))
        sensitivity_seeds = list(range(args.seed_offset, args.seed_offset + 2))
    else:
        train_samples, train_epochs = 80_000, 55
        main_seeds = list(range(args.seed_offset, args.seed_offset + 10))
        sensitivity_seeds = list(range(args.seed_offset, args.seed_offset + 5))

    training = {}
    required = [("td3", 2), ("td3", 3), ("td3", 4), ("td3", 6), ("sac", 4)]
    for backbone, n_auv in required:
        key = f"{backbone}_{n_auv}auv"
        print(f"[backbone] {key}", flush=True)
        training[key] = ensure_backbone(
            root,
            SimConfig(n_auv=n_auv),
            backbone,
            samples=train_samples,
            epochs=train_epochs,
            force=args.force_backbone,
        )

    metadata = {
        "mode": args.mode,
        "stages": args.stages,
        "main_seeds": main_seeds,
        "sensitivity_seeds": sensitivity_seeds,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "training": training,
        "config": cfg.__dict__,
        "started_unix": time.time(),
    }
    (root / "results" / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    runners = {
        "domain_shift": lambda: run_domain_shift(root, cfg, main_seeds),
        "adaptation": lambda: run_adaptation(root, cfg, main_seeds),
        "safety_ablation": lambda: run_safety_ablation(root, cfg, main_seeds),
        "control_plane": lambda: run_control_plane(root, cfg, main_seeds),
        "robustness": lambda: run_robustness(root, cfg, main_seeds),
        "sensitivity": lambda: run_sensitivity(root, cfg, sensitivity_seeds),
    }
    elapsed = {}
    for stage in args.stages:
        print(f"[stage:start] {stage}", flush=True)
        start = time.perf_counter()
        frame = runners[stage]()
        elapsed[stage] = time.perf_counter() - start
        print(f"[stage:done] {stage}: rows={len(frame)} seconds={elapsed[stage]:.2f}", flush=True)
    metadata["stage_seconds"] = elapsed
    metadata["finished_unix"] = time.time()
    (root / "results" / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps({"status": "complete", "elapsed": elapsed}, indent=2), flush=True)


if __name__ == "__main__":
    main()
