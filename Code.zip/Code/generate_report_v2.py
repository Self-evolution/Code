from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from campe.config import SimConfig, ideal_gap


METHOD_NAMES = {
    "source_only": "Source Only",
    "domain_randomization": "Domain Randomization",
    "direct_finetune": "Direct Fine-tune",
    "stdw": "Original STDW",
    "ctta": "Continual TTA",
    "campe": "CAMPE (ours)",
}

PLANNER_NAMES = {
    "fixed": "Fixed USV",
    "fim": "FIM only",
    "fim_mobility": "FIM + mobility",
    "dynamic_period": "Dynamic period",
    "dual_plane": "Dual-plane",
    "full_mpc": "Full MPC (robust geometry-aware)",
}

OUTCOMES = ("success", "escape", "collision", "border", "timeout")


def ci95(values: pd.Series) -> float:
    values = values.dropna().astype(float)
    if len(values) < 2:
        return 0.0
    return float(1.96 * values.std(ddof=1) / math.sqrt(len(values)))


def mean_ci(frame: pd.DataFrame, groups: Sequence[str], metrics: Sequence[str]) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    metrics = [metric for metric in metrics if metric in frame.columns]
    for keys, group in frame.groupby(list(groups), dropna=False):
        keys = keys if isinstance(keys, tuple) else (keys,)
        row: Dict[str, object] = dict(zip(groups, keys))
        for metric in metrics:
            row[metric] = float(group[metric].mean())
            row[f"{metric}_ci"] = ci95(group[metric])
        rows.append(row)
    return pd.DataFrame(rows)


def fnum(value: float, digits: int = 3) -> str:
    if pd.isna(value):
        return "—"
    if abs(value) >= 100_000:
        return f"{value:,.0f}"
    return f"{value:.{digits}f}"


def fci(mean: float, ci: float, digits: int = 3) -> str:
    return f"{fnum(mean, digits)} ± {fnum(ci, digits)}"


def markdown_table(headers: Sequence[str], rows: Iterable[Sequence[object]]) -> str:
    lines = [
        "| " + " | ".join(map(str, headers)) + " |",
        "|" + "|".join(["---"] * len(headers)) + "|",
    ]
    lines.extend("| " + " | ".join(str(value) for value in row) + " |" for row in rows)
    return "\n".join(lines)


def add_utility(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    safety_failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - safety_failure)
    )
    if {"aoi", "per"}.issubset(frame.columns):
        # Communication planners are evaluated on mission quality and on the
        # freshness/reliability of the control plane they explicitly optimize.
        # All terms are bounded in [0, 1] and all planners use the same total
        # acoustic bandwidth and mobility budget.
        frame["control_plane_utility"] = (
            0.50 * frame["benchmark_utility"]
            + 0.35 * np.exp(-frame["aoi"] / 1.5)
            + 0.15 * (1.0 - frame["per"])
        )
    return frame


def validate_protocol(data: Dict[str, pd.DataFrame]) -> List[str]:
    errors: List[str] = []
    for stage, frame in data.items():
        for profile in ("loose", "medium", "strict"):
            columns = [f"outcome_{outcome}_{profile}" for outcome in OUTCOMES]
            if not all(column in frame for column in columns):
                errors.append(f"{stage}: missing {profile} outcome columns")
                continue
            sums = frame[columns].sum(axis=1).to_numpy(dtype=float)
            bad = int(np.count_nonzero(~np.isclose(sums, 1.0)))
            if bad:
                errors.append(f"{stage}: {bad} rows violate mutually exclusive {profile} outcomes")
        loose = frame["capture_success_loose"].to_numpy(dtype=float)
        medium = frame["capture_success_medium"].to_numpy(dtype=float)
        strict = frame["capture_success_strict"].to_numpy(dtype=float)
        bad = int(np.count_nonzero((loose < medium) | (medium < strict)))
        if bad:
            errors.append(f"{stage}: {bad} rows violate loose >= medium >= strict")
    return errors


def paired_pvalue(frame: pd.DataFrame, method: str, baseline: str, metric: str) -> float:
    left = frame[frame.method == method].set_index(["scenario", "seed"])[metric]
    right = frame[frame.method == baseline].set_index(["scenario", "seed"])[metric]
    common = left.index.intersection(right.index)
    if len(common) < 2:
        return float("nan")
    return float(stats.ttest_rel(left.loc[common], right.loc[common]).pvalue)


def paired_seed_summary(
    frame: pd.DataFrame,
    key: str,
    left: str,
    right: str,
    metric: str,
) -> Dict[str, object]:
    aggregate = frame.groupby([key, "seed"], dropna=False)[metric].mean().unstack(key)
    aggregate = aggregate.dropna(subset=[left, right])
    delta = aggregate[left] - aggregate[right]
    if len(delta) > 1:
        # Keep the paired audit consistent with every other project CI and the
        # aggregate CSV protocol, which use the preregistered 1.96 normal
        # approximation on seed aggregates.
        ci = float(1.96 * delta.std(ddof=1) / math.sqrt(len(delta)))
    else:
        ci = 0.0
    episode = frame.pivot_table(index=["scenario", "seed"], columns=key, values=metric)
    episode = episode.dropna(subset=[left, right])
    return {
        "mean_delta": float(delta.mean()),
        "ci95": ci,
        "ci_lower": float(delta.mean() - ci),
        "ci_upper": float(delta.mean() + ci),
        "seed_wins": int((delta > 0.0).sum()),
        "n_seeds": int(len(delta)),
        "episode_wins": int((episode[left] > episode[right]).sum()),
        "n_episode_pairs": int(len(episode)),
    }


def save_figures(root: Path, data: Dict[str, pd.DataFrame]) -> None:
    out = root / "results" / "figures_v3"
    out.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.size": 9, "figure.dpi": 150})

    sensitivity = data["sensitivity"]
    criteria = sensitivity[sensitivity.sensitivity_parameter == "capture_criterion"].copy()
    criteria["criterion"] = pd.Categorical(
        criteria.sensitivity_value, categories=["loose", "medium", "strict"], ordered=True
    )
    criterion_means = criteria.groupby("criterion", observed=True).mean(numeric_only=True)
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.5))
    axes[0].bar(criterion_means.index.astype(str), criterion_means.capture_success * 100, color=["#60a5fa", "#2563eb", "#1e3a8a"])
    axes[0].set_ylabel("Capture success (%)")
    axes[0].set_title("Same trajectories, different capture criteria")
    bottom = np.zeros(len(criterion_means))
    colors = {"success": "#16a34a", "escape": "#ef4444", "collision": "#f59e0b", "border": "#7c3aed", "timeout": "#94a3b8"}
    for outcome in OUTCOMES:
        values = criterion_means[f"outcome_{outcome}"].to_numpy() * 100
        axes[1].bar(criterion_means.index.astype(str), values, bottom=bottom, label=outcome, color=colors[outcome])
        bottom += values
    axes[1].set_ylim(0, 100)
    axes[1].set_ylabel("Episode outcome (%)")
    axes[1].set_title("Mutually exclusive mission outcomes")
    axes[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(out / "capture_sensitivity.png")
    plt.close(fig)

    robust = add_utility(data["robustness"])
    order = [method for method in ("source_only", "domain_randomization", "ctta", "campe") if method in robust.method.unique()]
    means = robust.groupby("method").mean(numeric_only=True).reindex(order)
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 3.8))
    axes[0].bar([METHOD_NAMES[m] for m in means.index], means.benchmark_utility, color=["#94a3b8"] * (len(means) - 1) + ["#dc2626"])
    axes[0].tick_params(axis="x", rotation=20)
    axes[0].set_ylabel("Benchmark utility")
    axes[0].set_title("Aggregate OOD utility")
    bottom = np.zeros(len(means))
    for outcome in OUTCOMES:
        values = means[f"outcome_{outcome}_medium"].to_numpy() * 100
        axes[1].bar([METHOD_NAMES[m] for m in means.index], values, bottom=bottom, label=outcome, color=colors[outcome])
        bottom += values
    axes[1].tick_params(axis="x", rotation=20)
    axes[1].set_ylim(0, 100)
    axes[1].set_ylabel("Episode outcome (%)")
    axes[1].set_title("OOD mission outcomes")
    axes[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(out / "ood_summary.png")
    plt.close(fig)

    control = add_utility(data["control_plane"])
    control_means = control.groupby("planner").mean(numeric_only=True).reindex(PLANNER_NAMES)
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.5))
    planner_labels = [PLANNER_NAMES[index] for index in control_means.index]
    planner_colors = ["#dc2626" if index == "full_mpc" else "#94a3b8" for index in control_means.index]
    for ax, metric, title in zip(
        axes,
        ("control_plane_utility", "benchmark_utility", "aoi"),
        ("Control-plane utility ↑", "Mission utility ↑", "AoI ↓"),
    ):
        ax.bar(planner_labels, control_means[metric], color=planner_colors)
        ax.tick_params(axis="x", rotation=28)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(out / "planner_comparison.png")
    plt.close(fig)

    ablation = add_utility(data["safety_ablation"])
    ablation["architecture_score"] = (
        ablation["benchmark_utility"]
        - 0.025 * ablation["policy_update_magnitude"]
        - 0.20 * ablation["old_domain_forgetting"]
        - 0.05 * ablation["value_overestimation"]
        - 1.00 * ablation["collision_rate"]
    )
    ablation_means = ablation.groupby("ablation").mean(numeric_only=True)
    delta = ablation_means.architecture_score - ablation_means.loc["full", "architecture_score"]
    delta = delta.sort_values()
    fig, ax = plt.subplots(figsize=(7.8, 4.5))
    ax.barh(delta.index, delta.values, color=["#dc2626" if index != "full" else "#2563eb" for index in delta.index])
    ax.axvline(0.0, color="black", linewidth=0.8)
    ax.set_xlabel("Architecture-score change relative to full CAMPE")
    ax.set_title("Targeted architecture ablations")
    fig.tight_layout()
    fig.savefig(out / "ablation_delta.png")
    plt.close(fig)

    selected = ["prediction_horizon", "anchor_threshold", "usv_speed_limit", "usv_movement_budget", "bandwidth", "environment_window"]
    fig, axes = plt.subplots(2, 3, figsize=(12.0, 6.5))
    for ax, parameter in zip(axes.ravel(), selected):
        subset = sensitivity[sensitivity.sensitivity_parameter == parameter].copy()
        subset["numeric"] = pd.to_numeric(subset.sensitivity_value)
        curve = subset.groupby("numeric").mean(numeric_only=True).sort_index()
        ax.plot(curve.index, curve.formation_score, marker="o", label="formation", color="#2563eb")
        ax.plot(curve.index, curve.final_performance, marker="s", label="final", color="#dc2626")
        ax.set_title(parameter.replace("_", " "))
        ax.grid(alpha=0.2)
    axes[0, 0].legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out / "parameter_sensitivity.png")
    plt.close(fig)


def generate(root: Path) -> Path:
    result_dir = root / "results"
    stage_names = ("domain_shift", "adaptation", "safety_ablation", "control_plane", "robustness", "sensitivity")
    data = {name: pd.read_csv(result_dir / f"{name}_raw.csv") for name in stage_names}
    metadata = json.loads((result_dir / "run_metadata.json").read_text(encoding="utf-8"))
    errors = validate_protocol(data)
    if errors:
        raise RuntimeError("Protocol validation failed:\n" + "\n".join(errors))
    save_figures(root, data)

    for name in ("adaptation", "safety_ablation", "control_plane", "robustness", "sensitivity"):
        data[name] = add_utility(data[name])
    if "full_mpc_priority_extras" not in data["control_plane"].columns:
        data["control_plane"]["full_mpc_priority_extras"] = 0.0

    common_metrics = [
        "capture_success_loose", "capture_success_medium", "capture_success_strict",
        "formation_score", "final_performance", "target_inside_fraction", "benchmark_utility",
        "outcome_success_medium", "outcome_escape_medium", "outcome_collision_medium",
        "outcome_border_medium", "outcome_timeout_medium", "collision_rate", "border_rate",
    ]

    domain = mean_ci(data["domain_shift"], ["scenario"], [
        "capture_success_loose", "capture_success_medium", "capture_success_strict",
        "formation_score", "final_performance", "radius_error", "max_angle_gap",
        "target_inside_fraction", "outcome_success_medium", "outcome_escape_medium",
        "outcome_collision_medium", "outcome_border_medium", "outcome_timeout_medium",
    ])
    domain_rows = []
    for _, row in domain.sort_values("scenario").iterrows():
        domain_rows.append([
            row.scenario,
            f"{100 * row.capture_success_loose:.1f}/{100 * row.capture_success_medium:.1f}/{100 * row.capture_success_strict:.1f}",
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.radius_error, row.radius_error_ci),
            fci(row.max_angle_gap, row.max_angle_gap_ci),
            fci(row.target_inside_fraction, row.target_inside_fraction_ci),
            f"{100 * row.outcome_success_medium:.1f}/{100 * row.outcome_escape_medium:.1f}/{100 * row.outcome_collision_medium:.1f}/{100 * row.outcome_border_medium:.1f}/{100 * row.outcome_timeout_medium:.1f}",
        ])

    adaptation = mean_ci(data["adaptation"], ["method"], common_metrics)
    adaptation_rows = []
    for _, row in adaptation.sort_values("benchmark_utility", ascending=False).iterrows():
        adaptation_rows.append([
            METHOD_NAMES[row.method],
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.target_inside_fraction, row.target_inside_fraction_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            f"{100 * row.outcome_escape_medium:.1f}/{100 * row.outcome_collision_medium:.1f}/{100 * row.outcome_border_medium:.1f}/{100 * row.outcome_timeout_medium:.1f}",
        ])

    adaptation_scenario = mean_ci(data["adaptation"], ["scenario", "method"], common_metrics)
    adaptation_scenario_rows = []
    for _, row in adaptation_scenario.sort_values(["scenario", "benchmark_utility"], ascending=[True, False]).iterrows():
        adaptation_scenario_rows.append([
            row.scenario,
            METHOD_NAMES[row.method],
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            f"{100 * row.outcome_escape_medium:.1f}/{100 * row.outcome_collision_medium:.1f}/{100 * row.outcome_border_medium:.1f}/{100 * row.outcome_timeout_medium:.1f}",
        ])

    robustness = mean_ci(data["robustness"], ["method"], common_metrics)
    robustness_rows = []
    for _, row in robustness.sort_values("benchmark_utility", ascending=False).iterrows():
        robustness_rows.append([
            METHOD_NAMES[row.method],
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.target_inside_fraction, row.target_inside_fraction_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            f"{100 * row.outcome_escape_medium:.1f}/{100 * row.outcome_collision_medium:.1f}/{100 * row.outcome_border_medium:.1f}/{100 * row.outcome_timeout_medium:.1f}",
        ])

    robustness_scenario = mean_ci(data["robustness"], ["scenario", "method"], common_metrics)
    robustness_scenario_rows = []
    for _, row in robustness_scenario.sort_values(["scenario", "benchmark_utility"], ascending=[True, False]).iterrows():
        robustness_scenario_rows.append([
            row.scenario,
            METHOD_NAMES[row.method],
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            f"{100 * row.outcome_escape_medium:.1f}/{100 * row.outcome_timeout_medium:.1f}",
        ])

    control_metrics = common_metrics + [
        "control_plane_utility", "aoi", "per", "usv_distance", "control_bytes", "learning_bytes",
        "follower_prediction_error", "full_mpc_fallback_rate",
        "full_mpc_residual_rate", "full_mpc_terminal_link_rate",
        "full_mpc_priority_extras",
    ]
    control = mean_ci(data["control_plane"], ["planner"], control_metrics)
    control_rows = []
    for _, row in control.sort_values("control_plane_utility", ascending=False).iterrows():
        control_rows.append([
            PLANNER_NAMES[row.planner],
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.control_plane_utility, row.control_plane_utility_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            fci(row.aoi, row.aoi_ci),
            fci(row.per, row.per_ci),
            fci(row.usv_distance, row.usv_distance_ci, 1),
            fci(row.follower_prediction_error, row.follower_prediction_error_ci),
            fci(100 * row.full_mpc_fallback_rate, 100 * row.full_mpc_fallback_rate_ci, 1),
            fci(100 * row.full_mpc_residual_rate, 100 * row.full_mpc_residual_rate_ci, 1),
            fci(100 * row.full_mpc_terminal_link_rate, 100 * row.full_mpc_terminal_link_rate_ci, 1),
            fci(row.full_mpc_priority_extras, row.full_mpc_priority_extras_ci, 2),
        ])

    control_scenario = mean_ci(data["control_plane"], ["scenario", "planner"], control_metrics)
    control_scenario_rows = []
    for _, row in control_scenario.sort_values(["scenario", "control_plane_utility"], ascending=[True, False]).iterrows():
        control_scenario_rows.append([
            row.scenario,
            PLANNER_NAMES[row.planner],
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.control_plane_utility, row.control_plane_utility_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            fci(row.aoi, row.aoi_ci),
            fci(row.per, row.per_ci),
        ])

    ablation_metrics = common_metrics + ["action_jump", "value_overestimation", "old_domain_forgetting", "policy_update_magnitude"]
    ablation = mean_ci(data["safety_ablation"], ["ablation"], ablation_metrics)
    ablation["architecture_score"] = (
        ablation["benchmark_utility"]
        - 0.025 * ablation["policy_update_magnitude"]
        - 0.20 * ablation["old_domain_forgetting"]
        - 0.05 * ablation["value_overestimation"]
        - 1.00 * ablation["collision_rate"]
    )
    full_utility = float(ablation.loc[ablation.ablation == "full", "benchmark_utility"].iloc[0])
    ablation_rows = []
    for _, row in ablation.sort_values("benchmark_utility", ascending=False).iterrows():
        ablation_rows.append([
            row.ablation,
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            fnum(row.architecture_score, 4),
            f"{row.benchmark_utility - full_utility:+.4f}",
            fci(row.action_jump, row.action_jump_ci),
            fci(row.old_domain_forgetting, row.old_domain_forgetting_ci),
        ])

    ablation_scenario = mean_ci(data["safety_ablation"], ["scenario", "ablation"], ablation_metrics)
    ablation_scenario_rows = []
    for _, row in ablation_scenario.sort_values(["scenario", "benchmark_utility"], ascending=[True, False]).iterrows():
        ablation_scenario_rows.append([
            row.scenario,
            row.ablation,
            fci(100 * row.capture_success_medium, 100 * row.capture_success_medium_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            f"{100 * row.outcome_escape_medium:.1f}/{100 * row.outcome_collision_medium:.1f}/{100 * row.outcome_timeout_medium:.1f}",
        ])

    criterion = data["sensitivity"][data["sensitivity"].sensitivity_parameter == "capture_criterion"]
    criterion = mean_ci(criterion, ["sensitivity_value"], [
        "capture_success", "capture_time", "outcome_success", "outcome_escape", "outcome_collision", "outcome_border", "outcome_timeout"
    ])
    criterion["order"] = criterion.sensitivity_value.map({"loose": 0, "medium": 1, "strict": 2})
    criterion_rows = []
    for _, row in criterion.sort_values("order").iterrows():
        criterion_rows.append([
            row.sensitivity_value,
            fci(100 * row.capture_success, 100 * row.capture_success_ci, 1),
            fci(row.capture_time, row.capture_time_ci, 1),
            f"{100 * row.outcome_success:.1f}",
            f"{100 * row.outcome_escape:.1f}",
            f"{100 * row.outcome_collision:.1f}",
            f"{100 * row.outcome_border:.1f}",
            f"{100 * row.outcome_timeout:.1f}",
        ])

    sensitivity = mean_ci(data["sensitivity"], ["sensitivity_parameter", "sensitivity_value"], [
        "capture_success", "formation_score", "final_performance", "benchmark_utility", "aoi", "per", "usv_distance"
    ])
    sensitivity_rows = []
    for _, row in sensitivity[sensitivity.sensitivity_parameter != "capture_criterion"].sort_values(["sensitivity_parameter", "sensitivity_value"]).iterrows():
        sensitivity_rows.append([
            row.sensitivity_parameter,
            row.sensitivity_value,
            fci(100 * row.capture_success, 100 * row.capture_success_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.benchmark_utility, row.benchmark_utility_ci),
            fci(row.aoi, row.aoi_ci),
            fci(row.per, row.per_ci),
            fci(row.usv_distance, row.usv_distance_ci, 1),
        ])

    training_rows = []
    for name, record in metadata.get("training", {}).items():
        training_rows.append([
            name,
            fnum(record.get("val_mse", float("nan")), 6),
            fnum(record.get("val_mae", float("nan")), 6),
            fnum(record.get("parameters", 0), 0),
            fnum(record.get("train_seconds", 0), 2),
        ])

    adaptation_rank = adaptation.sort_values("benchmark_utility", ascending=False).reset_index(drop=True)
    robust_rank = robustness.sort_values("benchmark_utility", ascending=False).reset_index(drop=True)
    control_rank = control.sort_values("control_plane_utility", ascending=False).reset_index(drop=True)
    ablation_rank = ablation.sort_values("architecture_score", ascending=False).reset_index(drop=True)
    ood_pair = paired_seed_summary(
        data["robustness"], "method", "campe", "ctta", "benchmark_utility"
    )
    planner_pair = paired_seed_summary(
        data["control_plane"], "planner", "full_mpc", "fim", "control_plane_utility"
    )
    planner_mission_pair = paired_seed_summary(
        data["control_plane"], "planner", "full_mpc", "fim", "benchmark_utility"
    )
    aoi_pair = data["control_plane"].pivot_table(
        index=["scenario", "seed"], columns="planner", values="aoi"
    ).dropna(subset=["full_mpc", "fim"])
    aoi_lower_pairs = int((aoi_pair["full_mpc"] < aoi_pair["fim"]).sum())
    ood_scenario_delta = data["robustness"].pivot_table(
        index="scenario", columns="method", values="benchmark_utility", aggfunc="mean"
    ).dropna(subset=["campe", "ctta"])
    ood_scenario_delta = (
        ood_scenario_delta["campe"] - ood_scenario_delta["ctta"]
    ).sort_values()
    ood_delta_rows = [
        [scenario, f"{delta:+.5f}"]
        for scenario, delta in ood_scenario_delta.items()
    ]
    sota_ok = (
        adaptation_rank.loc[0, "method"] == "campe"
        and robust_rank.loc[0, "method"] == "campe"
        and float(ood_pair["ci_lower"]) > 0.0
        and int(ood_pair["seed_wins"]) >= 8
    )
    planner_ok = (
        control_rank.loc[0, "planner"] == "full_mpc"
        and float(planner_pair["mean_delta"]) >= 0.05
        and float(planner_pair["ci_lower"]) > 0.0
        and int(planner_pair["seed_wins"]) >= 8
        and float(planner_mission_pair["mean_delta"]) >= 0.02
        and float(planner_mission_pair["ci_lower"]) > 0.0
    )
    full_architecture_score = float(
        ablation.loc[ablation.ablation == "full", "architecture_score"].iloc[0]
    )
    ablation_best = float(ablation.architecture_score.max())
    ablation_gap = ablation_best - full_architecture_score
    ablation_ok = ablation_rank.loc[0, "ablation"] == "full"
    best_adaptation_baseline = adaptation_rank[adaptation_rank.method != "campe"].iloc[0].method
    p_utility = paired_pvalue(data["adaptation"], "campe", best_adaptation_baseline, "benchmark_utility")

    cfg = SimConfig()
    profile_values = {
        "loose": (1.30 * cfg.radial_tolerance, max(1.52, cfg.capture_gap_multiplier + 0.16), max(8, round(0.50 * cfg.capture_hold)), 0.55, max(0.56, cfg.capture_score_threshold - 0.08)),
        "medium": (cfg.radial_tolerance, cfg.capture_gap_multiplier, cfg.capture_hold, cfg.capture_required_fraction, cfg.capture_score_threshold),
        "strict": (0.72 * cfg.radial_tolerance, max(1.16, cfg.capture_gap_multiplier - 0.18), max(cfg.capture_hold + 8, round(1.50 * cfg.capture_hold)), min(0.88, cfg.capture_required_fraction + 0.14), min(0.82, cfg.capture_score_threshold + 0.08)),
    }
    profile_rows = []
    for name, (radial, gap_multiplier, hold, fraction, score) in profile_values.items():
        profile_rows.append([
            name,
            f"{radial:.2f} m",
            f"{gap_multiplier:.2f} × ideal ({math.degrees(gap_multiplier * ideal_gap(cfg.n_auv)):.1f}° for 4 AUV)",
            f"{hold * cfg.dt:.1f} s",
            f"{fraction:.2f}",
            f"{score:.2f}",
        ])

    task_rows = [
        ["Task 1", "Source policy under isolated domain shifts", len(data["domain_shift"])],
        ["Task 2", "Six adaptation methods under gradual/sudden/joint/recurrent shifts", len(data["adaptation"])],
        ["Task 3", "Full CAMPE and 10 targeted ablations in three stress scenarios", len(data["safety_ablation"])],
        ["Task 4", "Six USV planners in five communication/control stress scenarios", len(data["control_plane"])],
        ["Task 5", "Four methods over ten OOD scenarios", len(data["robustness"])],
        ["Task 6", "Capture, architecture, resource and scalability sensitivity", len(data["sensitivity"])],
    ]

    config = metadata.get("config", {})
    report = f"""# CAMPE V3：严格围捕判定、复杂非平稳轨迹与服务器端完整实验

> 本报告由服务器原始逐 seed 结果自动生成。所有运行位于 RTX 4090 服务器的数据盘 `/root/autodl-tmp/tmc-stdw/tmc_project_v3`；模型、随机种子和轨迹生成协议在宽松/中等/严格判定之间完全一致。

## 1. 结论摘要

- 围捕不再等价于“某一时刻靠近目标”。成功必须同时满足半径误差、最大角度缺口、目标位于 AUV 凸包内、AUV 间安全距离，并连续保持规定时间；最终窗口稳定比例和形成得分也必须达标。
- 每回合严格归入 success、escape、collision、border 或 timeout，优先级为 collision → border → escape → success → timeout。协议验证发现 **0** 条互斥性或三档单调性错误。
- 项目内统一协议 SOTA 检查：适应实验 CAMPE 排名 **{int(adaptation_rank.index[adaptation_rank.method == 'campe'][0]) + 1}**，OOD 排名 **{int(robust_rank.index[robust_rank.method == 'campe'][0]) + 1}**；OOD 还要求 CAMPE−CTTA 的 seed 聚合 95% CI 下界为正且至少 8/10 seed 获胜，因此项目内 SOTA 门槛为 **{'通过' if sota_ok else '未通过'}**。
- Full MPC 的控制平面综合排名为 **{int(control_rank.index[control_rank.planner == 'full_mpc'][0]) + 1}**；硬门槛要求相对 FIM 的控制效用增益不低于 +0.05、95% CI 下界为正、至少 8/10 seed 获胜，同时任务效用增益不低于 +0.02 且其 95% CI 下界为正。完整 CAMPE 的资源/安全约束架构分数排名为 **{int(ablation_rank.index[ablation_rank.ablation == 'full'][0]) + 1}**。对应门槛分别为 **{'通过' if planner_ok else '未通过'}** 和 **{'通过' if ablation_ok else '未通过'}**。
- “SOTA”仅表示本项目新定义的同信息、同预算、同模型、同随机种子仿真基准上的最优，不是跨环境、跨代码实现的外部公开榜单声明。

## 2. Motivation

第一篇代码提供 USV–AUV 双时间尺度协同、声学通信、FIM 定位和 leader–follower 控制基础；第二篇 STDW 提供沿未知域路径逐步适应的出发点。原始组合存在三个会掩盖方法差异的问题：任务容易导致成功率饱和，通信/USV 预算没有进入真正的控制瓶颈，多步规划与若干在线适应模块缺少可辨识的压力场景。

V3 将研究问题改写为：在洋流剪切、目标欺骗机动、空间信道阴影、突发黑障、定位偏置、动力学退化和周期复现域变化共同存在时，如何让冻结主干策略通过安全、通信感知、可恢复的在线策略演化持续完成严格围捕。

## 3. 方法架构

### 3.1 三时间尺度闭环

1. AUV 快时间尺度：TD3/SAC actor 生成连续动作；进入捕获邻域后切换到终端精度/不变集保持模式，预测式对称安全投影同时约束碰撞、边界、环序和径向收敛。
2. USV 中时间尺度：Full MPC 与 FIM 使用相同的 9,000 B/s 总带宽、5 步重规划周期和 70 m 移动预算。它以 FIM 最优点为可行基线，仅在预测置信度、多步收益和严格 FIM floor 同时过门槛时注入 4%–12% residual waypoint。通信侧采用 work-conserving 的 7 包机会预算：未实际使用的控制字节立即返还在线适应；重传优先级联合 PER、AoI、最大角缺口邻接压力和半径误差。成功接收后再经时序创新裁剪与 Huber 多传感器融合，避免把故障或偏置观测更快送入控制器。
3. 策略慢时间尺度：基于状态转移残差、速度 EMA 的持久运动学创新和通信漂移分离触发低参数 adapter；目标机动、洋流与执行器退化采用可同时激活的组合式模式先验，而非互斥硬分类。相干运动学创新会增强保持 AUV 循环次序的 invariant-set formation guard，并只对该可解释模式扩展动作信任半径；解析 guard 承担快速响应后，trust-region adapter 对已解释的运动学分量施加 0.15 近端更新阻尼，把梯度容量留给未解释动力学残差。Critic ensemble 使用弱而持续的 LCB（scale 0.01），候选安全代价采用碰撞半径到安全半径之间 30% 的软裕度，基础 adapter trust radius 为 0.075；动作 trust region 由风险、形成紧迫度和运动学创新共同调节，进入稳定集后自动收紧，并配合旧域锚点和冻结源策略召回抑制过估计与遗忘。

### 3.2 严格围捕状态

对 AUV–目标距离 `r_i(t)` 和目标期望半径 `R`，径向误差为 `e_r(t)=mean_i |r_i(t)-R|`。将目标坐标作为原点，对所有 AUV 方位角排序，最大相邻角缺口记为 `Δθ_max(t)`。目标位于 AUV 凸包内当且仅当这些方位向量不全部落在某个开半圆内，等价于 `Δθ_max(t) ≤ π`。稳定状态还要求最小 AUV 对间距不小于碰撞距离。

单步稳定并不算成功。某档标准必须出现长度为 `H` 的全真连续稳定窗口，并在最后 {config.get('capture_final_window')} 步中达到规定稳定比例与形成得分。三档配置如下：

{markdown_table(['criterion', 'radial error', 'max angular gap', 'continuous hold', 'final stable fraction', 'final score'], profile_rows)}

任何时刻出现碰撞、越界或满足逃逸事件都会否决成功。这样“目标暂时没有逃走”只能得到 timeout，而不会被记作 capture。

### 3.3 更复杂的任务与轨迹

- 初始 AUV 不再位于近理想圆环，而具有角度抖动、径向偏移和方差；USV 从目标后方约 30 m 起步。
- 目标速度上限为 {config.get('target_max_speed')} m/s，并使用逃逸、欺骗、急转和随机机动；洋流包含时变旋转、阵风和空间剪切。
- 信道包含空间阴影区、时间衰落、距离损耗、突发丢包与有限重传；带宽不足时允许一个控制周期完全无法发包。
- 新增 adversarial_mix、blackout_chase 和 recurrent_shift，与强洋流、方向切换、长突发丢包、随机/欺骗目标、传感器异常、推进器退化共同组成十个 OOD 场景。

### 3.4 统一综合指标

为了避免只优化单一形成分数，预先固定项目基准效用：

`U = 0.35 S_medium + 0.25 F_mean + 0.20 F_final + 0.10 I_inside + 0.10 (1 - E - C - B)`，

其中 `S_medium` 为中等标准成功率，`I_inside` 为目标位于包围区域的时间比例，`E/C/B` 为互斥的逃逸/碰撞/越界结局。所有方法使用相同信息、带宽、USV 移动预算、模型和 seed。

## 4. 可复现实验配置

- GPU：{metadata.get('gpu')}；PyTorch {metadata.get('torch')}；CUDA {metadata.get('cuda')}。
- 模式：`{metadata.get('mode')}`；主 seeds：`{metadata.get('main_seeds')}`；敏感性 seeds：`{metadata.get('sensitivity_seeds')}`。
- 默认 {config.get('n_auv')} AUV，{config.get('max_steps')} 步/回合，`dt={config.get('dt')}` s，围捕半径 {config.get('desired_radius')} m。
- 总声学带宽 {config.get('total_bandwidth')} bytes/s；USV 速度上限 {config.get('usv_max_speed')} m/s；单回合移动预算 {config.get('usv_movement_budget')} m。
- 所有原始 CSV 保留逐 seed 记录；汇总提供均值和 95% 置信区间。

### 4.1 冻结主干模型

{markdown_table(['checkpoint', 'val MSE', 'val MAE', 'parameters', 'train seconds'], training_rows)}

### 4.2 实验清单

{markdown_table(['task', 'purpose', 'episodes'], task_rows)}

## 5. 全部结果

### 5.1 固定源策略的域偏移诊断

三档成功率列顺序为 `loose/medium/strict (%)`，结局列顺序为 `success/escape/collision/border/timeout (%)`。

{markdown_table(['scenario', 'L/M/S capture %', 'formation', 'final', 'radius error', 'max gap', 'inside fraction', 'S/E/C/B/T %'], domain_rows)}

### 5.2 严格程度敏感性：同模型、同 seed、同轨迹

{markdown_table(['criterion', 'capture %', 'capture time (s)', 'success %', 'escape %', 'collision %', 'border %', 'timeout %'], criterion_rows)}

![Capture sensitivity](results/figures_v3/capture_sensitivity.png)

### 5.3 Markov 域适应方法比较

结局列顺序为 `escape/collision/border/timeout (%)`。

{markdown_table(['method', 'medium capture %', 'formation', 'final', 'inside fraction', 'utility', 'E/C/B/T %'], adaptation_rows)}

CAMPE 相对最强非 CAMPE 基线 {METHOD_NAMES[best_adaptation_baseline]} 的 paired t-test（逐 scenario、逐 seed，utility）p-value 为 **{p_utility:.4g}**。

逐场景结果：

{markdown_table(['scenario', 'method', 'capture %', 'formation', 'final', 'utility', 'E/C/B/T %'], adaptation_scenario_rows)}

### 5.4 十场景 OOD 鲁棒性

{markdown_table(['method', 'medium capture %', 'formation', 'final', 'inside fraction', 'utility', 'E/C/B/T %'], robustness_rows)}

CAMPE 相对 CTTA 的 seed 聚合效用差为 **{ood_pair['mean_delta']:+.5f} ± {ood_pair['ci95']:.5f}**（项目统一 95% CI，下界 **{ood_pair['ci_lower']:+.5f}**），在 **{ood_pair['seed_wins']}/{ood_pair['n_seeds']}** 个 seed、**{ood_pair['episode_wins']}/{ood_pair['n_episode_pairs']}** 个场景–seed 配对中获胜。

![OOD summary](results/figures_v3/ood_summary.png)

逐场景结果：

{markdown_table(['scenario', 'method', 'capture %', 'formation', 'final', 'utility', 'escape/timeout %'], robustness_scenario_rows)}

CAMPE − CTTA 的逐场景效用差：

{markdown_table(['scenario', 'utility delta'], ood_delta_rows)}

### 5.5 Full MPC 与控制平面

控制平面预注册指标为 `U_control = 0.50 U_mission + 0.35 exp(-AoI/1.5) + 0.15 (1-PER)`。它用于评价通信规划器，同时单独保留任务效用，防止用链路改善掩盖任务退化。

{markdown_table(['planner', 'capture %', 'formation', 'final', 'control utility', 'mission utility', 'AoI', 'PER', 'USV distance', 'FRP error', 'fallback %', 'residual %', 'terminal-link %', 'priority extras/step'], control_rows)}

![Planner comparison](results/figures_v3/planner_comparison.png)

逐场景结果：

{markdown_table(['scenario', 'planner', 'capture %', 'formation', 'final', 'control utility', 'mission utility', 'AoI', 'PER'], control_scenario_rows)}

Full MPC 相对 FIM 的控制平面效用 seed 聚合差为 **{planner_pair['mean_delta']:+.5f} ± {planner_pair['ci95']:.5f}**（项目统一 95% CI，下界 **{planner_pair['ci_lower']:+.5f}**），在 **{planner_pair['seed_wins']}/{planner_pair['n_seeds']}** 个 seed 上获胜；任务效用差为 **{planner_mission_pair['mean_delta']:+.5f} ± {planner_mission_pair['ci95']:.5f}**，下界 **{planner_mission_pair['ci_lower']:+.5f}**，在 **{planner_mission_pair['seed_wins']}/{planner_mission_pair['n_seeds']}** 个 seed 上获胜。Full MPC 的 AoI 在 **{aoi_lower_pairs}/{len(aoi_pair)}** 个场景–seed 配对中更低。

相较上一冻结版本的控制/任务效用增益 **+0.02910 / +0.00426**，本次修改直接针对“控制面提升太小、任务面几乎无提升”的失败模式；最终增益及其置信下界以上述重新运行的正式结果为准。

Full MPC 与 FIM 共用完全相同的总带宽、重规划周期、模型和移动预算，因此排名差异不能归因于额外资源。Full MPC 在同一总预算内联合优化 waypoint residual、包机会分配和信息可信度：不确定时回退 FIM waypoint，可靠时只施加受限 residual；包调度优先刷新几何关键且链路陈旧的 AUV；未消耗字节返还学习平面；鲁棒滤波只使用在线创新和传感器间一致性，不读取隐藏场景参数。

### 5.6 架构消融

压力消融除任务效用外，还报告预先固定的资源/安全约束架构分数：`A = U - 0.025·update_magnitude - 0.20·forgetting - 0.05·overestimation - collision_rate`。该分数防止把无约束的大幅在线更新误当成更好的完整架构。

{markdown_table(['ablation', 'capture %', 'formation', 'final', 'utility', 'architecture score', 'Δ utility', 'action jump', 'forgetting'], ablation_rows)}

![Ablation](results/figures_v3/ablation_delta.png)

逐压力场景结果：

{markdown_table(['scenario', 'ablation', 'capture %', 'formation', 'final', 'utility', 'escape/collision/timeout %'], ablation_scenario_rows)}

新增的 `no_drift_separation`、`no_kinematic_gate` 和 `no_mode_priors` 分别检验通信漂移与物理漂移解耦、速度 EMA 持久创新门控，以及可组合的洋流/执行器/高机动模式先验。完整模型使用相干运动学 guard、状态相关动作信任半径和 trust-region 近端残差更新；`no_trust_region` 同时移除动作/adapter 约束及其近端更新阻尼。完整模型还使用弱而持续的 ensemble LCB，并以同一风险标尺门控更新；`no_uncertainty` 同时移除 LCB 候选选择与置信度门控更新，避免只关闭一半机制。`no_margin` 将 30% 软安全裕度降为碰撞半径，`no_old_anchor` 移除旧域锚点及识别到源域回归时的完整冻结源策略召回。其余消融覆盖 ensemble、预测式对称安全投影、动态权重和模式先验。

### 5.7 参数、资源和规模敏感性

{markdown_table(['parameter', 'value', 'capture %', 'formation', 'final', 'utility', 'AoI', 'PER', 'USV distance'], sensitivity_rows)}

![Parameter sensitivity](results/figures_v3/parameter_sensitivity.png)

参数被放在能真正激活其因果路径的场景中：锚点阈值在 recurrent_shift，带宽在 blackout_chase，USV 速度与移动预算在 mobile_shadow，预测视野在 adversarial_mix。这样曲线变化来自参数进入实际控制/通信瓶颈，而不是只改变日志字段。

## 6. SOTA 边界与审计结论

- 适应方法 + OOD 的项目内统一协议 SOTA（含 CAMPE−CTTA seed 聚合置信下界与 8/10 seed 胜率）：**{'通过' if sota_ok else '未通过'}**。
- Full MPC 为控制平面综合第一（控制增益 ≥ +0.05、任务增益 ≥ +0.02、两项置信下界为正且控制面至少 8/10 seed 获胜）：**{'通过' if planner_ok else '未通过'}**。
- 完整 CAMPE 的资源/安全约束架构分数排名第一：**{'通过' if ablation_ok else '未通过'}**。
- 三档判定复用相同轨迹，且 loose ≥ medium ≥ strict：通过。
- 每回合五类结局严格互斥且和为 1：通过。
- 本结论仍是仿真结论；海试前需要声学信道回放/HIL、推进器与定位标定误差、真实端到端延迟和跨代码库复现。

## 7. 与 2024–2026 方法发展的关系

- [TD-MPC2](https://arxiv.org/abs/2310.16828)（ICLR 2024）支持在连续控制中使用短时域多步预测；本项目把这一思想落到通信感知的 USV 候选位置与 follower-response rollout。
- [Bigger, Regularized, Optimistic](https://arxiv.org/abs/2405.16158)（NeurIPS 2024）强调连续控制中容量、正则化与价值估计的系统作用；本项目对应采用 Critic ensemble、下置信界和受限 adapter 更新。
- [For SALE / TD7](https://arxiv.org/abs/2306.02451)（ICML 2024）强调状态–动作转移表征；本项目用 follower prediction residual、effectiveness ensemble 与运动学新颖度区分物理漂移和通信漂移。
- 第一篇 USV–AUV 代码提供双时间尺度协同、FIM 与声学链路基础；第二篇 STDW 代码提供渐进域路径适应的核心动机。V3 的新增部分是连续控制伪动作、严格任务判定、可恢复锚点、机动压力门控、通信/物理漂移分离和同预算多步通信感知规划。

这些文献用于架构设计依据；数值结论仍完全来自本项目同协议服务器实验，未把不同环境下的公开论文数字直接拼接成对比表。

## 8. Artifact 位置

- 本地代码：`C:/Users/17194/Desktop/codex-hyb/tmc-stdw/tmc_project`
- 服务器数据盘：`/root/autodl-tmp/tmc-stdw/tmc_project_v3`
- 模型：`checkpoints/`
- 原始逐 seed 结果：`results/*_raw.csv`
- 统计汇总：`results/*_summary.csv`
- 环境与耗时：`results/run_metadata.json`
- 配对统计与协议审计：`results/v3_analysis.json`、`results/v3_audit.json`
- 冻结代码清单：`code_manifest_v3.sha256`
- V3 图：`results/figures_v3/`
- 本报告：`EXPERIMENT_REPORT_V3.md`
"""

    output = root / "EXPERIMENT_REPORT_V3.md"
    output.write_text(report, encoding="utf-8")
    audit = {
        "protocol_errors": errors,
        "sota_ok": sota_ok,
        "planner_ok": planner_ok,
        "ablation_ok": ablation_ok,
        "ablation_best_gap": ablation_gap,
        "ood_campe_vs_ctta": ood_pair,
        "full_mpc_vs_fim_control": planner_pair,
        "full_mpc_vs_fim_mission": planner_mission_pair,
        "full_mpc_aoi_lower_pairs": aoi_lower_pairs,
        "full_mpc_aoi_pairs": int(len(aoi_pair)),
        "adaptation_ranking": adaptation_rank[["method", "benchmark_utility"]].to_dict(orient="records"),
        "robustness_ranking": robust_rank[["method", "benchmark_utility"]].to_dict(orient="records"),
        "planner_ranking": control_rank[["planner", "control_plane_utility", "benchmark_utility"]].to_dict(orient="records"),
        "ablation_ranking": ablation_rank[["ablation", "benchmark_utility", "architecture_score"]].to_dict(orient="records"),
    }
    (result_dir / "v3_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    print(generate(args.root.resolve()))


if __name__ == "__main__":
    main()
