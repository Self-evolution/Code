from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch

from campe.config import ABLATIONS, OOD_SCENARIOS, SimConfig
from campe.experiment import run_episode


METRICS = (
    "capture_success",
    "formation_score",
    "final_performance",
    "escape_rate",
    "collision_rate",
    "action_jump",
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Screen a CAMPE policy revision on the formal OOD protocol.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--seed-offset", type=int, default=0)
    parser.add_argument(
        "--scenarios",
        nargs="+",
        default=tuple(OOD_SCENARIOS),
        choices=tuple(OOD_SCENARIOS),
    )
    parser.add_argument(
        "--methods",
        nargs="+",
        default=("domain_randomization", "campe"),
        choices=("source_only", "domain_randomization", "ctta", "campe"),
    )
    parser.add_argument("--ablation", default="full", choices=ABLATIONS)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("OOD screening must run on the server GPU.")

    root = args.root.resolve()
    seeds = range(args.seed_offset, args.seed_offset + args.seeds)
    rows = []
    for scenario in args.scenarios:
        for method in args.methods:
            for seed in seeds:
                row, _ = run_episode(
                    root,
                    SimConfig(),
                    method,
                    scenario,
                    seed,
                    ablation=args.ablation,
                )
                rows.append(row)

    raw = pd.DataFrame.from_records(rows)
    output_dir = root / "results" / "screening"
    output_dir.mkdir(parents=True, exist_ok=True)
    raw.to_csv(output_dir / "ood_screen_raw.csv", index=False)
    per_scenario = raw.groupby(["scenario", "method"])[list(METRICS)].mean().reset_index()
    overall = raw.groupby("method")[list(METRICS)].mean().reset_index()
    per_scenario.to_csv(output_dir / "ood_screen_by_scenario.csv", index=False)
    overall.to_csv(output_dir / "ood_screen_overall.csv", index=False)
    print(json.dumps({
        "seeds": list(seeds),
        "overall": overall.to_dict(orient="records"),
        "by_scenario": per_scenario.to_dict(orient="records"),
    }, indent=2))


if __name__ == "__main__":
    main()
