from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from campe.config import SimConfig
from campe.environment import PursuitEnv
from campe.experiment import _domain_for, _initial_info, checkpoint_path
from campe.policy import AdaptiveController


METHOD_NAMES = {
    "source_only": "Source Only",
    "domain_randomization": "Domain Randomization",
    "direct_finetune": "Direct Fine-tune",
    "stdw": "Original STDW",
    "ctta": "Continual Test-Time Adaptation",
    "campe": "CAMPE (full)",
}

PLANNER_NAMES = {
    "fixed": "Fixed USV",
    "fim": "FIM only",
    "fim_mobility": "FIM + mobility",
    "dynamic_period": "Dynamic period",
    "dual_plane": "Dual-plane bandwidth",
    "full_mpc": "Full multi-step planner",
}


def ci95(values: pd.Series) -> float:
    values = values.dropna().astype(float)
    if len(values) < 2:
        return 0.0
    return float(1.96 * values.std(ddof=1) / math.sqrt(len(values)))


def mean_ci(frame: pd.DataFrame, groups: Sequence[str], metrics: Sequence[str]) -> pd.DataFrame:
    rows = []
    for keys, group in frame.groupby(list(groups), dropna=False):
        keys = keys if isinstance(keys, tuple) else (keys,)
        row = dict(zip(groups, keys))
        for metric in metrics:
            row[metric] = float(group[metric].mean())
            row[metric + "_ci"] = ci95(group[metric])
        rows.append(row)
    return pd.DataFrame(rows)


def fnum(value: float, digits: int = 3) -> str:
    if pd.isna(value):
        return "—"
    if abs(value) >= 100_000:
        return f"{value:,.0f}"
    return f"{value:.{digits}f}"


def fci(mean: float, ci: float, digits: int = 3) -> str:
    return f"{fnum(mean, digits)} ± {fnum(ci, digits)}"


def markdown_table(headers: Sequence[str], rows: Iterable[Sequence[object]]) -> str:
    lines = ["| " + " | ".join(map(str, headers)) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        lines.append("| " + " | ".join(str(x) for x in row) + " |")
    return "\n".join(lines)


def save_figures(root: Path, data: Dict[str, pd.DataFrame]) -> None:
    out = root / "results" / "figures"
    out.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.size": 9, "figure.dpi": 150})

    domain = data["domain_shift"]
    order = ["source", "current", "target_evasion", "burst_loss", "localization", "dynamics", "thruster"]
    means = domain.groupby("scenario")["final_performance"].mean().reindex(order)
    fig, ax = plt.subplots(figsize=(8.2, 3.6))
    ax.bar(np.arange(len(order)), means.values, color=["#3b82f6"] + ["#94a3b8"] * (len(order) - 1))
    ax.set_xticks(np.arange(len(order)), [x.replace("_", "\n") for x in order])
    ax.set_ylabel("Final formation performance")
    ax.set_title("Fixed source policy under Markov domain shifts")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout(); fig.savefig(out / "domain_shift.png"); plt.close(fig)

    adaptation = data["adaptation"]
    scenarios = ["gradual", "sudden", "joint"]
    methods = list(METHOD_NAMES)
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.6), sharey=True)
    for ax, scenario in zip(axes, scenarios):
        sub = adaptation[adaptation.scenario == scenario].groupby("method")["formation_score"].mean().reindex(methods)
        colors = ["#ef4444" if m == "campe" else "#94a3b8" for m in methods]
        ax.barh(np.arange(len(methods)), sub.values, color=colors)
        ax.set_yticks(np.arange(len(methods)), [METHOD_NAMES[m] for m in methods] if ax is axes[0] else [])
        ax.set_title(scenario.capitalize()); ax.set_xlabel("Mean formation score"); ax.grid(axis="x", alpha=0.25)
    fig.suptitle("Markov policy evolution comparison")
    fig.tight_layout(); fig.savefig(out / "adaptation.png"); plt.close(fig)

    ablation = data["safety_ablation"].groupby("ablation").mean(numeric_only=True)
    metrics = ["formation_score", "collision_rate", "action_jump", "value_overestimation"]
    values = ablation[metrics].copy()
    values = (values - values.min()) / (values.max() - values.min() + 1e-9)
    fig, ax = plt.subplots(figsize=(7.5, 4.3))
    im = ax.imshow(values.values, aspect="auto", cmap="viridis")
    ax.set_xticks(range(len(metrics)), [m.replace("_", "\n") for m in metrics])
    ax.set_yticks(range(len(values.index)), values.index)
    fig.colorbar(im, ax=ax, label="Within-metric normalized value")
    ax.set_title("Safety policy evolution ablations")
    fig.tight_layout(); fig.savefig(out / "ablation.png"); plt.close(fig)

    control = data["control_plane"].groupby("planner").mean(numeric_only=True).reindex(PLANNER_NAMES)
    fig, axes = plt.subplots(1, 3, figsize=(11.0, 3.4))
    for ax, metric, title in zip(axes, ["formation_score", "aoi", "usv_distance"], ["Formation ↑", "AoI ↓", "USV distance ↓"]):
        ax.bar(np.arange(len(control)), control[metric].values, color=["#ef4444" if p == "full_mpc" else "#94a3b8" for p in control.index])
        ax.set_xticks(np.arange(len(control)), [x.replace("_", "\n") for x in control.index], rotation=25)
        ax.set_title(title); ax.grid(axis="y", alpha=0.25)
    fig.tight_layout(); fig.savefig(out / "control_plane.png"); plt.close(fig)

    robust = data["robustness"].pivot_table(index="scenario", columns="method", values="formation_score", aggfunc="mean")
    robust = robust.reindex(columns=["source_only", "domain_randomization", "ctta", "campe"])
    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    im = ax.imshow(robust.values, aspect="auto", cmap="magma", vmin=0.0, vmax=1.0)
    ax.set_xticks(range(len(robust.columns)), [METHOD_NAMES[x] for x in robust.columns], rotation=20)
    ax.set_yticks(range(len(robust.index)), [x.replace("_", " ") for x in robust.index])
    for i in range(robust.shape[0]):
        for j in range(robust.shape[1]):
            ax.text(j, i, f"{robust.iloc[i, j]:.2f}", ha="center", va="center", color="white" if robust.iloc[i, j] < 0.65 else "black")
    fig.colorbar(im, ax=ax, label="Formation score")
    ax.set_title("Out-of-range robustness")
    fig.tight_layout(); fig.savefig(out / "robustness.png"); plt.close(fig)

    sensitivity = data["sensitivity"]
    selected = ["prediction_horizon", "environment_window", "usv_speed_budget", "bandwidth"]
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.2))
    for ax, parameter in zip(axes.ravel(), selected):
        sub = sensitivity[sensitivity.sensitivity_parameter == parameter].copy()
        sub["numeric"] = pd.to_numeric(sub.sensitivity_value)
        curve = sub.groupby("numeric")["formation_score"].mean().sort_index()
        ax.plot(curve.index, curve.values, marker="o", color="#ef4444")
        ax.set_title(parameter.replace("_", " ")); ax.set_ylabel("Formation score"); ax.grid(alpha=0.25)
    fig.tight_layout(); fig.savefig(out / "sensitivity.png"); plt.close(fig)


def save_mechanism_trace(root: Path) -> None:
    """Run one fully logged server-side episode for mechanism visualisation."""
    cfg = SimConfig()
    env = PursuitEnv(cfg, seed=0)
    obs = env.reset()
    info = _initial_info(env)
    controller = AdaptiveController(cfg, "campe", checkpoint_path(root, "td3", cfg.n_auv), seed=0)
    rows = []
    snapshot = None
    for step in range(cfg.max_steps):
        domain = _domain_for("joint", step, cfg.max_steps, 1.0)
        action = controller.act(obs, info)
        next_obs, _, done, next_info = env.step(
            action, domain, "full_mpc", controller.drift_score, controller.learning_active
        )
        controller.feedback(obs, next_obs, action, next_info)
        row = {
            "step": step,
            "score": next_info["score"],
            "radius_error": next_info["radius_error"],
            "max_gap": next_info["max_gap"],
            "aoi": next_info["aoi"],
            "per": next_info["per"],
            "control_ratio": next_info["control_ratio"],
            "learning_ratio": 1.0 - next_info["control_ratio"],
            "drift": controller.drift_score,
            "update_weight": controller.update_weight,
            "target_x": env.target_pos[0],
            "target_y": env.target_pos[1],
            "usv_x": env.usv_pos[0],
            "usv_y": env.usv_pos[1],
        }
        for i in range(cfg.n_auv):
            row[f"auv{i}_x"] = env.auv_pos[i, 0]
            row[f"auv{i}_y"] = env.auv_pos[i, 1]
        rows.append(row)
        if step == 120:
            snapshot = env.clone()
        obs, info = next_obs, next_info
        if done:
            break
    trace = pd.DataFrame(rows)
    trace.to_csv(root / "results" / "mechanism_trace.csv", index=False)
    out = root / "results" / "figures"

    fig, ax = plt.subplots(figsize=(6.2, 5.8))
    ax.plot(trace.target_x, trace.target_y, color="black", linewidth=2.0, label="Target")
    ax.plot(trace.usv_x, trace.usv_y, color="#f59e0b", linewidth=1.8, label="USV")
    colors = plt.cm.Blues(np.linspace(0.45, 0.95, cfg.n_auv))
    for i, color in enumerate(colors):
        ax.plot(trace[f"auv{i}_x"], trace[f"auv{i}_y"], color=color, linewidth=1.4, label=f"AUV {i}")
    ax.set_xlim(0, cfg.arena_size); ax.set_ylim(0, cfg.arena_size); ax.set_aspect("equal")
    ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)"); ax.set_title("Representative joint-shift trajectory")
    ax.legend(ncol=2, fontsize=8); ax.grid(alpha=0.2)
    fig.tight_layout(); fig.savefig(out / "mechanism_trajectory.png"); plt.close(fig)

    fig, axes = plt.subplots(3, 1, figsize=(9.0, 6.5), sharex=True)
    axes[0].plot(trace.step, trace.score, label="formation score", color="#2563eb")
    axes[0].plot(trace.step, trace.drift, label="drift", color="#ef4444", alpha=0.8)
    axes[0].legend(); axes[0].grid(alpha=0.2)
    axes[1].plot(trace.step, trace.aoi, label="AoI", color="#7c3aed")
    axes[1].plot(trace.step, trace.per, label="PER", color="#db2777")
    axes[1].legend(); axes[1].grid(alpha=0.2)
    axes[2].plot(trace.step, trace.control_ratio, label="control plane", color="#059669")
    axes[2].plot(trace.step, trace.learning_ratio, label="learning plane", color="#f59e0b")
    axes[2].plot(trace.step, trace.update_weight, label="policy update weight", color="#334155", linestyle="--")
    axes[2].legend(); axes[2].grid(alpha=0.2); axes[2].set_xlabel("Step")
    fig.suptitle("Adaptation recovery and dual-plane allocation")
    fig.tight_layout(); fig.savefig(out / "mechanism_curves.png"); plt.close(fig)

    if snapshot is None:
        snapshot = env
    xs = np.linspace(10.0, cfg.arena_size - 10.0, 70)
    ys = np.linspace(10.0, cfg.arena_size - 10.0, 70)
    heat = np.zeros((len(ys), len(xs)))
    for yi, y in enumerate(ys):
        for xi, x in enumerate(xs):
            point = np.array([x, y])
            fim = snapshot._fim(point, snapshot.cached_auv)
            comm = -np.mean(np.linalg.norm(snapshot.cached_auv - point, axis=1)) / 80.0
            move = -np.linalg.norm(point - snapshot.usv_pos) / 18.0
            heat[yi, xi] = fim + 0.45 * comm + 0.38 * move
    fig, ax = plt.subplots(figsize=(6.4, 5.3))
    im = ax.imshow(heat, extent=[xs.min(), xs.max(), ys.min(), ys.max()], origin="lower", cmap="viridis", aspect="equal")
    ax.scatter(snapshot.cached_auv[:, 0], snapshot.cached_auv[:, 1], marker="^", c="white", edgecolors="black", label="cached AUV")
    ax.scatter(snapshot.cached_target[0], snapshot.cached_target[1], marker="*", s=140, c="red", label="cached target")
    ax.scatter(snapshot.usv_pos[0], snapshot.usv_pos[1], marker="s", c="orange", edgecolors="black", label="USV")
    fig.colorbar(im, ax=ax, label="Candidate leader score")
    ax.set_title("USV candidate-position score heatmap (step 120)")
    ax.legend(fontsize=8); ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
    fig.tight_layout(); fig.savefig(out / "usv_candidate_heatmap.png"); plt.close(fig)


def paired_pvalue(frame: pd.DataFrame, scenario: str, baseline: str, metric: str) -> float:
    left = frame[(frame.scenario == scenario) & (frame.method == "campe")].set_index("seed")[metric]
    right = frame[(frame.scenario == scenario) & (frame.method == baseline)].set_index("seed")[metric]
    common = left.index.intersection(right.index)
    if len(common) < 2:
        return float("nan")
    return float(stats.ttest_rel(left.loc[common], right.loc[common]).pvalue)


def generate(root: Path) -> Path:
    result_dir = root / "results"
    names = ["domain_shift", "adaptation", "safety_ablation", "control_plane", "robustness", "sensitivity"]
    data = {name: pd.read_csv(result_dir / f"{name}_raw.csv") for name in names}
    metadata = json.loads((result_dir / "run_metadata.json").read_text(encoding="utf-8"))
    save_figures(root, data)
    save_mechanism_trace(root)

    domain = mean_ci(data["domain_shift"], ["scenario"], ["capture_success", "formation_score", "final_performance", "escape_rate", "radius_error", "max_angle_gap", "auv_energy"])
    source_final = float(domain.loc[domain.scenario == "source", "final_performance"].iloc[0])
    domain_rows = []
    for _, row in domain.sort_values("scenario").iterrows():
        drop = 100.0 * (source_final - row.final_performance) / max(source_final, 1e-9)
        domain_rows.append([
            row.scenario,
            fci(row.capture_success * 100, row.capture_success_ci * 100, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            f"{drop:.1f}%",
            fci(row.radius_error, row.radius_error_ci),
            fci(row.max_angle_gap, row.max_angle_gap_ci),
        ])

    adaptation = mean_ci(data["adaptation"], ["scenario", "method"], [
        "capture_success", "escape_rate", "formation_score", "final_performance", "recovery_time",
        "min_performance", "old_domain_forgetting", "collision_rate", "action_jump",
        "follower_prediction_error", "policy_update_magnitude",
    ])
    adaptation_rows = []
    for _, row in adaptation.sort_values(["scenario", "method"]).iterrows():
        adaptation_rows.append([
            row.scenario,
            METHOD_NAMES[row.method],
            fci(100 * row.capture_success, 100 * row.capture_success_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.escape_rate, row.escape_rate_ci),
            fci(row.recovery_time, row.recovery_time_ci, 1),
            fci(row.old_domain_forgetting, row.old_domain_forgetting_ci),
            fci(row.collision_rate, row.collision_rate_ci, 4),
            fci(row.action_jump, row.action_jump_ci),
        ])

    ablation = mean_ci(data["safety_ablation"], ["ablation"], [
        "formation_score", "final_performance", "escape_rate", "collision_rate", "action_jump",
        "value_overestimation", "policy_update_magnitude", "old_domain_forgetting" if "old_domain_forgetting" in data["safety_ablation"] else "mean_drift",
    ])
    ablation_rows = []
    for _, row in ablation.sort_values("ablation").iterrows():
        ablation_rows.append([
            row.ablation,
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.collision_rate, row.collision_rate_ci, 4),
            fci(row.action_jump, row.action_jump_ci),
            fci(row.value_overestimation, row.value_overestimation_ci),
            fci(row.policy_update_magnitude, row.policy_update_magnitude_ci),
            fci(row.old_domain_forgetting, row.old_domain_forgetting_ci) if "old_domain_forgetting" in row else "—",
        ])

    control = mean_ci(data["control_plane"], ["planner"], [
        "formation_score", "final_performance", "aoi", "per", "control_bytes", "learning_bytes",
        "auv_energy", "usv_distance", "follower_prediction_error",
    ])
    control_rows = []
    for _, row in control.sort_values("planner").iterrows():
        control_rows.append([
            PLANNER_NAMES[row.planner],
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.aoi, row.aoi_ci),
            fci(row.per, row.per_ci),
            fci(row.control_bytes, row.control_bytes_ci, 0),
            fci(row.learning_bytes, row.learning_bytes_ci, 0),
            fci(row.usv_distance, row.usv_distance_ci, 1),
            fci(row.follower_prediction_error, row.follower_prediction_error_ci),
        ])

    robustness = mean_ci(data["robustness"], ["scenario", "method"], [
        "capture_success", "escape_rate", "formation_score", "final_performance", "collision_rate",
    ])
    robustness_rows = []
    for _, row in robustness.sort_values(["scenario", "method"]).iterrows():
        robustness_rows.append([
            row.scenario,
            METHOD_NAMES[row.method],
            fci(100 * row.capture_success, 100 * row.capture_success_ci, 1),
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(row.escape_rate, row.escape_rate_ci),
            fci(row.collision_rate, row.collision_rate_ci, 4),
        ])

    sensitivity = mean_ci(data["sensitivity"], ["sensitivity_parameter", "sensitivity_value"], [
        "formation_score", "final_performance", "capture_success", "aoi", "per", "wall_time",
    ])
    sensitivity_rows = []
    for _, row in sensitivity.sort_values(["sensitivity_parameter", "sensitivity_value"]).iterrows():
        sensitivity_rows.append([
            row.sensitivity_parameter,
            row.sensitivity_value,
            fci(row.formation_score, row.formation_score_ci),
            fci(row.final_performance, row.final_performance_ci),
            fci(100 * row.capture_success, 100 * row.capture_success_ci, 1),
            fci(row.aoi, row.aoi_ci),
            fci(row.wall_time, row.wall_time_ci, 2),
        ])

    efficiency = mean_ci(data["adaptation"], ["method"], [
        "online_adaptation_time", "inference_time_ms", "adapter_parameters", "learning_bytes",
        "control_bytes", "auv_energy", "usv_distance",
    ])
    efficiency_rows = []
    for _, row in efficiency.sort_values("method").iterrows():
        efficiency_rows.append([
            METHOD_NAMES[row.method],
            fci(row.inference_time_ms, row.inference_time_ms_ci, 3),
            fci(row.online_adaptation_time, row.online_adaptation_time_ci, 3),
            fnum(row.adapter_parameters, 0),
            fci(row.control_bytes, row.control_bytes_ci, 0),
            fci(row.learning_bytes, row.learning_bytes_ci, 0),
            fci(row.auv_energy, row.auv_energy_ci, 1),
            fci(row.usv_distance, row.usv_distance_ci, 1),
        ])

    avg_robust = data["robustness"].groupby("method")["formation_score"].mean().sort_values(ascending=False)
    best_robust = METHOD_NAMES[avg_robust.index[0]]
    robust_overall = data["robustness"].groupby("method").agg({
        "capture_success": "mean",
        "formation_score": "mean",
        "final_performance": "mean",
        "escape_rate": "mean",
        "collision_rate": "mean",
    })
    campe_robust = robust_overall.loc["campe"]
    strongest_robust_baseline_name = robust_overall.drop(index="campe")["formation_score"].idxmax()
    strongest_robust_baseline = robust_overall.loc[strongest_robust_baseline_name]
    control_overall = data["control_plane"].groupby("planner").mean(numeric_only=True)
    full_control = control_overall.loc["full_mpc"]
    safety_overall = data["safety_ablation"].groupby("ablation").mean(numeric_only=True)
    full_safety = safety_overall.loc["full"]
    no_safety = safety_overall.loc["no_safety"]
    collision_multiplier = float(no_safety.collision_rate / max(full_safety.collision_rate, 1e-12))
    campe_avg = float(data["adaptation"][data["adaptation"].method == "campe"].formation_score.mean())
    baseline_frame = data["adaptation"][data["adaptation"].method != "campe"]
    best_baseline_method = baseline_frame.groupby("method").formation_score.mean().idxmax()
    best_baseline_avg = float(baseline_frame.groupby("method").formation_score.mean().max())
    pvalues = {s: paired_pvalue(data["adaptation"], s, best_baseline_method, "formation_score") for s in ["gradual", "sudden", "joint"]}

    training_rows = []
    for name, record in metadata.get("training", {}).items():
        training_rows.append([name, fnum(record.get("val_mse", float("nan")), 6), fnum(record.get("val_mae", float("nan")), 6), fnum(record.get("parameters", 0), 0), fnum(record.get("train_seconds", 0), 2)])

    report = rf"""# CAMPE：面向非平稳水下围捕的通信感知 Markov 策略演化

> 本报告由服务器上的真实训练、仿真与逐种子统计结果自动生成。所有指标均来自 `{result_dir}`，不是手工填写或估算。

## 1. 结论摘要

- 项目已把第一篇代码的 USV–AUV 双时间尺度协同、FIM 定位、时延/丢包/缓存状态和 Stackelberg follower-response 思想，重构为运动目标围捕任务。
- 项目已把第二篇 STDW 的离散分类伪标签改造成连续控制伪动作，并新增 Critic 集成保守评分、不确定性惩罚、安全动作投影、通信—风险动态权重、旧域锚定、风险自适应信赖域和自动环境锚点。
- 最终 CAMPE 进一步解耦物理/模型漂移与通信漂移，加入洋流部分补偿、推进器逆 effectiveness 补偿、通信可靠性调制的目标运动新颖性门，以及模式条件候选正则；预测视野真实执行配置的多步 rollout。
- 完整协议覆盖 PDF 中的六类实验，并统一报告多随机种子均值、标准差/95% 置信区间、通信、控制、安全、适应与计算指标。
- 在本项目新建立的同协议 benchmark 上，CAMPE 的三类域变化平均 formation score 为 **{campe_avg:.4f}**；最强非 CAMPE 基线 {METHOD_NAMES[best_baseline_method]} 为 **{best_baseline_avg:.4f}**。训练范围外鲁棒性平均最优方法为 **{best_robust}**。
- 正式 7 场景 × 10 seeds OOD 汇总：CAMPE capture/formation/final/collision = **{campe_robust.capture_success:.4f}/{campe_robust.formation_score:.4f}/{campe_robust.final_performance:.4f}/{campe_robust.collision_rate:.6f}**；最强 formation 基线 {METHOD_NAMES[strongest_robust_baseline_name]} 为 **{strongest_robust_baseline.formation_score:.4f}**，其 final/collision 为 **{strongest_robust_baseline.final_performance:.4f}/{strongest_robust_baseline.collision_rate:.6f}**。
- 安全投影移除后碰撞率增至完整方法的 **{collision_multiplier:.1f}×**。Full MPC 在 90 m 移动预算内取得 FIM **{full_control.fim:.4f}**、AoI **{full_control.aoi:.4f}**、PER **{full_control.per:.4f}**；控制面结论按多目标 Pareto 解释，不声称每个单指标都同时第一。
- “SOTA”仅指本报告定义、代码公开且同预算运行的新 benchmark 上的最优结果；由于这是新任务，不把内部数值冒充成与外部论文不同环境下可直接比较的公开榜单 SOTA。

## 2. Motivation

第一篇工作解决了水声通信不完美条件下 USV 慢时标领导者与 AUV 快时标跟随者的协同，但其策略只在预设扰动范围内训练。未知洋流、目标主动逃逸、连续丢包、定位偏差、动力学变化和推进器退化会同时改变观测分布、动作执行结果和状态转移，因此问题不是普通 covariate shift，而是通信约束 Markov 域变化。

第二篇 STDW 提供了“沿渐进域路径自训练”的核心启发，但原始方法针对分类：伪标签离散、域路径人工给定、权重只随训练进度变化，也没有控制安全、价值过估计或灾难性遗忘约束。新的研究问题是：**在没有目标域真实动作标签、通信资源有限且失败代价很高时，如何让多 AUV 策略安全、渐进并可恢复地自演化？**

## 3. 方法论：CAMPE

### 3.1 通信约束 Markov 域

把环境写为 $\mathcal{{M}}_z=(\mathcal{{S}},\mathcal{{A}},P_z,O_z,R_z,C_z)$。潜变量 $z$ 同时控制洋流、目标机动、声学丢包过程、定位噪声/偏差、动力学尺度和推进器健康。策略只能看到近期状态—动作—奖励—通信轨迹，不能读取 $z$。

### 3.2 三时间尺度闭环

1. **AUV 快时标控制**：TD3-compatible 或 SAC-compatible actor 输出围捕动作；安全层处理碰撞、边界和围捕裕度。
2. **USV 中时标协调**：联合优化 FIM、通信距离、移动代价、Follower Response Prediction 和多步逃逸风险，并动态选择更新周期。
3. **策略慢时标演化**：低参数在线 adapter 根据自动域锚点和保守连续伪动作更新；大偏移或高不确定性时先保守控制。

### 3.3 保守连续伪动作

在冻结源策略动作附近生成部分/完整洋流补偿、逆执行器 effectiveness、旋转、环序保持、径向修复和历史平滑候选。多个转移/Critic 假设在配置的多步预测视野内评估半径误差、角度缺口、碰撞裕度和能耗，使用

$$Q_{{\mathrm{{LCB}}}}(a)=\mathbb{{E}}_k[Q_k(a)]-\beta\,\mathrm{{Std}}_k[Q_k(a)]$$

选择低分歧高价值动作。加性残差一致且 effectiveness 稳定时偏向洋流补偿；effectiveness 显著下降时偏向逆执行器补偿；目标高速/急转或传感器异常时，在通信可靠性调制下偏向预测环形 guard。通信丢包只降低可靠性，不再被误当成动力学漂移。动作和参数更新都受风险自适应信赖域约束。

### 3.4 控制—学习双平面

总水声带宽被拆为控制与学习流。目标接近逃逸时提高控制比例；围捕稳定但检测到持续域漂移时，为压缩轨迹、环境特征和 adapter 更新分配更多学习带宽。Full MPC 的 USV 候选评分真实包含未来 follower ring error 与信息增益，而不是退化成单步 FIM heuristic。所有 planner 在相同总带宽与 90 m USV 移动预算下评估。

## 4. 实验架构与可复现配置

- GPU：{metadata.get('gpu')}；PyTorch {metadata.get('torch')}；CUDA {metadata.get('cuda')}。
- 模式：`{metadata.get('mode')}`；主实验 seeds：`{metadata.get('main_seeds')}`；敏感性 seeds：`{metadata.get('sensitivity_seeds')}`。
- 默认 4 AUV，240 步/回合，目标围捕半径 {metadata.get('config', {}).get('desired_radius')} m，总带宽 {metadata.get('config', {}).get('total_bandwidth')} bytes/s。
- 每个原始结果文件保留逐 seed 记录；汇总文件报告 mean/std/95% CI。

### 4.1 策略骨干训练

{markdown_table(['checkpoint', 'val MSE', 'val MAE', 'parameters', 'train seconds'], training_rows)}

## 5. 实验清单、任务与结果

正式实验矩阵：Task 1 = {len(data['domain_shift'])} 回合，Task 2 = {len(data['adaptation'])} 回合，Task 3 = {len(data['safety_ablation'])} 回合，Task 4 = {len(data['control_plane'])} 回合，Task 5 OOD = {len(data['robustness'])} 回合，敏感性/扩展性 = {len(data['sensitivity'])} 回合。预筛选结果不混入正式统计。

### 5.1 Task 1：原始协同框架复现与域偏移验证

任务：在理想源域训练/蒸馏策略，然后直接部署到六类未知偏移，验证固定策略退化。

{markdown_table(['scenario', 'capture %', 'formation', 'final', 'drop vs source', 'radius error', 'max gap'], domain_rows)}

![Domain shift](results/figures/domain_shift.png)

### 5.2 Task 2：Markov 渐进策略演化

比较 Source Only、Domain Randomization、直接微调、原始 STDW、CTTA 与完整 CAMPE；场景包括渐进、突变和多因素联合变化。

{markdown_table(['scenario', 'method', 'capture %', 'formation', 'final', 'escape', 'recovery steps', 'forgetting', 'collision', 'action jump'], adaptation_rows)}

![Adaptation](results/figures/adaptation.png)

与平均最强基线 {METHOD_NAMES[best_baseline_method]} 的 paired t-test（formation score）p-values：gradual={pvalues['gradual']:.4g}，sudden={pvalues['sudden']:.4g}，joint={pvalues['joint']:.4g}。统计显著性应结合完整种子数、效应量和各场景方向共同解释。

### 5.3 Task 3：安全策略演化消融

{markdown_table(['ablation', 'formation', 'final', 'collision', 'action jump', 'overestimation', 'update magnitude', 'forgetting'], ablation_rows)}

![Ablation](results/figures/ablation.png)

### 5.4 Task 4：控制—学习双平面闭环

{markdown_table(['planner', 'formation', 'final', 'AoI', 'PER', 'control bytes', 'learning bytes', 'USV distance', 'FRP error'], control_rows)}

![Control plane](results/figures/control_plane.png)

该表是多目标比较：formation/final、AoI/PER、FIM、控制/学习字节数和移动距离不能用单列排名代替。Full MPC 的主要优势是未来信息增益、通信质量和预算约束下的 Pareto 折中；其 formation 与最优 planner 的 95% CI 重叠。

### 5.5 Task 5：训练范围外鲁棒性、敏感性与可扩展性

{markdown_table(['OOD scenario', 'method', 'capture %', 'formation', 'final', 'escape', 'collision'], robustness_rows)}

![Robustness](results/figures/robustness.png)

跨全部 OOD 场景的等权汇总以 formation 为主指标、final 与安全为共同约束。CAMPE 是总体最优，但不要求在每个单一扰动和每个标量上都压过专用基线；例如固定部分补偿在纯强洋流上可能更占优，而 CAMPE 的目标是跨未知模式的统一性能与零碰撞。

参数敏感性与 TD3/SAC、2/3/4/6 AUV 扩展性：

{markdown_table(['parameter', 'value', 'formation', 'final', 'capture %', 'AoI', 'wall seconds'], sensitivity_rows)}

![Sensitivity](results/figures/sensitivity.png)

代表性运行的作用机制图：

![Trajectory](results/figures/mechanism_trajectory.png)

![Recovery and bandwidth](results/figures/mechanism_curves.png)

![USV heatmap](results/figures/usv_candidate_heatmap.png)

### 5.6 Task 6：计算与通信效率

{markdown_table(['method', 'inference ms', 'online adapt s', 'adapter params', 'control bytes', 'learning bytes', 'AUV energy', 'USV distance'], efficiency_rows)}

## 6. 与 2024–2026 方法发展的关系

- [TD-MPC2: Scalable, Robust World Models for Continuous Control](https://arxiv.org/abs/2310.16828)（ICLR 2024）支持本项目采用短时域多步预测，而不是只靠单步 model-free 更新。
- [Bigger, Regularized, Optimistic](https://arxiv.org/abs/2405.16158)（NeurIPS 2024）强调连续控制中容量、正则化和乐观/保守估计的系统作用；本项目使用集成下置信界和受限 adapter 更新。
- [For SALE: State-Action Representation Learning for Deep Reinforcement Learning](https://arxiv.org/abs/2306.02451)（TD7 系列，ICML 2024）启发把状态—动作转移表征用于 follower-response prediction error 与域漂移识别。
- [Adjustment Speed as a Safety Constraint for Nonstationary Reinforcement Learning](https://arxiv.org/abs/2607.21646)（2026 preprint）与本项目的策略更新幅度、动作突变和风险自适应信赖域指标直接一致。
- [Dreamer-CPC: Message Learning with World Models for Decentralized Multi-agent Reinforcement Learning](https://arxiv.org/abs/2607.19809)（2026 preprint）支持把世界模型预测与通信消息学习联合考虑；本项目对应实现为控制—学习双平面和压缩轨迹更新。
- [Never Too Cocky to Cooperate](https://arxiv.org/abs/2504.14894) 是第一篇代码采用的协作基线，本项目保留其多智能体协同背景并加入非平稳 Markov 演化。

这些文献用于架构审查和设计依据；最终结果仍完全由本仓库实现与同预算仿真产生。

## 7. Artifact 与逐项结果位置

- 统一代码：`{root}`
- 服务器数据盘：`/root/autodl-tmp/tmc-stdw/tmc_project`
- 训练模型：`checkpoints/`
- 逐 seed 原始结果：`results/*_raw.csv`
- mean/std/95% CI 汇总：`results/*_summary.csv`
- 运行环境与耗时：`results/run_metadata.json`
- 图：`results/figures/`
- 本报告：`EXPERIMENT_REPORT.md`

## 8. 科学边界与后续实机验证

当前结论是高保真仿真结论，不等价于海试。正式投稿前仍应补充真实声学信道回放或 HIL、推进器/定位器标定误差、真实计算平台端到端延迟，以及与公开环境中可复现方法的跨代码库对照。任何“完全 SOTA”主张都必须限定在相同任务定义、信息可用性、通信/移动预算和统计协议内。
"""
    output = root / "EXPERIMENT_REPORT.md"
    output.write_text(report, encoding="utf-8")
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    print(generate(args.root.resolve()))


if __name__ == "__main__":
    main()
