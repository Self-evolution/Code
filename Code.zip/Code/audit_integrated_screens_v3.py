from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict

import numpy as np
import pandas as pd
from scipy import stats


def add_utility(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    safety_failure = (
        frame.outcome_escape_medium
        + frame.outcome_collision_medium
        + frame.outcome_border_medium
    )
    frame["benchmark_utility"] = (
        0.35 * frame.capture_success_medium
        + 0.25 * frame.formation_score
        + 0.20 * frame.final_performance
        + 0.10 * frame.target_inside_fraction
        + 0.10 * (1.0 - safety_failure)
    )
    frame["control_plane_utility"] = (
        0.50 * frame.benchmark_utility
        + 0.35 * np.exp(-frame.aoi / 1.5)
        + 0.15 * (1.0 - frame.per)
    )
    return frame


def paired(
    frame: pd.DataFrame,
    key: str,
    left: str,
    right: str,
    metric: str,
) -> Dict[str, float | int]:
    seed = frame.groupby([key, "seed"])[metric].mean().unstack(key)
    seed = seed.dropna(subset=[left, right])
    delta = seed[left] - seed[right]
    ci = float(1.96 * delta.std(ddof=1) / math.sqrt(len(delta)))
    episode = frame.pivot_table(
        index=["scenario", "seed"], columns=key, values=metric
    ).dropna(subset=[left, right])
    return {
        "mean_delta": float(delta.mean()),
        "ci95": ci,
        "ci_lower": float(delta.mean() - ci),
        "ci_upper": float(delta.mean() + ci),
        "seed_wins": int((delta > 0.0).sum()),
        "n_seeds": int(len(delta)),
        "episode_wins": int((episode[left] > episode[right]).sum()),
        "n_episode_pairs": int(len(episode)),
        "seed_deltas": {str(index): float(value) for index, value in delta.items()},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root.resolve()
    screening = root / "results" / "screening"

    ood = add_utility(pd.read_csv(screening / "ood_integrated_v3_raw.csv"))
    mpc = add_utility(pd.read_csv(screening / "mpc_integrated_v3_raw.csv"))
    ood_key = "policy_variant"
    result = {
        "ood_campe_vs_ctta": paired(
            ood, ood_key, "base", "ctta", "benchmark_utility"
        ),
        "full_mpc_vs_fim_control": paired(
            mpc, "mpc_variant", "final", "fim", "control_plane_utility"
        ),
        "full_mpc_vs_fim_mission": paired(
            mpc, "mpc_variant", "final", "fim", "benchmark_utility"
        ),
    }
    scenario = ood.pivot_table(
        index="scenario", columns=ood_key, values="benchmark_utility", aggfunc="mean"
    ).dropna(subset=["base", "ctta"])
    result["ood_campe_vs_ctta"]["scenario_deltas"] = {
        str(index): float(row["base"] - row["ctta"])
        for index, row in scenario.iterrows()
    }
    base = ood[ood[ood_key] == "base"]
    diagnostics = [
        column for column in (
            "mean_kinematic_gate",
            "mean_maneuver_pressure",
            "final_kinematic_coherence",
            "mean_update_weight",
            "action_jump",
        ) if column in base.columns
    ]
    result["ood_campe_vs_ctta"]["campe_scenario_diagnostics"] = (
        base.groupby("scenario")[diagnostics].mean().to_dict(orient="index")
    )
    aoi = mpc.pivot_table(
        index=["scenario", "seed"], columns="mpc_variant", values="aoi"
    ).dropna(subset=["final", "fim"])
    result["full_mpc_vs_fim_control"]["aoi_lower_pairs"] = int(
        (aoi["final"] < aoi["fim"]).sum()
    )
    result["full_mpc_vs_fim_control"]["n_aoi_pairs"] = int(len(aoi))
    output = screening / "integrated_v3_audit.json"
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
