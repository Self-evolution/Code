from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import multiprocessing as mp
import os
from pathlib import Path
from typing import Dict, Iterable, Tuple

import pandas as pd
import torch

from campe.config import SimConfig
from campe.experiment import evaluate_retention, run_episode


VARIANTS = {
    "current": {},
    # Direct action priors: retain the frozen full-model adapter dynamics and
    # spend recognized manoeuvre evidence in the control path instead.  These
    # candidates are deliberately separated from the earlier OOD screen,
    # whose fast-expert variants also reduced maneuver_update_gain and thus
    # confounded control-prior benefit with adaptation suppression.
    "fast_g045_t060": {
        "fast_mode_gain": 0.45,
        "fast_mode_trust_gain": 0.60,
    },
    "fast_g060_t090": {
        "fast_mode_gain": 0.60,
        "fast_mode_trust_gain": 0.90,
    },
    "fast_g075_t120": {
        "fast_mode_gain": 0.75,
        "fast_mode_trust_gain": 1.20,
    },
    "fast_g090_t150": {
        "fast_mode_gain": 0.90,
        "fast_mode_trust_gain": 1.50,
    },
    "expert_g045_t060_b025": {
        "fast_mode_gain": 0.45,
        "fast_mode_trust_gain": 0.60,
        "fast_expert_blend": 0.25,
    },
    "expert_g060_t090_b025": {
        "fast_mode_gain": 0.60,
        "fast_mode_trust_gain": 0.90,
        "fast_expert_blend": 0.25,
    },
    "expert_g060_t090_b040": {
        "fast_mode_gain": 0.60,
        "fast_mode_trust_gain": 0.90,
        "fast_expert_blend": 0.40,
    },
    "expert_g075_t120_b025": {
        "fast_mode_gain": 0.75,
        "fast_mode_trust_gain": 1.20,
        "fast_expert_blend": 0.25,
    },
    "expert_g075_t120_b040": {
        "fast_mode_gain": 0.75,
        "fast_mode_trust_gain": 1.20,
        "fast_expert_blend": 0.40,
    },
    "expert_g075_t120_b055": {
        "fast_mode_gain": 0.75,
        "fast_mode_trust_gain": 1.20,
        "fast_expert_blend": 0.55,
    },
    "expert_g090_t150_b040": {
        "fast_mode_gain": 0.90,
        "fast_mode_trust_gain": 1.50,
        "fast_expert_blend": 0.40,
    },
    "expert_g090_t150_b055": {
        "fast_mode_gain": 0.90,
        "fast_mode_trust_gain": 1.50,
        "fast_expert_blend": 0.55,
    },
    "model_gate_t042_w10": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.42,
        "maneuver_update_model_width": 0.10,
        "maneuver_update_risk_floor": 0.10,
    },
    "model_gate_t045_w10": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.45,
        "maneuver_update_model_width": 0.10,
        "maneuver_update_risk_floor": 0.10,
    },
    "model_gate_t048_w10": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.48,
        "maneuver_update_model_width": 0.10,
        "maneuver_update_risk_floor": 0.10,
    },
    "model_gate_t050_w10": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.50,
        "maneuver_update_model_width": 0.10,
        "maneuver_update_risk_floor": 0.10,
    },
    "model_gate_t045_w15": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.45,
        "maneuver_update_model_width": 0.15,
        "maneuver_update_risk_floor": 0.10,
    },
    "model_gate_t048_w15": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.48,
        "maneuver_update_model_width": 0.15,
        "maneuver_update_risk_floor": 0.10,
    },
    "model_gate_t045_w10_need10": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.45,
        "maneuver_update_model_width": 0.10,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_need_threshold": 0.10,
        "maneuver_update_need_width": 0.40,
    },
    "model_gate_t048_w10_need10": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_model_gate": True,
        "maneuver_update_model_threshold": 0.48,
        "maneuver_update_model_width": 0.10,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_need_threshold": 0.10,
        "maneuver_update_need_width": 0.40,
    },
    "batch2_t010": {
        "kinematic_update_batch": 2,
        "kinematic_update_batch_threshold": 0.10,
    },
    "batch2_t016": {
        "kinematic_update_batch": 2,
        "kinematic_update_batch_threshold": 0.16,
    },
    "batch2_t024": {
        "kinematic_update_batch": 2,
        "kinematic_update_batch_threshold": 0.24,
    },
    "batch3_t010": {
        "kinematic_update_batch": 3,
        "kinematic_update_batch_threshold": 0.10,
    },
    "batch3_t016": {
        "kinematic_update_batch": 3,
        "kinematic_update_batch_threshold": 0.16,
    },
    "batch3_t024": {
        "kinematic_update_batch": 3,
        "kinematic_update_batch_threshold": 0.24,
    },
    "batch4_t010": {
        "kinematic_update_batch": 4,
        "kinematic_update_batch_threshold": 0.10,
    },
    "batch4_t016": {
        "kinematic_update_batch": 4,
        "kinematic_update_batch_threshold": 0.16,
    },
    "batch4_t024": {
        "kinematic_update_batch": 4,
        "kinematic_update_batch_threshold": 0.24,
    },
    "kgmix060": {
        "kinematic_guard_mix_gain": 0.60,
    },
    "kgmix068": {
        "kinematic_guard_mix_gain": 0.68,
    },
    "kgmix076": {
        "kinematic_guard_mix_gain": 0.76,
    },
    "kgmix084": {
        "kinematic_guard_mix_gain": 0.84,
    },
    "kgmix060_ff032": {
        "kinematic_guard_mix_gain": 0.60,
        "kinematic_accel_feedforward_gain": 0.32,
    },
    "kgmix068_ff032": {
        "kinematic_guard_mix_gain": 0.68,
        "kinematic_accel_feedforward_gain": 0.32,
    },
    "kgmix068_ff038": {
        "kinematic_guard_mix_gain": 0.68,
        "kinematic_accel_feedforward_gain": 0.38,
    },
    "kgmix076_ff032": {
        "kinematic_guard_mix_gain": 0.76,
        "kinematic_accel_feedforward_gain": 0.32,
    },
    "kgmix068_prior110": {
        "kinematic_guard_mix_gain": 0.68,
        "kinematic_candidate_prior_weight": 1.10,
    },
    "kgmix068_prior125": {
        "kinematic_guard_mix_gain": 0.68,
        "kinematic_candidate_prior_weight": 1.25,
    },
    "kgmix076_prior110": {
        "kinematic_guard_mix_gain": 0.76,
        "kinematic_candidate_prior_weight": 1.10,
    },
    "kgmix068_slot028": {
        "kinematic_guard_mix_gain": 0.68,
        "kinematic_slot_gain": 0.28,
    },
    "kgmix088": {
        "kinematic_guard_mix_gain": 0.88,
    },
    "kgmix092": {
        "kinematic_guard_mix_gain": 0.92,
    },
    "kgmix100": {
        "kinematic_guard_mix_gain": 1.00,
    },
    "kgmix110": {
        "kinematic_guard_mix_gain": 1.10,
    },
    "kgmix120": {
        "kinematic_guard_mix_gain": 1.20,
    },
    "kgmix088_u080": {
        "kinematic_guard_mix_gain": 0.88,
        "maneuver_update_gain": 0.80,
    },
    "kgmix092_u080": {
        "kinematic_guard_mix_gain": 0.92,
        "maneuver_update_gain": 0.80,
    },
    "kgmix100_u080": {
        "kinematic_guard_mix_gain": 1.00,
        "maneuver_update_gain": 0.80,
    },
    "kgmix088_s016": {
        "kinematic_guard_mix_gain": 0.88,
        "mode_adapter_suppression": 0.16,
    },
    "kgmix092_s016": {
        "kinematic_guard_mix_gain": 0.92,
        "mode_adapter_suppression": 0.16,
    },
    "kgmix100_s016": {
        "kinematic_guard_mix_gain": 1.00,
        "mode_adapter_suppression": 0.16,
    },
    "kgmix092_u080_s016": {
        "kinematic_guard_mix_gain": 0.92,
        "maneuver_update_gain": 0.80,
        "mode_adapter_suppression": 0.16,
    },
    "kgmix100_u080_s016": {
        "kinematic_guard_mix_gain": 1.00,
        "maneuver_update_gain": 0.80,
        "mode_adapter_suppression": 0.16,
    },
    "kgmix100_prior105": {
        "kinematic_guard_mix_gain": 1.00,
        "kinematic_candidate_prior_weight": 1.05,
    },
    "kgmix120_kt025": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 0.25,
    },
    "kgmix120_kt050": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 0.50,
    },
    "kgmix120_kt075": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 0.75,
    },
    "kgmix120_kt100": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.00,
    },
    "kgmix120_kt125": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.25,
    },
    "kgmix120_kt150": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.50,
    },
    "kgmix120_kt200": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.00,
    },
    "kgmix110_kt050": {
        "kinematic_guard_mix_gain": 1.10,
        "kinematic_action_trust_gain": 0.50,
    },
    "kgmix110_kt100": {
        "kinematic_guard_mix_gain": 1.10,
        "kinematic_action_trust_gain": 1.00,
    },
    "kgmix120_kt075_a090": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 0.75,
        "adapter_trust_radius": 0.09,
    },
    "kgmix120_kt100_a090": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.00,
        "adapter_trust_radius": 0.09,
    },
    "kgmix120_kt170": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.70,
    },
    "kgmix120_kt180": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.80,
    },
    "kgmix120_kt190": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 1.90,
    },
    "kgmix120_kt210": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.10,
    },
    "kgmix120_kt220": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.20,
    },
    "kgmix120_kt230": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.30,
    },
    "kgmix120_kt250": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
    },
    "kgmix120_kt275": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.75,
    },
    "kgmix120_kt300": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 3.00,
    },
    "kgmix116_kt200": {
        "kinematic_guard_mix_gain": 1.16,
        "kinematic_action_trust_gain": 2.00,
    },
    "kgmix118_kt200": {
        "kinematic_guard_mix_gain": 1.18,
        "kinematic_action_trust_gain": 2.00,
    },
    "kgmix122_kt200": {
        "kinematic_guard_mix_gain": 1.22,
        "kinematic_action_trust_gain": 2.00,
    },
    "kgmix124_kt200": {
        "kinematic_guard_mix_gain": 1.24,
        "kinematic_action_trust_gain": 2.00,
    },
    "kgmix120_kt250_ka010": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 0.10,
    },
    "kgmix120_kt250_ka025": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 0.25,
    },
    "kgmix120_kt250_ka050": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 0.50,
    },
    "kgmix120_kt250_ka075": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 0.75,
    },
    "kgmix120_kt250_ka100": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 1.00,
    },
    "kgmix120_kt250_ka150": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 1.50,
    },
    "kgmix120_kt250_ka200": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_adapter_trust_gain": 2.00,
    },
    "kgmix120_kt250_a080": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "adapter_trust_radius": 0.08,
    },
    "kgmix120_kt250_a085": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "adapter_trust_radius": 0.085,
    },
    "kgmix120_kt250_a090": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "adapter_trust_radius": 0.09,
    },
    "kgmix120_kt250_kr010": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 0.10,
    },
    "kgmix120_kt250_kr020": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 0.20,
    },
    "kgmix120_kt250_kr030": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 0.30,
    },
    "kgmix120_kt250_kr040": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 0.40,
    },
    "kgmix120_kt250_kr050": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 0.50,
    },
    "kgmix120_kt250_kr075": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 0.75,
    },
    "kgmix120_kt250_kr100": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 1.00,
    },
    "kgmix120_kt250_kr150": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_reference_gain": 1.50,
    },
    "kgmix120_kt250_kd002": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.02,
    },
    "kgmix120_kt250_kd004": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.04,
    },
    "kgmix120_kt250_kd006": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.06,
    },
    "kgmix120_kt250_kd008": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.08,
    },
    "kgmix120_kt250_kd010": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.10,
    },
    "kgmix120_kt250_kd015": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.15,
    },
    "kgmix120_kt250_kd020": {
        "kinematic_guard_mix_gain": 1.20,
        "kinematic_action_trust_gain": 2.50,
        "kinematic_trust_update_damping": 0.20,
    },
    "risk_gate010_u085": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
    },
    "risk_gate020_u085": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.20,
    },
    "risk_gate030_u085": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.30,
    },
    "risk_gate020_u075": {
        "maneuver_update_gain": 0.75,
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.20,
    },
    "pressure_gate010_t010": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.10,
        "maneuver_update_pressure_width": 0.08,
    },
    "pressure_gate010_t012": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.12,
        "maneuver_update_pressure_width": 0.08,
    },
    "pressure_gate010_t014": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.14,
        "maneuver_update_pressure_width": 0.08,
    },
    "pressure_gate020_t012": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.20,
        "maneuver_update_pressure_threshold": 0.12,
        "maneuver_update_pressure_width": 0.08,
    },
    "saturated_t020_w035": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.12,
        "maneuver_update_pressure_width": 0.08,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.35,
    },
    "saturated_t020_w045": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.12,
        "maneuver_update_pressure_width": 0.08,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.45,
    },
    "saturated_t020_w055": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.12,
        "maneuver_update_pressure_width": 0.08,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.55,
    },
    "saturated_t015_w045": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.12,
        "maneuver_update_pressure_width": 0.08,
        "maneuver_update_need_threshold": 0.15,
        "maneuver_update_need_width": 0.45,
    },
    "pressure_sharp_t013_w02": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.13,
        "maneuver_update_pressure_width": 0.02,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.45,
    },
    "pressure_sharp_t014_w02": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.14,
        "maneuver_update_pressure_width": 0.02,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.45,
    },
    "pressure_sharp_t015_w02": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.15,
        "maneuver_update_pressure_width": 0.02,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.45,
    },
    "pressure_sharp_t016_w02": {
        "maneuver_update_formation_gate": True,
        "maneuver_update_risk_floor": 0.10,
        "maneuver_update_pressure_threshold": 0.16,
        "maneuver_update_pressure_width": 0.02,
        "maneuver_update_need_threshold": 0.20,
        "maneuver_update_need_width": 0.45,
    },
    "trust105": {
        "maneuver_trust_gain": 1.05,
    },
    "trust120": {
        "maneuver_trust_gain": 1.20,
    },
    "trust135": {
        "maneuver_trust_gain": 1.35,
    },
    "trust150": {
        "maneuver_trust_gain": 1.50,
    },
    "gate105_trust120": {
        "maneuver_gate_gain": 1.05,
        "maneuver_trust_gain": 1.20,
    },
    "gradema050_t030": {
        "maneuver_gradient_ema_decay": 0.50,
        "maneuver_gradient_ema_threshold": 0.30,
        "maneuver_gradient_ema_width": 0.12,
    },
    "gradema070_t030": {
        "maneuver_gradient_ema_decay": 0.70,
        "maneuver_gradient_ema_threshold": 0.30,
        "maneuver_gradient_ema_width": 0.12,
    },
    "gradema085_t030": {
        "maneuver_gradient_ema_decay": 0.85,
        "maneuver_gradient_ema_threshold": 0.30,
        "maneuver_gradient_ema_width": 0.12,
    },
    "gradema070_t025": {
        "maneuver_gradient_ema_decay": 0.70,
        "maneuver_gradient_ema_threshold": 0.25,
        "maneuver_gradient_ema_width": 0.12,
    },
    "adaptive100_u070_s25": {
        "action_trust_formation_gain": 1.00,
        "maneuver_update_gain": 0.70,
        "mode_adapter_suppression": 0.25,
    },
    "adaptive200_u070_s25": {
        "action_trust_formation_gain": 2.00,
        "maneuver_update_gain": 0.70,
        "mode_adapter_suppression": 0.25,
    },
    "adaptive200_u065_s25": {
        "action_trust_formation_gain": 2.00,
        "maneuver_update_gain": 0.65,
        "mode_adapter_suppression": 0.25,
    },
    "adaptive200_u060_s30": {
        "action_trust_formation_gain": 2.00,
        "maneuver_update_gain": 0.60,
        "mode_adapter_suppression": 0.30,
    },
    "adaptive200_u055_s35": {
        "action_trust_formation_gain": 2.00,
        "maneuver_update_gain": 0.55,
        "mode_adapter_suppression": 0.35,
    },
    "adaptive300_u070_s25": {
        "action_trust_formation_gain": 3.00,
        "maneuver_update_gain": 0.70,
        "mode_adapter_suppression": 0.25,
    },
    "adaptive200_u075_s20": {
        "action_trust_formation_gain": 2.00,
        "maneuver_update_gain": 0.75,
        "mode_adapter_suppression": 0.20,
    },
    "adaptive300_u075_s20": {
        "action_trust_formation_gain": 3.00,
        "maneuver_update_gain": 0.75,
        "mode_adapter_suppression": 0.20,
    },
    "adaptive200_u085_s12": {
        "action_trust_formation_gain": 2.00,
    },
}

ABLATIONS = ("full", "no_kinematic_gate", "no_trust_region")
SCENARIOS = ("adversarial_mix", "blackout_chase", "recurrent_shift")


def stress_config(cfg: SimConfig) -> SimConfig:
    return replace(
        cfg,
        n_auv=6,
        desired_radius=10.5,
        radial_tolerance=2.8,
        capture_gap_multiplier=1.28,
        capture_hold=24,
        capture_required_fraction=0.78,
        initial_angle_jitter=0.78,
        initial_radius_offset=8.0,
        initial_radius_std=6.0,
        safety_distance=9.0,
        collision_distance=6.0,
    )


def reference_worker(task: Tuple[str, SimConfig, int]) -> Tuple[int, float]:
    root_text, cfg, seed = task
    torch.set_num_threads(1)
    row, _ = run_episode(
        Path(root_text), cfg, "source_only", "source", seed + 40_000,
        planner="full_mpc",
    )
    return seed, float(row["final_performance"])


def worker(task: Tuple[str, str, SimConfig, str, str, int, float]) -> Dict[str, object]:
    root_text, variant, cfg, ablation, scenario, seed, reference = task
    torch.set_num_threads(1)
    row, controller = run_episode(
        Path(root_text), cfg, "campe", scenario, seed,
        planner="full_mpc", ablation=ablation, retain_controller=True,
    )
    assert controller is not None
    row.update(evaluate_retention(Path(root_text), cfg, controller, seed, "td3", reference))
    row["architecture_variant"] = variant
    return row


def collect(pool: ProcessPoolExecutor, tasks: Iterable[Tuple], fn) -> list:
    futures = [pool.submit(fn, task) for task in tasks]
    rows = []
    for index, future in enumerate(as_completed(futures), start=1):
        rows.append(future.result())
        if index % max(1, len(futures) // 10) == 0 or index == len(futures):
            print(f"[arch-screen] {index}/{len(futures)}", flush=True)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--tag", default="arch_candidates_v3")
    parser.add_argument("--variants", nargs="+", choices=tuple(VARIANTS))
    args = parser.parse_args()

    root = args.root.resolve()
    base = SimConfig()
    selected = args.variants or list(VARIANTS)
    cfgs = {
        name: stress_config(replace(base, **overrides))
        for name, overrides in VARIANTS.items()
        if name in selected
    }
    context = mp.get_context("spawn")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=context) as pool:
        references = dict(collect(
            pool,
            [(str(root), stress_config(base), seed) for seed in args.seeds],
            reference_worker,
        ))
        tasks = [
            (str(root), variant, cfg, ablation, scenario, seed, references[seed])
            for variant, cfg in cfgs.items()
            for ablation in ABLATIONS
            for scenario in SCENARIOS
            for seed in args.seeds
        ]
        rows = collect(pool, tasks, worker)

    frame = pd.DataFrame(rows)
    failure = (
        frame.outcome_escape_medium
        + frame.outcome_collision_medium
        + frame.outcome_border_medium
    )
    frame["benchmark_utility"] = (
        0.35 * frame.capture_success_medium
        + 0.25 * frame.formation_score
        + 0.20 * frame.final_performance
        + 0.10 * frame.target_inside_fraction
        + 0.10 * (1.0 - failure)
    )
    frame["architecture_score"] = (
        frame.benchmark_utility
        - 0.025 * frame.policy_update_magnitude
        - 0.20 * frame.old_domain_forgetting
        - 0.05 * frame.value_overestimation
        - frame.collision_rate
    )
    output_dir = root / "results" / "screening"
    output_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_dir / f"{args.tag}_raw.csv", index=False)
    summary = (
        frame.groupby(["architecture_variant", "ablation"], as_index=False)[
            [
                "benchmark_utility",
                "architecture_score",
                "policy_update_magnitude",
                "value_overestimation",
                "action_jump",
            ]
        ]
        .mean(numeric_only=True)
    )
    summary.to_csv(output_dir / f"{args.tag}_summary.csv", index=False)
    pivot = summary.pivot(index="architecture_variant", columns="ablation", values="architecture_score")
    pivot["full_margin"] = pivot["full"] - pivot[["no_kinematic_gate", "no_trust_region"]].max(axis=1)
    print(pivot.sort_values("full_margin", ascending=False).round(6).to_string())


if __name__ == "__main__":
    main()
