from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


RESULTS = Path(__file__).resolve().parent / "results"


def add_utility(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    safety_failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - safety_failure)
    )
    return frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--control", type=Path, default=RESULTS / "control_plane_raw.csv")
    parser.add_argument("--ablation", type=Path, default=RESULTS / "safety_ablation_raw.csv")
    parser.add_argument("--methods", type=Path)
    args = parser.parse_args()

    if args.methods is not None:
        methods = add_utility(pd.read_csv(args.methods))
        columns = [
            "capture_success_medium",
            "capture_success_strict",
            "formation_score",
            "final_performance",
            "outcome_collision_medium",
            "outcome_timeout_medium",
            "benchmark_utility",
        ]
        print("METHOD RANKING")
        print(
            methods.groupby("method")[columns]
            .mean()
            .sort_values("benchmark_utility", ascending=False)
            .round(5)
            .to_string()
        )
        print("\nMETHODS BY SCENARIO")
        print(
            methods.groupby(["scenario", "method"])[columns]
            .mean()
            .round(5)
            .to_string()
        )
        return

    control = add_utility(pd.read_csv(args.control))
    control_columns = [
        "capture_success_medium",
        "formation_score",
        "final_performance",
        "target_inside_fraction",
        "outcome_collision_medium",
        "outcome_timeout_medium",
        "aoi",
        "per",
        "usv_distance",
        "benchmark_utility",
    ]
    control_columns.extend(
        column
        for column in (
            "planner_target_speed_ratio_mean",
            "planner_target_speed_ratio_p90",
        )
        if column in control.columns
    )
    print("PLANNER OVERALL")
    print(
        control.groupby("planner")[control_columns]
        .mean()
        .sort_values("benchmark_utility", ascending=False)
        .round(4)
        .to_string()
    )
    print("\nPLANNER BY SCENARIO")
    print(
        control.groupby(["scenario", "planner"])[control_columns]
        .mean()
        .round(4)
        .to_string()
    )
    diagnostic_columns = [
        column
        for column in (
            "scenario",
            "seed",
            "capture_success_loose",
            "capture_success_medium",
            "capture_success_strict",
            "capture_time_medium",
            "capture_max_streak_medium",
            "capture_final_fraction_medium",
            "capture_final_score_medium",
            "radius_error",
            "max_angle_gap",
            "target_inside_fraction",
            "formation_score",
            "final_performance",
            "aoi",
            "per",
        )
        if column in control.columns
    ]
    print("\nTOP PLANNER EPISODES")
    print(
        control.loc[
            control.planner.isin(("full_mpc", "dynamic_period", "dual_plane")),
            ["planner", *diagnostic_columns],
        ]
        .sort_values(["scenario", "planner", "seed"])
        .round(4)
        .to_string(index=False)
    )

    if not args.ablation.exists():
        return
    ablation = add_utility(pd.read_csv(args.ablation))
    ablation["architecture_score"] = (
        ablation["benchmark_utility"]
        - 0.025 * ablation["policy_update_magnitude"]
        - 0.20 * ablation["old_domain_forgetting"]
        - 0.05 * ablation["value_overestimation"]
        - ablation["collision_rate"]
    )
    ablation_columns = [
        "capture_success_medium",
        "formation_score",
        "final_performance",
        "collision_rate",
        "old_domain_forgetting",
        "value_overestimation",
        "policy_update_magnitude",
        "benchmark_utility",
        "architecture_score",
    ]
    print("\nABLATION OVERALL")
    print(
        ablation.groupby("ablation")[ablation_columns]
        .mean()
        .sort_values("architecture_score", ascending=False)
        .round(4)
        .to_string()
    )
    print("\nABLATION BY SCENARIO")
    print(
        ablation.groupby(["scenario", "ablation"])[ablation_columns]
        .mean()
        .round(4)
        .to_string()
    )

    gate_columns = [
        column
        for column in (
            "capture_success_medium",
            "formation_score",
            "final_performance",
            "policy_update_magnitude",
            "mean_kinematic_gate",
            "partial_compensation_selection_rate",
            "guard_selection_rate",
            "effect_compensation_selection_rate",
            "mean_update_weight",
            "mean_model_drift",
            "action_jump",
        )
        if column in ablation.columns
    ]
    gate_pair = ablation.loc[
        ablation.ablation.isin(("full", "no_kinematic_gate"))
    ]
    print("\nKINEMATIC GATE PAIR BY SCENARIO")
    print(
        gate_pair.groupby(["scenario", "ablation"])[gate_columns]
        .mean()
        .round(5)
        .to_string()
    )
    paired_metrics = [
        column
        for column in (
            "capture_success_medium",
            "capture_final_score_medium",
            "radius_error",
            "max_angle_gap",
            "target_inside_fraction",
            "formation_score",
            "final_performance",
            "policy_update_magnitude",
            "guard_selection_rate",
        )
        if column in gate_pair.columns
    ]
    paired = gate_pair.pivot(
        index=["scenario", "seed"],
        columns="ablation",
        values=paired_metrics,
    )
    print("\nKINEMATIC GATE FULL MINUS ABLATION BY SEED")
    print(
        (paired.xs("full", axis=1, level=1)
         - paired.xs("no_kinematic_gate", axis=1, level=1))
        .round(4)
        .to_string()
    )


if __name__ == "__main__":
    main()
