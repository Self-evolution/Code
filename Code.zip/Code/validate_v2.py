from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Iterable

import numpy as np
import pandas as pd

from campe.config import SimConfig
from campe.experiment import run_episode


PROFILES = ("loose", "medium", "strict")
OUTCOMES = ("success", "escape", "collision", "border", "timeout")


def _validate_frame(frame: pd.DataFrame, name: str) -> Dict[str, object]:
    errors = []
    for profile in PROFILES:
        columns = [f"outcome_{label}_{profile}" for label in OUTCOMES]
        missing = [column for column in columns if column not in frame]
        if missing:
            errors.append(f"{name}: missing {missing}")
            continue
        sums = frame[columns].sum(axis=1).to_numpy(dtype=float)
        bad = int(np.count_nonzero(~np.isclose(sums, 1.0)))
        if bad:
            errors.append(f"{name}: {bad} rows do not have exactly one {profile} outcome")

        mission_column = f"mission_outcome_{profile}"
        if mission_column in frame:
            expected = frame[columns].idxmax(axis=1).str.replace(
                f"outcome_", "", regex=False
            ).str.replace(f"_{profile}", "", regex=False)
            mismatch = int((expected != frame[mission_column]).sum())
            if mismatch:
                errors.append(f"{name}: {mismatch} {profile} mission labels disagree with one-hot outcomes")

    capture_columns = [f"capture_success_{profile}" for profile in PROFILES]
    if all(column in frame for column in capture_columns):
        loose = frame[capture_columns[0]].to_numpy(dtype=float)
        medium = frame[capture_columns[1]].to_numpy(dtype=float)
        strict = frame[capture_columns[2]].to_numpy(dtype=float)
        bad = int(np.count_nonzero((loose < medium) | (medium < strict)))
        if bad:
            errors.append(f"{name}: {bad} rows violate loose >= medium >= strict")

    numeric = frame.select_dtypes(include=[np.number])
    nonfinite = int(np.count_nonzero(~np.isfinite(numeric.to_numpy(dtype=float))))
    if nonfinite:
        errors.append(f"{name}: {nonfinite} non-finite numeric values")
    return {"file": name, "rows": int(len(frame)), "errors": errors}


def validate_results(root: Path) -> Dict[str, object]:
    validations = []
    for path in sorted((root / "results").glob("*_raw.csv")):
        validations.append(_validate_frame(pd.read_csv(path), path.name))
    all_errors = [error for validation in validations for error in validation["errors"]]
    return {
        "status": "ok" if not all_errors else "failed",
        "files": validations,
        "errors": all_errors,
    }


def smoke(root: Path, seeds: Iterable[int]) -> Dict[str, object]:
    cfg = SimConfig()
    rows = []
    for seed in seeds:
        row, _ = run_episode(root, cfg, "campe", "adversarial_mix", seed)
        rows.append(row)
    frame = pd.DataFrame(rows)
    validation = _validate_frame(frame, "smoke")
    metrics = [
        "capture_success_loose",
        "capture_success_medium",
        "capture_success_strict",
        "outcome_success_medium",
        "outcome_escape_medium",
        "outcome_collision_medium",
        "outcome_border_medium",
        "outcome_timeout_medium",
        "formation_score",
        "final_performance",
        "radius_error",
        "max_angle_gap",
        "target_inside_fraction",
        "collision_rate",
        "border_rate",
        "aoi",
        "per",
    ]
    return {
        "status": "ok" if not validation["errors"] else "failed",
        "validation": validation,
        "means": {metric: float(frame[metric].mean()) for metric in metrics},
        "episodes": frame[
            ["seed", "mission_outcome_loose", "mission_outcome_medium", "mission_outcome_strict"]
        ].to_dict(orient="records"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate the strict V2 capture protocol and raw results.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--seeds", type=int, nargs="+", default=[0])
    args = parser.parse_args()
    root = args.root.resolve()
    result = smoke(root, args.seeds) if args.smoke else validate_results(root)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["status"] != "ok":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
