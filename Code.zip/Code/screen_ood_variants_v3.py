from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import multiprocessing as mp
import os
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd
import torch

from campe.config import OOD_SCENARIOS, SimConfig
from campe.experiment import run_episode


VARIANTS = {
    "ctta": ("ctta", {}),
    "base": ("campe", {}),
    "trust180": ("campe", {"action_trust_base": 1.80}),
    "trust220": ("campe", {"action_trust_base": 2.20}),
    "trust180_r160": (
        "campe",
        {"action_trust_base": 1.80, "action_trust_risk_gain": 1.60},
    ),
    "adapter075": ("campe", {"adapter_trust_radius": 0.075}),
    "trust180_adapter075": (
        "campe",
        {"action_trust_base": 1.80, "adapter_trust_radius": 0.075},
    ),
    "trust220_adapter075": (
        "campe",
        {"action_trust_base": 2.20, "adapter_trust_radius": 0.075},
    ),
    "trust180_adapter100": (
        "campe",
        {"action_trust_base": 1.80, "adapter_trust_radius": 0.10},
    ),
    "observer": ("campe", {"robust_observer_gain": 1.0}),
    "maneuver": (
        "campe",
        {"maneuver_gate_gain": 0.90, "maneuver_trust_gain": 0.90},
    ),
    "maneuver_trust_only": (
        "campe",
        {"maneuver_gate_gain": 0.0, "maneuver_trust_gain": 1.40},
    ),
    "maneuver_g025_t140": (
        "campe",
        {"maneuver_gate_gain": 0.25, "maneuver_trust_gain": 1.40},
    ),
    "maneuver_g045_t120": (
        "campe",
        {"maneuver_gate_gain": 0.45, "maneuver_trust_gain": 1.20},
    ),
    "maneuver_g065_t110": (
        "campe",
        {"maneuver_gate_gain": 0.65, "maneuver_trust_gain": 1.10},
    ),
    "maneuver_update060": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.60,
            "mode_adapter_suppression": 0.25,
        },
    ),
    "maneuver_update085": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.85,
            "mode_adapter_suppression": 0.12,
            "adapter_trust_radius": 0.075,
        },
    ),
    "maneuver_update120": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 1.20,
            "mode_adapter_suppression": 0.0,
            "adapter_trust_radius": 0.10,
        },
    ),
    "maneuver_update085_fast": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 1.60,
            "maneuver_update_gain": 0.85,
            "mode_adapter_suppression": 0.12,
            "action_trust_base": 1.80,
            "action_trust_risk_gain": 1.40,
            "adapter_trust_radius": 0.075,
        },
    ),
    "maneuver_update085_free": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 1.80,
            "maneuver_update_gain": 0.85,
            "mode_adapter_suppression": 0.12,
            "action_trust_base": 2.20,
            "action_trust_risk_gain": 1.40,
            "adapter_trust_radius": 0.075,
        },
    ),
    "observer_update085_fast": (
        "campe",
        {
            "robust_observer_gain": 1.0,
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 1.60,
            "maneuver_update_gain": 0.85,
            "mode_adapter_suppression": 0.12,
            "action_trust_base": 1.80,
            "action_trust_risk_gain": 1.40,
            "adapter_trust_radius": 0.075,
        },
    ),
    "fast_expert": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.60,
            "mode_adapter_suppression": 0.25,
            "fast_mode_gain": 1.0,
            "fast_mode_trust_gain": 1.80,
            "adapter_trust_radius": 0.10,
        },
    ),
    "fast_expert_soft": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.60,
            "mode_adapter_suppression": 0.25,
            "fast_mode_gain": 0.72,
            "fast_mode_trust_gain": 1.40,
            "adapter_trust_radius": 0.075,
        },
    ),
    "nominal_guard_expert": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.60,
            "mode_adapter_suppression": 0.25,
            "fast_mode_gain": 1.0,
            "fast_mode_trust_gain": 1.80,
            "fast_expert_blend": 1.0,
            "adapter_trust_radius": 0.10,
        },
    ),
    "nominal_guard_soft": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.60,
            "mode_adapter_suppression": 0.25,
            "fast_mode_gain": 0.85,
            "fast_mode_trust_gain": 1.40,
            "fast_expert_blend": 0.70,
            "adapter_trust_radius": 0.075,
        },
    ),
    "nominal_guard_hard": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 1.20,
            "maneuver_update_gain": 0.85,
            "mode_adapter_suppression": 0.0,
            "fast_mode_gain": 1.20,
            "fast_mode_trust_gain": 3.00,
            "fast_expert_blend": 2.00,
            "adapter_trust_radius": 0.10,
        },
    ),
    "nominal_guard_selective": (
        "campe",
        {
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
            "maneuver_update_gain": 0.60,
            "mode_adapter_suppression": 0.25,
            "fast_mode_gain": 1.0,
            "fast_mode_threshold": 0.34,
            "fast_mode_width": 0.28,
            "fast_mode_trust_gain": 1.40,
            "fast_expert_blend": 0.70,
            "adapter_trust_radius": 0.075,
        },
    ),
    "observer_maneuver": (
        "campe",
        {
            "robust_observer_gain": 1.0,
            "maneuver_gate_gain": 0.90,
            "maneuver_trust_gain": 0.90,
        },
    ),
    "observer_maneuver_t160": (
        "campe",
        {
            "robust_observer_gain": 1.0,
            "maneuver_gate_gain": 1.00,
            "maneuver_trust_gain": 1.00,
            "action_trust_base": 1.60,
        },
    ),
    "observer_maneuver_t180_a075": (
        "campe",
        {
            "robust_observer_gain": 1.0,
            "maneuver_gate_gain": 1.00,
            "maneuver_trust_gain": 1.00,
            "action_trust_base": 1.80,
            "adapter_trust_radius": 0.075,
        },
    ),
}


Task = Tuple[str, str, str, SimConfig, str, int]


def _worker(task: Task) -> Dict[str, object]:
    root_text, variant, method, cfg, scenario, seed = task
    torch.set_num_threads(1)
    row, _ = run_episode(
        Path(root_text), cfg, method, scenario, seed,
        planner="full_mpc", ablation="full",
    )
    row["policy_variant"] = variant
    return row


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Paired OOD calibration screen for CAMPE versus CTTA."
    )
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--tag", default="ood_calibration_v3")
    parser.add_argument("--variants", nargs="+", choices=tuple(VARIANTS))
    parser.add_argument(
        "--scenarios", nargs="+", choices=tuple(OOD_SCENARIOS),
        default=list(OOD_SCENARIOS),
    )
    args = parser.parse_args()

    root = args.root.resolve()
    selected = args.variants or list(VARIANTS)
    base = SimConfig()
    tasks: List[Task] = []
    for variant in selected:
        method, overrides = VARIANTS[variant]
        cfg = replace(base, **overrides)
        for scenario in args.scenarios:
            for seed in args.seeds:
                tasks.append((str(root), variant, method, cfg, scenario, seed))

    rows: List[Dict[str, object]] = []
    context = mp.get_context("spawn")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=context) as pool:
        futures = [pool.submit(_worker, task) for task in tasks]
        for index, future in enumerate(as_completed(futures), start=1):
            rows.append(future.result())
            if index % max(1, len(tasks) // 12) == 0 or index == len(tasks):
                print(f"[ood-v3] {index}/{len(tasks)}", flush=True)

    frame = pd.DataFrame(rows)
    failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - failure)
    )
    output = root / "results" / "screening"
    output.mkdir(parents=True, exist_ok=True)
    raw_path = output / f"{args.tag}_raw.csv"
    summary_path = output / f"{args.tag}_summary.csv"
    paired_path = output / f"{args.tag}_paired.csv"
    frame.to_csv(raw_path, index=False)

    metrics = [
        "benchmark_utility", "capture_success_medium", "formation_score",
        "final_performance", "target_inside_fraction", "outcome_timeout_medium",
        "action_jump", "policy_update_magnitude", "mean_update_weight",
        "mean_uncertainty", "value_overestimation",
    ]
    summary = frame.groupby("policy_variant")[metrics].mean().sort_values(
        "benchmark_utility", ascending=False
    )
    summary.to_csv(summary_path)

    pivot = frame.pivot_table(
        index=["scenario", "seed"], columns="policy_variant",
        values="benchmark_utility",
    )
    paired_rows = []
    for variant in selected:
        if variant == "ctta" or "ctta" not in pivot or variant not in pivot:
            continue
        delta = pivot[variant] - pivot["ctta"]
        for scenario, values in delta.groupby(level="scenario"):
            paired_rows.append({
                "policy_variant": variant,
                "scenario": scenario,
                "mean_delta": float(values.mean()),
                "win_rate": float((values > 0.0).mean()),
                "n": int(len(values)),
            })
        paired_rows.append({
            "policy_variant": variant,
            "scenario": "__overall__",
            "mean_delta": float(delta.mean()),
            "win_rate": float((delta > 0.0).mean()),
            "n": int(len(delta)),
        })
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(paired_path, index=False)
    print(summary.round(6).to_string(), flush=True)
    if not paired.empty:
        print("\nPaired delta versus CTTA:", flush=True)
        print(
            paired[paired.scenario == "__overall__"]
            .sort_values("mean_delta", ascending=False)
            .round(6).to_string(index=False),
            flush=True,
        )
    print(f"raw={raw_path}\nsummary={summary_path}\npaired={paired_path}", flush=True)


if __name__ == "__main__":
    main()
