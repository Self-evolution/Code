from __future__ import annotations

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Tuple

import pandas as pd
import torch

from campe.config import SimConfig
from campe.experiment import aggregate, checkpoint_path


STAGES = ("domain_shift", "adaptation", "safety_ablation", "control_plane", "robustness", "sensitivity")
GROUPS = {
    "domain_shift": ["scenario", "method"],
    "adaptation": ["scenario", "method"],
    "safety_ablation": ["ablation"],
    "control_plane": ["planner"],
    "robustness": ["scenario", "method"],
    "sensitivity": ["sensitivity_parameter", "sensitivity_value"],
}


def _partition(seeds: List[int], count: int) -> List[List[int]]:
    count = max(1, min(count, len(seeds)))
    return [seeds[index::count] for index in range(count)]


def _archive_results(root: Path) -> Path | None:
    result_dir = root / "results"
    if not result_dir.exists() or not any(result_dir.iterdir()):
        result_dir.mkdir(parents=True, exist_ok=True)
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive = root / f"results_archive_{stamp}"
    if archive.exists():
        raise FileExistsError(archive)
    shutil.move(str(result_dir), str(archive))
    result_dir.mkdir(parents=True, exist_ok=True)
    return archive


def _checkpoint_metadata(root: Path) -> Dict[str, Dict[str, float]]:
    records: Dict[str, Dict[str, float]] = {}
    for backbone, n_auv in (("td3", 2), ("td3", 3), ("td3", 4), ("td3", 6), ("sac", 4)):
        payload = torch.load(checkpoint_path(root, backbone, n_auv), map_location="cpu", weights_only=False)
        records[f"{backbone}_{n_auv}auv"] = {
            "val_mse": float(payload.get("val_mse", float("nan"))),
            "val_mae": float(payload.get("val_mae", float("nan"))),
            "train_seconds": 0.0,
            "parameters": float(sum(value.numel() for value in payload["state_dict"].values())),
            "samples": int(payload.get("samples", 0)),
            "epochs": int(payload.get("epochs", 0)),
        }
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the official V3 protocol in deterministic seed shards.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--mode", choices=("quick", "full"), default="full")
    parser.add_argument("--stages", nargs="+", choices=STAGES, default=list(STAGES))
    parser.add_argument("--shards-per-stage", type=int, default=4)
    parser.add_argument("--max-parallel", type=int, default=8)
    parser.add_argument("--seed-offset", type=int, default=0)
    parser.add_argument("--archive-results", action="store_true")
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required")

    root = args.root.resolve()
    archive = _archive_results(root) if args.archive_results else None
    (root / "results").mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    shard_base = root / f"stage_shards_{args.mode}_{stamp}"
    shard_base.mkdir(parents=True, exist_ok=False)
    log_dir = root / "logs_v2"
    log_dir.mkdir(parents=True, exist_ok=True)

    main_count, sensitivity_count = (3, 2) if args.mode == "quick" else (10, 5)
    main_seeds = list(range(args.seed_offset, args.seed_offset + main_count))
    sensitivity_seeds = list(range(args.seed_offset, args.seed_offset + sensitivity_count))
    jobs: List[Dict[str, object]] = []
    for stage in args.stages:
        seeds = sensitivity_seeds if stage == "sensitivity" else main_seeds
        for shard_index, shard_seeds in enumerate(_partition(seeds, args.shards_per_stage)):
            shard_root = shard_base / f"{stage}_{shard_index}"
            shard_root.mkdir(parents=True)
            (shard_root / "checkpoints").symlink_to(root / "checkpoints", target_is_directory=True)
            jobs.append({
                "stage": stage,
                "index": shard_index,
                "seeds": shard_seeds,
                "root": shard_root,
            })

    pending = jobs.copy()
    active: Dict[Tuple[str, int], Tuple[subprocess.Popen[str], object, Dict[str, object]]] = {}
    started_unix = time.time()
    stage_script = root / "run_stage_v2.py"
    child_env = os.environ.copy()
    child_env.setdefault("OMP_NUM_THREADS", "1")
    child_env.setdefault("MKL_NUM_THREADS", "1")
    child_env.setdefault("OPENBLAS_NUM_THREADS", "1")

    while pending or active:
        while pending and len(active) < max(1, args.max_parallel):
            job = pending.pop(0)
            stage = str(job["stage"])
            index = int(job["index"])
            seeds = list(job["seeds"])
            shard_root = Path(job["root"])
            log_handle = (log_dir / f"{args.mode}_{stage}_shard{index}.log").open("w", encoding="utf-8")
            command = [
                sys.executable,
                str(stage_script),
                "--root",
                str(shard_root),
                "--stage",
                stage,
                "--seeds",
                *[str(seed) for seed in seeds],
            ]
            process = subprocess.Popen(
                command,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                text=True,
                env=child_env,
            )
            active[(stage, index)] = (process, log_handle, job)
            print(f"[shard:start] {stage}/{index} pid={process.pid} seeds={seeds}", flush=True)

        finished: List[Tuple[str, int]] = []
        for key, (process, log_handle, job) in active.items():
            code = process.poll()
            if code is None:
                continue
            log_handle.close()
            stage, index = key
            if code != 0:
                for other_process, other_handle, _ in active.values():
                    if other_process.poll() is None:
                        other_process.terminate()
                    if not other_handle.closed:
                        other_handle.close()
                raise RuntimeError(f"shard {stage}/{index} failed; see {log_dir}")
            timing = json.loads(
                (Path(job["root"]) / "results" / f"{stage}_timing.json").read_text(encoding="utf-8")
            )
            job["seconds"] = float(timing["seconds"])
            job["rows"] = int(timing["rows"])
            print(f"[shard:done] {stage}/{index} rows={timing['rows']} seconds={timing['seconds']:.2f}", flush=True)
            finished.append(key)
        for key in finished:
            active.pop(key)
        if active and not finished:
            time.sleep(1.0)

    stage_seconds: Dict[str, float] = {}
    stage_compute_seconds: Dict[str, float] = {}
    expected_seed_counts = {
        stage: len(sensitivity_seeds if stage == "sensitivity" else main_seeds)
        for stage in args.stages
    }
    for stage in args.stages:
        stage_jobs = [job for job in jobs if job["stage"] == stage]
        frames = [
            pd.read_csv(Path(job["root"]) / "results" / f"{stage}_raw.csv")
            for job in stage_jobs
        ]
        raw = pd.concat(frames, ignore_index=True)
        if raw.seed.nunique() != expected_seed_counts[stage]:
            raise RuntimeError(f"{stage}: merged seed count mismatch")
        raw.to_csv(root / "results" / f"{stage}_raw.csv", index=False)
        aggregate(raw, GROUPS[stage]).to_csv(
            root / "results" / f"{stage}_summary.csv", index=False
        )
        stage_seconds[stage] = max(float(job["seconds"]) for job in stage_jobs)
        stage_compute_seconds[stage] = sum(float(job["seconds"]) for job in stage_jobs)

    cfg = SimConfig()
    metadata = {
        "mode": args.mode,
        "stages": args.stages,
        "main_seeds": main_seeds,
        "sensitivity_seeds": sensitivity_seeds,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "training": _checkpoint_metadata(root),
        "config": cfg.__dict__,
        "started_unix": started_unix,
        "stage_seconds": stage_seconds,
        "stage_compute_seconds": stage_compute_seconds,
        "finished_unix": time.time(),
        "parallel_workers": args.max_parallel,
        "shards_per_stage": args.shards_per_stage,
        "shard_artifacts": str(shard_base),
        "previous_results_archive": str(archive) if archive else None,
        "code_manifest": str(root / "code_manifest_v3.sha256"),
        "capture_protocol": "loose/medium/strict on identical trajectories; five exclusive outcomes",
        "common_random_numbers": "independent counter-indexed channel/sensor/local streams",
    }
    (root / "results" / "run_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "status": "complete",
        "stage_seconds": stage_seconds,
        "stage_compute_seconds": stage_compute_seconds,
        "shard_artifacts": str(shard_base),
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
