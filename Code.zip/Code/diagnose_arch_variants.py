from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.csv)
    failure = (
        frame.outcome_escape_medium
        + frame.outcome_collision_medium
        + frame.outcome_border_medium
    )
    frame["benchmark_utility"] = (
        0.35 * frame.capture_success_medium
        + 0.25 * frame.formation_score
        + 0.20 * frame.final_performance
        + 0.10 * frame.target_inside_fraction
        + 0.10 * (1.0 - failure)
    )
    frame["architecture_score"] = (
        frame.benchmark_utility
        - 0.025 * frame.policy_update_magnitude
        - 0.20 * frame.old_domain_forgetting
        - 0.05 * frame.value_overestimation
        - frame.collision_rate
    )
    metrics = [
        "benchmark_utility",
        "architecture_score",
        "formation_score",
        "final_performance",
        "policy_update_magnitude",
        "value_overestimation",
        "action_jump",
        "mean_kinematic_gate",
        "mean_maneuver_pressure",
        "mean_model_drift",
        "mean_sensor_gate",
        "mean_update_weight",
        "radius_error",
        "max_angle_gap",
        "target_inside_fraction",
    ]
    metrics = [metric for metric in metrics if metric in frame.columns]
    print(
        frame.groupby(["scenario", "architecture_variant", "ablation"])[metrics]
        .mean(numeric_only=True)
        .round(6)
        .to_string()
    )


if __name__ == "__main__":
    main()
