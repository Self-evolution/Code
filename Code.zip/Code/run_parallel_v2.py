from __future__ import annotations

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Tuple

import torch

from campe.config import SimConfig
from campe.experiment import checkpoint_path


STAGES = ("domain_shift", "adaptation", "safety_ablation", "control_plane", "robustness", "sensitivity")


def _archive_results(root: Path) -> None:
    result_dir = root / "results"
    if not result_dir.exists() or not any(result_dir.iterdir()):
        result_dir.mkdir(parents=True, exist_ok=True)
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive = root / f"results_archive_{stamp}"
    if archive.exists():
        raise FileExistsError(archive)
    shutil.move(str(result_dir), str(archive))
    result_dir.mkdir(parents=True, exist_ok=True)
    print(f"[archive] {archive}", flush=True)


def _checkpoint_metadata(root: Path) -> Dict[str, Dict[str, float]]:
    records: Dict[str, Dict[str, float]] = {}
    for backbone, n_auv in (("td3", 2), ("td3", 3), ("td3", 4), ("td3", 6), ("sac", 4)):
        path = checkpoint_path(root, backbone, n_auv)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        records[f"{backbone}_{n_auv}auv"] = {
            "val_mse": float(payload.get("val_mse", float("nan"))),
            "val_mae": float(payload.get("val_mae", float("nan"))),
            "train_seconds": 0.0,
            "parameters": float(sum(value.numel() for value in payload["state_dict"].values())),
            "samples": int(payload.get("samples", 0)),
            "epochs": int(payload.get("epochs", 0)),
        }
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description="Run V2 stages concurrently as isolated CUDA processes.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--mode", choices=("quick", "full"), default="full")
    parser.add_argument("--stages", nargs="+", choices=STAGES, default=list(STAGES))
    parser.add_argument("--max-parallel", type=int, default=3)
    parser.add_argument("--seed-offset", type=int, default=0)
    parser.add_argument("--archive-results", action="store_true")
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required")

    root = args.root.resolve()
    if args.archive_results:
        _archive_results(root)
    else:
        (root / "results").mkdir(parents=True, exist_ok=True)
    log_dir = root / "logs_v2"
    log_dir.mkdir(parents=True, exist_ok=True)
    main_count, sensitivity_count = (3, 2) if args.mode == "quick" else (10, 5)
    main_seeds = list(range(args.seed_offset, args.seed_offset + main_count))
    sensitivity_seeds = list(range(args.seed_offset, args.seed_offset + sensitivity_count))

    pending = list(args.stages)
    active: Dict[str, Tuple[subprocess.Popen[str], object]] = {}
    timings: Dict[str, float] = {}
    started_unix = time.time()
    python = sys.executable
    stage_script = root / "run_stage_v2.py"

    while pending or active:
        while pending and len(active) < max(1, args.max_parallel):
            stage = pending.pop(0)
            seeds = sensitivity_seeds if stage == "sensitivity" else main_seeds
            log_handle = (log_dir / f"{args.mode}_{stage}.log").open("w", encoding="utf-8")
            command = [
                python,
                str(stage_script),
                "--root",
                str(root),
                "--stage",
                stage,
                "--seeds",
                *[str(seed) for seed in seeds],
            ]
            child_env = os.environ.copy()
            child_env.setdefault("OMP_NUM_THREADS", "1")
            child_env.setdefault("MKL_NUM_THREADS", "1")
            child_env.setdefault("OPENBLAS_NUM_THREADS", "1")
            process = subprocess.Popen(
                command,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                text=True,
                env=child_env,
            )
            active[stage] = (process, log_handle)
            print(f"[stage:start] {stage} pid={process.pid} seeds={seeds}", flush=True)

        finished: List[str] = []
        for stage, (process, log_handle) in active.items():
            code = process.poll()
            if code is None:
                continue
            log_handle.close()
            if code != 0:
                for other, (other_process, other_handle) in active.items():
                    if other != stage and other_process.poll() is None:
                        other_process.terminate()
                    if not other_handle.closed:
                        other_handle.close()
                raise RuntimeError(f"stage {stage} failed with exit code {code}; see logs_v2")
            timing_path = root / "results" / f"{stage}_timing.json"
            timing = json.loads(timing_path.read_text(encoding="utf-8"))
            timings[stage] = float(timing["seconds"])
            print(f"[stage:done] {stage} rows={timing['rows']} seconds={timing['seconds']:.2f}", flush=True)
            finished.append(stage)
        for stage in finished:
            active.pop(stage)
        if active and not finished:
            time.sleep(1.0)

    cfg = SimConfig()
    metadata = {
        "mode": args.mode,
        "stages": args.stages,
        "main_seeds": main_seeds,
        "sensitivity_seeds": sensitivity_seeds,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "training": _checkpoint_metadata(root),
        "config": cfg.__dict__,
        "started_unix": started_unix,
        "stage_seconds": timings,
        "finished_unix": time.time(),
        "parallel_workers": args.max_parallel,
    }
    (root / "results" / "run_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps({"status": "complete", "stage_seconds": timings}, indent=2), flush=True)


if __name__ == "__main__":
    main()
