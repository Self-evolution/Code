from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import torch

from campe.config import SimConfig
from campe.experiment import (
    run_adaptation,
    run_control_plane,
    run_domain_shift,
    run_robustness,
    run_safety_ablation,
    run_sensitivity,
)


RUNNERS = {
    "domain_shift": run_domain_shift,
    "adaptation": run_adaptation,
    "safety_ablation": run_safety_ablation,
    "control_plane": run_control_plane,
    "robustness": run_robustness,
    "sensitivity": run_sensitivity,
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one independent V2 experiment stage.")
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--stage", choices=RUNNERS, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", required=True)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required")
    torch.set_float32_matmul_precision("high")
    root = args.root.resolve()
    started = time.time()
    start = time.perf_counter()
    frame = RUNNERS[args.stage](root, SimConfig(), args.seeds)
    record = {
        "stage": args.stage,
        "seeds": args.seeds,
        "rows": int(len(frame)),
        "seconds": time.perf_counter() - start,
        "started_unix": started,
        "finished_unix": time.time(),
    }
    (root / "results" / f"{args.stage}_timing.json").write_text(
        json.dumps(record, indent=2), encoding="utf-8"
    )
    print(json.dumps(record, indent=2), flush=True)


if __name__ == "__main__":
    main()
