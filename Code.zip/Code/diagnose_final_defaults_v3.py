from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--raw", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    screening = root / "results" / "screening"
    raw = args.raw or (root / "results" / "safety_ablation_raw.csv")
    if not raw.exists():
        raw = sorted(screening.glob("final_defaults_*_safety_ablation_raw.csv"))[-1]
    frame = pd.read_csv(raw)
    frame = frame[
        frame.ablation.isin(("full", "no_kinematic_gate", "no_trust_region"))
    ].copy()
    safety_failure = (
        frame.outcome_escape_medium
        + frame.outcome_collision_medium
        + frame.outcome_border_medium
    )
    frame["benchmark_utility"] = (
        0.35 * frame.capture_success_medium
        + 0.25 * frame.formation_score
        + 0.20 * frame.final_performance
        + 0.10 * frame.target_inside_fraction
        + 0.10 * (1.0 - safety_failure)
    )
    metrics = [
        "benchmark_utility",
        "capture_success_medium",
        "formation_score",
        "final_performance",
        "target_inside_fraction",
        "policy_update_magnitude",
        "value_overestimation",
        "action_jump",
        "old_domain_forgetting",
        "collision_rate",
        "mean_kinematic_gate",
        "mean_maneuver_pressure",
    ]
    metrics = [metric for metric in metrics if metric in frame.columns]
    frame["architecture_score"] = (
        frame["benchmark_utility"]
        - 0.025 * frame["policy_update_magnitude"]
        - 0.20 * frame["old_domain_forgetting"]
        - 0.05 * frame["value_overestimation"]
        - frame["collision_rate"]
    )
    metrics.insert(1, "architecture_score")
    print("OVERALL")
    print(frame.groupby("ablation")[metrics].mean().to_string())
    print("\nBY SCENARIO")
    print(frame.groupby(["scenario", "ablation"])[metrics].mean().to_string())

    ood_path = screening / "ood_full10_crn_raw.csv"
    if ood_path.exists():
        ood = pd.read_csv(ood_path)
        method_column = "policy_variant" if "policy_variant" in ood.columns else "method"
        campe_label = "maneuver_update085" if method_column == "policy_variant" else "campe"
        ood = ood[ood[method_column] == campe_label]
        ood_metrics = [
            metric for metric in (
                "mean_kinematic_gate",
                "mean_maneuver_pressure",
                "mean_update_weight",
                "policy_update_magnitude",
                "benchmark_utility",
            ) if metric in ood.columns
        ]
        print("\nOOD CAMPE GATES")
        print(ood.groupby("scenario")[ood_metrics].mean().to_string())


if __name__ == "__main__":
    main()
