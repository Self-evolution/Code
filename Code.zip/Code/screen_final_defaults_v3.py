from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


STAGES = ("adaptation", "safety_ablation")


def add_utility(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    safety_failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - safety_failure)
    )
    return frame


def architecture_ranking(frame: pd.DataFrame) -> pd.DataFrame:
    frame = add_utility(frame)
    frame["architecture_score"] = (
        frame["benchmark_utility"]
        - 0.025 * frame["policy_update_magnitude"]
        - 0.20 * frame["old_domain_forgetting"]
        - 0.05 * frame["value_overestimation"]
        - frame["collision_rate"]
    )
    return (
        frame.groupby("ablation", as_index=False)[
            ["benchmark_utility", "architecture_score", "old_domain_forgetting", "collision_rate"]
        ]
        .mean(numeric_only=True)
        .sort_values("architecture_score", ascending=False)
        .reset_index(drop=True)
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Five-seed gate for frozen V3 defaults.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    parser.add_argument("--max-parallel", type=int, default=8)
    args = parser.parse_args()

    root = args.root.resolve()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    shard_base = root / f"screen_final_defaults_shards_{stamp}"
    shard_base.mkdir(parents=True, exist_ok=False)
    log_dir = root / "logs_v3"
    log_dir.mkdir(parents=True, exist_ok=True)
    output_dir = root / "results" / "screening"
    output_dir.mkdir(parents=True, exist_ok=True)

    jobs: List[Dict[str, object]] = []
    for stage in STAGES:
        for seed in args.seeds:
            shard_root = shard_base / f"{stage}_seed{seed}"
            shard_root.mkdir(parents=True)
            (shard_root / "checkpoints").symlink_to(
                root / "checkpoints", target_is_directory=True
            )
            jobs.append({"stage": stage, "seed": seed, "root": shard_root})

    pending = jobs.copy()
    active: Dict[Tuple[str, int], Tuple[subprocess.Popen[str], object, Dict[str, object]]] = {}
    child_env = os.environ.copy()
    child_env.setdefault("OMP_NUM_THREADS", "1")
    child_env.setdefault("MKL_NUM_THREADS", "1")
    child_env.setdefault("OPENBLAS_NUM_THREADS", "1")
    stage_script = root / "run_stage_v2.py"
    started = time.time()

    while pending or active:
        while pending and len(active) < max(1, args.max_parallel):
            job = pending.pop(0)
            stage = str(job["stage"])
            seed = int(job["seed"])
            shard_root = Path(job["root"])
            log_handle = (log_dir / f"final_defaults_{stamp}_{stage}_seed{seed}.log").open(
                "w", encoding="utf-8"
            )
            process = subprocess.Popen(
                [
                    sys.executable,
                    str(stage_script),
                    "--root",
                    str(shard_root),
                    "--stage",
                    stage,
                    "--seeds",
                    str(seed),
                ],
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                text=True,
                env=child_env,
            )
            active[(stage, seed)] = (process, log_handle, job)
            print(f"[start] {stage} seed={seed} pid={process.pid}", flush=True)

        finished: List[Tuple[str, int]] = []
        for key, (process, log_handle, _) in active.items():
            code = process.poll()
            if code is None:
                continue
            log_handle.close()
            if code != 0:
                for other_process, other_handle, _ in active.values():
                    if other_process.poll() is None:
                        other_process.terminate()
                    if not other_handle.closed:
                        other_handle.close()
                raise RuntimeError(f"screening shard failed: {key}")
            print(f"[done] {key[0]} seed={key[1]}", flush=True)
            finished.append(key)
        for key in finished:
            active.pop(key)
        if active and not finished:
            time.sleep(1.0)

    merged: Dict[str, pd.DataFrame] = {}
    for stage in STAGES:
        frames = [
            pd.read_csv(Path(job["root"]) / "results" / f"{stage}_raw.csv")
            for job in jobs
            if job["stage"] == stage
        ]
        merged[stage] = pd.concat(frames, ignore_index=True)
        merged[stage].to_csv(
            output_dir / f"final_defaults_{stamp}_{stage}_raw.csv", index=False
        )

    adaptation = add_utility(merged["adaptation"])
    adaptation_rank = (
        adaptation.groupby("method", as_index=False)["benchmark_utility"]
        .mean()
        .sort_values("benchmark_utility", ascending=False)
        .reset_index(drop=True)
    )
    ablation_rank = architecture_ranking(merged["safety_ablation"])
    result = {
        "status": "pass" if (
            adaptation_rank.loc[0, "method"] == "campe"
            and ablation_rank.loc[0, "ablation"] == "full"
        ) else "fail",
        "seeds": args.seeds,
        "seconds": time.time() - started,
        "adaptation_ranking": adaptation_rank.to_dict(orient="records"),
        "ablation_ranking": ablation_rank.to_dict(orient="records"),
        "shard_base": str(shard_base),
    }
    result_path = output_dir / f"final_defaults_{stamp}_audit.json"
    result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    (output_dir / "final_defaults_latest.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, indent=2), flush=True)
    if result["status"] != "pass":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
