from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import multiprocessing as mp
import os
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd
import torch

from campe.config import SimConfig
from campe.experiment import evaluate_retention, run_episode


VARIANTS = {
    "base": {},
    "m000": dict(safety_margin_fraction=0.00),
    "m015": dict(safety_margin_fraction=0.15),
    "m030": dict(safety_margin_fraction=0.30),
    "m045": dict(safety_margin_fraction=0.45),
    "m060": dict(safety_margin_fraction=0.60),
    "m075": dict(safety_margin_fraction=0.75),
    "t180": dict(action_trust_base=1.80),
    "t220": dict(action_trust_base=2.20),
    "t260": dict(action_trust_base=2.60),
    "t300": dict(action_trust_base=3.00),
    "m030_t180": dict(safety_margin_fraction=0.30, action_trust_base=1.80),
    "m030_t220": dict(safety_margin_fraction=0.30, action_trust_base=2.20),
    "m045_t180": dict(safety_margin_fraction=0.45, action_trust_base=1.80),
    "m045_t220": dict(safety_margin_fraction=0.45, action_trust_base=2.20),
    "m060_t180": dict(safety_margin_fraction=0.60, action_trust_base=1.80),
    "m060_t220": dict(safety_margin_fraction=0.60, action_trust_base=2.20),
    "m030_b080": dict(safety_margin_fraction=0.30, action_trust_base=0.80),
    "m030_b100": dict(safety_margin_fraction=0.30, action_trust_base=1.00),
    "m030_b120": dict(safety_margin_fraction=0.30, action_trust_base=1.20),
    "m030_r060": dict(safety_margin_fraction=0.30, action_trust_risk_gain=0.60),
    "m030_r090": dict(safety_margin_fraction=0.30, action_trust_risk_gain=0.90),
    "m030_a050": dict(safety_margin_fraction=0.30, adapter_trust_radius=0.050),
    "m030_a075": dict(safety_margin_fraction=0.30, adapter_trust_radius=0.075),
    "m030_a125": dict(safety_margin_fraction=0.30, adapter_trust_radius=0.125),
    "m030_a150": dict(safety_margin_fraction=0.30, adapter_trust_radius=0.150),
    "m030_a200": dict(safety_margin_fraction=0.30, adapter_trust_radius=0.200),
    "m030_b120_a075": dict(
        safety_margin_fraction=0.30, action_trust_base=1.20,
        adapter_trust_radius=0.075,
    ),
    "m030_r090_a075": dict(
        safety_margin_fraction=0.30, action_trust_risk_gain=0.90,
        adapter_trust_radius=0.075,
    ),
    "u030": dict(uncertainty_scale=0.03),
    "u060": dict(uncertainty_scale=0.06),
    "u090": dict(uncertainty_scale=0.09),
    "u120_d012": dict(uncertainty_scale=0.12, uncertainty_deadzone=0.12),
    "u120_d015": dict(uncertainty_scale=0.12, uncertainty_deadzone=0.15),
    "u060_d012": dict(uncertainty_scale=0.06, uncertainty_deadzone=0.12),
    "u060_d015": dict(uncertainty_scale=0.06, uncertainty_deadzone=0.15),
    "u010_d000": dict(uncertainty_scale=0.01, uncertainty_deadzone=0.00),
    "u030_d000": dict(uncertainty_scale=0.03, uncertainty_deadzone=0.00),
    "u060_d000": dict(uncertainty_scale=0.06, uncertainty_deadzone=0.00),
    "u090_d000": dict(uncertainty_scale=0.09, uncertainty_deadzone=0.00),
    "u120_d000": dict(uncertainty_scale=0.12, uncertainty_deadzone=0.00),
    "u060_d025": dict(uncertainty_scale=0.06, uncertainty_deadzone=0.025),
    "u120_d025": dict(uncertainty_scale=0.12, uncertainty_deadzone=0.025),
    "u120_d050": dict(uncertainty_scale=0.12, uncertainty_deadzone=0.050),
}


def stress_config(base: SimConfig) -> SimConfig:
    return replace(
        base,
        n_auv=6,
        desired_radius=10.5,
        radial_tolerance=2.8,
        capture_gap_multiplier=1.28,
        capture_hold=24,
        capture_required_fraction=0.78,
        initial_angle_jitter=0.78,
        initial_radius_offset=8.0,
        initial_radius_std=6.0,
        safety_distance=9.0,
        collision_distance=6.0,
    )


def _reference(task: Tuple[str, SimConfig, int]) -> Tuple[int, float]:
    root_text, cfg, seed = task
    torch.set_num_threads(1)
    row, _ = run_episode(
        Path(root_text), cfg, "source_only", "source", seed + 40_000,
        planner="full_mpc",
    )
    return seed, float(row["final_performance"])


def _worker(task: Tuple[str, str, SimConfig, str, int, float]) -> Dict[str, object]:
    root_text, variant, cfg, scenario, seed, reference = task
    torch.set_num_threads(1)
    root = Path(root_text)
    row, controller = run_episode(
        root, cfg, "campe", scenario, seed,
        planner="full_mpc", ablation="full", retain_controller=True,
    )
    assert controller is not None
    row.update(evaluate_retention(root, cfg, controller, seed, "td3", reference))
    row["calibration_variant"] = variant
    return row


def _collect(pool: ProcessPoolExecutor, tasks: List[Tuple], worker) -> List:
    futures = [pool.submit(worker, task) for task in tasks]
    rows = []
    for index, future in enumerate(as_completed(futures), start=1):
        rows.append(future.result())
        if index % max(1, len(futures) // 10) == 0 or index == len(futures):
            print(f"[policy-screen] {index}/{len(futures)}", flush=True)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Calibrate full-model margin and action trust region.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--tag", default="policy_calibration")
    parser.add_argument("--variants", nargs="+", choices=tuple(VARIANTS))
    args = parser.parse_args()

    root = args.root.resolve()
    base_stress = stress_config(SimConfig())
    selected = args.variants or list(VARIANTS)
    context = mp.get_context("spawn")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=context) as pool:
        references = dict(_collect(
            pool,
            [(str(root), base_stress, seed) for seed in args.seeds],
            _reference,
        ))
        tasks = []
        for variant in selected:
            cfg = replace(base_stress, **VARIANTS[variant])
            for scenario in ("adversarial_mix", "blackout_chase", "recurrent_shift"):
                for seed in args.seeds:
                    tasks.append((str(root), variant, cfg, scenario, seed, references[seed]))
        rows = _collect(pool, tasks, _worker)

    frame = pd.DataFrame(rows)
    failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - failure)
    )
    frame["architecture_score"] = (
        frame["benchmark_utility"]
        - 0.025 * frame["policy_update_magnitude"]
        - 0.20 * frame["old_domain_forgetting"]
        - 0.05 * frame["value_overestimation"]
        - frame["collision_rate"]
    )
    output = root / "results" / "screening"
    output.mkdir(parents=True, exist_ok=True)
    raw = output / f"{args.tag}_raw.csv"
    summary = output / f"{args.tag}_summary.csv"
    frame.to_csv(raw, index=False)
    columns = [
        "benchmark_utility", "architecture_score", "capture_success_medium",
        "formation_score", "final_performance", "policy_update_magnitude",
        "old_domain_forgetting", "value_overestimation", "collision_rate",
    ]
    ranking = frame.groupby("calibration_variant")[columns].mean().sort_values(
        "architecture_score", ascending=False
    )
    ranking.to_csv(summary)
    print(ranking.round(6).to_string(), flush=True)
    print(f"raw={raw}\nsummary={summary}", flush=True)


if __name__ == "__main__":
    main()
