from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Iterable, List

import numpy as np
import pandas as pd


OUTCOMES = ("success", "escape", "collision", "border", "timeout")


def _add_utilities(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    required = {
        "capture_success_medium",
        "formation_score",
        "final_performance",
        "target_inside_fraction",
        "outcome_escape_medium",
        "outcome_collision_medium",
        "outcome_border_medium",
    }
    if required.issubset(frame.columns):
        safety_failure = (
            frame["outcome_escape_medium"]
            + frame["outcome_collision_medium"]
            + frame["outcome_border_medium"]
        )
        frame["benchmark_utility"] = (
            0.35 * frame["capture_success_medium"]
            + 0.25 * frame["formation_score"]
            + 0.20 * frame["final_performance"]
            + 0.10 * frame["target_inside_fraction"]
            + 0.10 * (1.0 - safety_failure)
        )
    if {"benchmark_utility", "aoi", "per"}.issubset(frame.columns):
        frame["control_plane_utility"] = (
            0.50 * frame["benchmark_utility"]
            + 0.35 * np.exp(-frame["aoi"] / 1.5)
            + 0.15 * (1.0 - frame["per"])
        )
    return frame


def _paired_seed_summary(
    frame: pd.DataFrame,
    key: str,
    left: str,
    right: str,
    metric: str,
) -> Dict[str, object]:
    aggregate = frame.groupby([key, "seed"], dropna=False)[metric].mean().unstack(key)
    aggregate = aggregate.dropna(subset=[left, right])
    delta = aggregate[left] - aggregate[right]
    ci = float(1.96 * delta.std(ddof=1) / np.sqrt(len(delta))) if len(delta) > 1 else 0.0
    pair = frame.pivot_table(index=["scenario", "seed"], columns=key, values=metric)
    pair = pair.dropna(subset=[left, right])
    return {
        "left": left,
        "right": right,
        "metric": metric,
        "mean_delta": float(delta.mean()),
        "ci95": ci,
        "ci_lower": float(delta.mean() - ci),
        "ci_upper": float(delta.mean() + ci),
        "seed_wins": int((delta > 0.0).sum()),
        "seed_ties": int(np.isclose(delta, 0.0).sum()),
        "n_seeds": int(len(delta)),
        "episode_wins": int((pair[left] > pair[right]).sum()),
        "n_episode_pairs": int(len(pair)),
        "seed_deltas": {str(seed): float(value) for seed, value in delta.items()},
    }


def _records(frame: pd.DataFrame, groups: Iterable[str], metrics: Iterable[str]) -> List[Dict[str, object]]:
    columns = [column for column in metrics if column in frame.columns]
    grouped = frame.groupby(list(groups), dropna=False)[columns].mean(numeric_only=True).reset_index()
    return json.loads(grouped.to_json(orient="records", double_precision=6))


def _outcome_errors(frame: pd.DataFrame) -> int:
    errors = 0
    for profile in ("loose", "medium", "strict"):
        columns = [f"outcome_{label}_{profile}" for label in OUTCOMES]
        if all(column in frame for column in columns):
            sums = frame[columns].sum(axis=1).to_numpy(dtype=float)
            errors += int(np.count_nonzero(~np.isclose(sums, 1.0)))
    return errors


def summarize(root: Path) -> Dict[str, object]:
    result_dir = root / "results"
    data = {
        path.stem.removesuffix("_raw"): _add_utilities(pd.read_csv(path))
        for path in sorted(result_dir.glob("*_raw.csv"))
    }
    report: Dict[str, object] = {
        "available_stages": sorted(data),
        "rows": {name: int(len(frame)) for name, frame in data.items()},
        "protocol_outcome_errors": int(sum(_outcome_errors(frame) for frame in data.values())),
    }
    common = [
        "capture_success_loose",
        "capture_success_medium",
        "capture_success_strict",
        "outcome_success_medium",
        "outcome_escape_medium",
        "outcome_collision_medium",
        "outcome_border_medium",
        "outcome_timeout_medium",
        "formation_score",
        "final_performance",
        "radius_error",
        "max_angle_gap",
        "target_inside_fraction",
        "aoi",
        "per",
        "collision_rate",
        "border_rate",
        "benchmark_utility",
    ]
    if "domain_shift" in data:
        report["domain_shift"] = _records(data["domain_shift"], ["scenario"], common)
    if "adaptation" in data:
        report["adaptation_overall"] = _records(data["adaptation"], ["method"], common)
        report["adaptation_by_scenario"] = _records(data["adaptation"], ["scenario", "method"], common)
    if "robustness" in data:
        report["robustness_overall"] = _records(data["robustness"], ["method"], common)
        report["robustness_by_scenario"] = _records(data["robustness"], ["scenario", "method"], common)
    if "control_plane" in data:
        report["control_plane"] = _records(
            data["control_plane"], ["planner"],
            common + ["control_plane_utility", "usv_distance", "control_bytes", "learning_bytes", "fim", "follower_prediction_error", "full_mpc_priority_extras"],
        )
    if "safety_ablation" in data:
        report["safety_ablation"] = _records(
            data["safety_ablation"], ["ablation"],
            common + ["action_jump", "value_overestimation", "old_domain_forgetting", "policy_update_magnitude"],
        )
    if "sensitivity" in data:
        report["sensitivity"] = _records(
            data["sensitivity"], ["sensitivity_parameter", "sensitivity_value"],
            common + ["usv_distance", "control_bytes", "learning_bytes", "old_domain_forgetting"],
        )
    paired: Dict[str, object] = {}
    if "robustness" in data:
        paired["ood_campe_vs_ctta"] = _paired_seed_summary(
            data["robustness"], "method", "campe", "ctta", "benchmark_utility"
        )
        scenario = data["robustness"].pivot_table(
            index="scenario", columns="method", values="benchmark_utility", aggfunc="mean"
        ).dropna(subset=["campe", "ctta"])
        paired["ood_campe_vs_ctta"]["scenario_deltas"] = {
            str(index): float(row["campe"] - row["ctta"])
            for index, row in scenario.iterrows()
        }
    if "control_plane" in data:
        paired["full_mpc_vs_fim_control"] = _paired_seed_summary(
            data["control_plane"], "planner", "full_mpc", "fim", "control_plane_utility"
        )
        paired["full_mpc_vs_fim_mission"] = _paired_seed_summary(
            data["control_plane"], "planner", "full_mpc", "fim", "benchmark_utility"
        )
        aoi = data["control_plane"].pivot_table(
            index=["scenario", "seed"], columns="planner", values="aoi"
        ).dropna(subset=["full_mpc", "fim"])
        paired["full_mpc_vs_fim_control"]["aoi_lower_pairs"] = int(
            (aoi["full_mpc"] < aoi["fim"]).sum()
        )
        paired["full_mpc_vs_fim_control"]["n_aoi_pairs"] = int(len(aoi))
    report["paired_comparisons"] = paired
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = summarize(args.root.resolve())
    payload = json.dumps(report, indent=2, ensure_ascii=False)
    if args.output:
        args.output.write_text(payload, encoding="utf-8")
    print(payload)


if __name__ == "__main__":
    main()
