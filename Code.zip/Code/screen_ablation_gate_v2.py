from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import multiprocessing as mp
import os
from pathlib import Path
from typing import Dict, Iterable, Tuple

import pandas as pd
import torch

from campe.config import ABLATIONS, SimConfig
from campe.experiment import evaluate_retention, run_episode


def stress_config() -> SimConfig:
    cfg = SimConfig()
    return replace(
        cfg,
        n_auv=6,
        desired_radius=10.5,
        radial_tolerance=2.8,
        capture_gap_multiplier=1.28,
        capture_hold=24,
        capture_required_fraction=0.78,
        initial_angle_jitter=0.78,
        initial_radius_offset=8.0,
        initial_radius_std=6.0,
        safety_distance=9.0,
        collision_distance=6.0,
    )


def reference_worker(task: Tuple[str, SimConfig, int]) -> Tuple[int, float]:
    root_text, cfg, seed = task
    torch.set_num_threads(1)
    row, _ = run_episode(
        Path(root_text), cfg, "source_only", "source", seed + 40_000,
        planner="full_mpc",
    )
    return seed, float(row["final_performance"])


def ablation_worker(
    task: Tuple[str, SimConfig, str, str, int, float]
) -> Dict[str, object]:
    root_text, cfg, ablation, scenario, seed, reference = task
    torch.set_num_threads(1)
    root = Path(root_text)
    row, controller = run_episode(
        root,
        cfg,
        "campe",
        scenario,
        seed,
        planner="full_mpc",
        ablation=ablation,
        retain_controller=True,
    )
    assert controller is not None
    row.update(evaluate_retention(root, cfg, controller, seed, "td3", reference))
    return row


def collect(pool: ProcessPoolExecutor, tasks: Iterable[Tuple], worker) -> list:
    futures = [pool.submit(worker, task) for task in tasks]
    rows = []
    for index, future in enumerate(as_completed(futures), start=1):
        rows.append(future.result())
        if index % max(1, len(futures) // 10) == 0 or index == len(futures):
            print(f"[gate-screen] {index}/{len(futures)}", flush=True)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument(
        "--ablations",
        nargs="+",
        choices=ABLATIONS,
        default=list(ABLATIONS),
        help="Subset used for targeted architecture-gate screening.",
    )
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--tag", default="ablation_gate")
    args = parser.parse_args()

    root = args.root.resolve()
    cfg = stress_config()
    context = mp.get_context("spawn")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=context) as pool:
        references = dict(collect(
            pool,
            [(str(root), cfg, seed) for seed in args.seeds],
            reference_worker,
        ))
        tasks = [
            (str(root), cfg, ablation, scenario, seed, references[seed])
            for ablation in args.ablations
            for scenario in ("adversarial_mix", "blackout_chase", "recurrent_shift")
            for seed in args.seeds
        ]
        rows = collect(pool, tasks, ablation_worker)

    frame = pd.DataFrame(rows)
    failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - failure)
    )
    frame["architecture_score"] = (
        frame["benchmark_utility"]
        - 0.025 * frame["policy_update_magnitude"]
        - 0.20 * frame["old_domain_forgetting"]
        - 0.05 * frame["value_overestimation"]
        - frame["collision_rate"]
    )
    output_dir = root / "results" / "screening"
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{args.tag}_raw.csv"
    frame.to_csv(output, index=False)
    columns = [
        "capture_success_medium",
        "formation_score",
        "final_performance",
        "policy_update_magnitude",
        "old_domain_forgetting",
        "value_overestimation",
        "benchmark_utility",
        "architecture_score",
    ]
    ranking = (
        frame.groupby("ablation")[columns]
        .mean()
        .sort_values("architecture_score", ascending=False)
    )
    print(ranking.round(5).to_string())
    print(f"raw={output}")


if __name__ == "__main__":
    main()
