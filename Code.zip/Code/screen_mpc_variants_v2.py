from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import multiprocessing as mp
import os
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd
import torch

from campe.config import SimConfig
from campe.experiment import run_episode


VARIANTS = {
    "fim": None,
    "exact_fim": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_terminal_link_streak=0,
    ),
    "residual_only": dict(mpc_terminal_link_streak=0),
    "final": {},
    "residual_005": dict(mpc_residual_gain=0.05),
    "residual_020": dict(mpc_residual_gain=0.20),
    "no_fim_guard": dict(mpc_terminal_fim_tolerance=3.0),
    "lookahead_030": dict(
        mpc_min_confidence=0.38,
        mpc_gain_margin=0.06,
        mpc_residual_gain=0.12,
        mpc_residual_gain_max=0.30,
        mpc_reactive_weight=0.46,
        mpc_rollout_weight=0.32,
        mpc_mean_link_weight=0.12,
        mpc_worst_link_weight=0.18,
        mpc_fim_floor_tolerance=0.80,
        mpc_terminal_link_streak=4,
        mpc_terminal_link_gain=0.30,
        mpc_terminal_min_link_gain=0.025,
    ),
    "lookahead_045": dict(
        mpc_min_confidence=0.36,
        mpc_gain_margin=0.05,
        mpc_residual_gain=0.15,
        mpc_residual_gain_max=0.45,
        mpc_reactive_weight=0.42,
        mpc_rollout_weight=0.38,
        mpc_mean_link_weight=0.14,
        mpc_worst_link_weight=0.22,
        mpc_fim_floor_tolerance=0.70,
        mpc_terminal_link_streak=4,
        mpc_terminal_link_gain=0.35,
        mpc_terminal_min_link_gain=0.025,
    ),
    "lookahead_060": dict(
        mpc_min_confidence=0.34,
        mpc_gain_margin=0.04,
        mpc_residual_gain=0.18,
        mpc_residual_gain_max=0.60,
        mpc_reactive_weight=0.38,
        mpc_rollout_weight=0.44,
        mpc_mean_link_weight=0.16,
        mpc_worst_link_weight=0.26,
        mpc_fim_floor_tolerance=0.65,
        mpc_terminal_link_streak=4,
        mpc_terminal_link_gain=0.40,
        mpc_terminal_min_link_gain=0.025,
    ),
    "lookahead_045_no_terminal": dict(
        mpc_min_confidence=0.36,
        mpc_gain_margin=0.05,
        mpc_residual_gain=0.15,
        mpc_residual_gain_max=0.45,
        mpc_reactive_weight=0.42,
        mpc_rollout_weight=0.38,
        mpc_mean_link_weight=0.14,
        mpc_worst_link_weight=0.22,
        mpc_fim_floor_tolerance=0.70,
        mpc_terminal_link_streak=0,
    ),
    "lookahead_045_paced": dict(
        mpc_min_confidence=0.36,
        mpc_gain_margin=0.05,
        mpc_residual_gain=0.15,
        mpc_residual_gain_max=0.45,
        mpc_reactive_weight=0.42,
        mpc_rollout_weight=0.38,
        mpc_mean_link_weight=0.14,
        mpc_worst_link_weight=0.22,
        mpc_fim_floor_tolerance=0.70,
        mpc_budget_pacing=True,
        mpc_terminal_link_streak=4,
        mpc_terminal_link_gain=0.35,
        mpc_terminal_min_link_gain=0.025,
    ),
    "lookahead_080": dict(
        mpc_min_confidence=0.28,
        mpc_gain_margin=0.01,
        mpc_residual_gain=0.35,
        mpc_residual_gain_max=0.80,
        mpc_reactive_weight=0.28,
        mpc_rollout_weight=0.48,
        mpc_mean_link_weight=0.22,
        mpc_worst_link_weight=0.38,
        mpc_fim_floor_tolerance=0.55,
        mpc_terminal_link_streak=0,
    ),
    "link_dominant": dict(
        mpc_min_confidence=0.24,
        mpc_gain_margin=0.00,
        mpc_residual_gain=0.45,
        mpc_residual_gain_max=1.00,
        mpc_reactive_weight=0.20,
        mpc_rollout_weight=0.42,
        mpc_mean_link_weight=0.30,
        mpc_worst_link_weight=0.52,
        mpc_fim_floor_tolerance=0.45,
        mpc_terminal_link_streak=0,
    ),
    "rollout_dominant": dict(
        mpc_min_confidence=0.24,
        mpc_gain_margin=0.00,
        mpc_residual_gain=0.45,
        mpc_residual_gain_max=1.00,
        mpc_reactive_weight=0.18,
        mpc_rollout_weight=0.66,
        mpc_mean_link_weight=0.18,
        mpc_worst_link_weight=0.28,
        mpc_fim_floor_tolerance=0.45,
        mpc_terminal_link_streak=0,
    ),
    "dual_control_mpc": dict(
        mpc_min_confidence=0.24,
        mpc_gain_margin=0.00,
        mpc_residual_gain=0.40,
        mpc_residual_gain_max=0.90,
        mpc_reactive_weight=0.22,
        mpc_rollout_weight=0.56,
        mpc_mean_link_weight=0.22,
        mpc_worst_link_weight=0.36,
        mpc_fim_floor_tolerance=0.50,
        mpc_dynamic_bandwidth=True,
        mpc_terminal_link_streak=0,
    ),
    "dual_path_mpc": dict(
        mpc_min_confidence=0.24,
        mpc_gain_margin=0.00,
        mpc_residual_gain=0.40,
        mpc_residual_gain_max=0.90,
        mpc_reactive_weight=0.22,
        mpc_rollout_weight=0.56,
        mpc_mean_link_weight=0.22,
        mpc_worst_link_weight=0.36,
        mpc_fim_floor_tolerance=0.50,
        mpc_dynamic_bandwidth=False,
        mpc_terminal_link_streak=0,
    ),
    "dual_path_priority": dict(
        mpc_min_confidence=0.24,
        mpc_gain_margin=0.00,
        mpc_residual_gain=0.40,
        mpc_residual_gain_max=0.90,
        mpc_reactive_weight=0.22,
        mpc_rollout_weight=0.56,
        mpc_mean_link_weight=0.22,
        mpc_worst_link_weight=0.36,
        mpc_fim_floor_tolerance=0.50,
        mpc_dynamic_bandwidth=False,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp8": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.92,
        mpc_control_ratio_max=0.96,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7_geom25": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.25,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7_geom50": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.50,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7_period": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_dynamic_period=True,
        mpc_period_risk_gain=2.0,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_fixed7": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.90,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7_robust": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_robust_information_filter=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7_geom25_robust": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.25,
        mpc_robust_information_filter=True,
        mpc_terminal_link_streak=0,
    ),
    "fim_path_priority_wcp7_geom50_period": dict(
        mpc_min_confidence=1.10,
        mpc_residual_gain=0.0,
        mpc_residual_gain_max=0.0,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.50,
        mpc_dynamic_period=True,
        mpc_period_risk_gain=2.0,
        mpc_terminal_link_streak=0,
    ),
    "wcp7_geom50_residual_std": dict(
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.50,
        mpc_terminal_link_streak=0,
    ),
    "wcp7_geom50_residual_strict": dict(
        mpc_min_confidence=0.48,
        mpc_gain_margin=0.10,
        mpc_residual_gain=0.04,
        mpc_residual_gain_max=0.12,
        mpc_fim_floor_tolerance=0.15,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.50,
        mpc_terminal_link_streak=0,
    ),
    "wcp7_geom25_robust_residual_strict": dict(
        mpc_min_confidence=0.48,
        mpc_gain_margin=0.10,
        mpc_residual_gain=0.04,
        mpc_residual_gain_max=0.12,
        mpc_fim_floor_tolerance=0.15,
        mpc_dynamic_bandwidth=True,
        mpc_control_ratio_min=0.80,
        mpc_control_ratio_max=0.94,
        mpc_priority_retransmission=True,
        mpc_geometry_priority_weight=0.25,
        mpc_robust_information_filter=True,
        mpc_terminal_link_streak=0,
    ),
    "lookahead_030_priority": dict(
        mpc_min_confidence=0.38,
        mpc_gain_margin=0.06,
        mpc_residual_gain=0.12,
        mpc_residual_gain_max=0.30,
        mpc_reactive_weight=0.46,
        mpc_rollout_weight=0.32,
        mpc_mean_link_weight=0.12,
        mpc_worst_link_weight=0.18,
        mpc_fim_floor_tolerance=0.80,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
    "lookahead_030_selective": dict(
        mpc_min_confidence=0.38,
        mpc_gain_margin=0.06,
        mpc_residual_gain=0.12,
        mpc_residual_gain_max=0.30,
        mpc_reactive_weight=0.46,
        mpc_rollout_weight=0.32,
        mpc_mean_link_weight=0.12,
        mpc_worst_link_weight=0.18,
        mpc_fim_floor_tolerance=0.80,
        mpc_priority_retransmission=True,
        mpc_priority_per_threshold=0.30,
        mpc_priority_aoi_threshold=0.85,
        mpc_terminal_link_streak=0,
    ),
    "lookahead_060_priority": dict(
        mpc_min_confidence=0.34,
        mpc_gain_margin=0.04,
        mpc_residual_gain=0.18,
        mpc_residual_gain_max=0.60,
        mpc_reactive_weight=0.38,
        mpc_rollout_weight=0.44,
        mpc_mean_link_weight=0.16,
        mpc_worst_link_weight=0.26,
        mpc_fim_floor_tolerance=0.65,
        mpc_priority_retransmission=True,
        mpc_terminal_link_streak=0,
    ),
}


Task = Tuple[str, str, SimConfig, str, int, str]


def _worker(task: Task) -> Dict[str, object]:
    root_text, variant, cfg, scenario, seed, planner = task
    torch.set_num_threads(1)
    row, _ = run_episode(
        Path(root_text), cfg, "campe", scenario, seed,
        planner=planner, ablation="full",
    )
    row["mpc_variant"] = variant
    return row


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Screen the final safeguarded residual-MPC architecture."
    )
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seeds", type=int, nargs="+", default=list(range(10)))
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--tag", default="mpc_final_variants")
    parser.add_argument("--variants", nargs="+", choices=tuple(VARIANTS))
    parser.add_argument(
        "--scenarios", nargs="+",
        default=["mobile_shadow", "adversarial_mix"],
    )
    args = parser.parse_args()

    root = args.root.resolve()
    base = SimConfig()
    tasks: List[Task] = []
    selected_variants = args.variants or list(VARIANTS)
    for variant in selected_variants:
        overrides = VARIANTS[variant]
        cfg = base if overrides is None else replace(base, **overrides)
        planner = "fim" if variant == "fim" else "full_mpc"
        for scenario in args.scenarios:
            for seed in args.seeds:
                tasks.append((str(root), variant, cfg, scenario, seed, planner))

    rows: List[Dict[str, object]] = []
    context = mp.get_context("spawn")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=context) as pool:
        futures = [pool.submit(_worker, task) for task in tasks]
        for index, future in enumerate(as_completed(futures), start=1):
            rows.append(future.result())
            if index % max(1, len(tasks) // 10) == 0 or index == len(tasks):
                print(f"[mpc-screen] {index}/{len(tasks)}", flush=True)

    frame = pd.DataFrame(rows)
    safety_failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["benchmark_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - safety_failure)
    )
    output = root / "results" / "screening"
    output.mkdir(parents=True, exist_ok=True)
    raw_path = output / f"{args.tag}_raw.csv"
    summary_path = output / f"{args.tag}_summary.csv"
    frame.to_csv(raw_path, index=False)
    metrics = [
        "benchmark_utility", "capture_success_medium", "formation_score",
        "final_performance", "aoi", "per", "usv_distance",
        "full_mpc_fallback_rate", "full_mpc_residual_rate",
        "full_mpc_terminal_link_rate", "usv_period_mean",
        "full_mpc_priority_extras",
    ]
    summary = frame.groupby("mpc_variant")[metrics].mean().sort_values(
        "benchmark_utility", ascending=False
    )
    summary.to_csv(summary_path)
    print(summary.round(6).to_string(), flush=True)
    print(f"raw={raw_path}\nsummary={summary_path}", flush=True)


if __name__ == "__main__":
    main()
