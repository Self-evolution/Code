from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def add_utilities(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    safety_failure = (
        frame["outcome_escape_medium"]
        + frame["outcome_collision_medium"]
        + frame["outcome_border_medium"]
    )
    frame["mission_utility"] = (
        0.35 * frame["capture_success_medium"]
        + 0.25 * frame["formation_score"]
        + 0.20 * frame["final_performance"]
        + 0.10 * frame["target_inside_fraction"]
        + 0.10 * (1.0 - safety_failure)
    )
    frame["control_utility"] = (
        0.50 * frame["mission_utility"]
        + 0.35 * np.exp(-frame["aoi"] / 1.5)
        + 0.15 * (1.0 - frame["per"])
    )
    return frame


def paired_summary(
    frame: pd.DataFrame,
    variant: str,
    baseline: str,
    metric: str,
) -> dict[str, float | int]:
    paired = frame.pivot_table(
        index=["scenario", "seed"], columns="mpc_variant", values=metric
    ).dropna(subset=[variant, baseline])
    episode_delta = paired[variant] - paired[baseline]
    seed_delta = episode_delta.groupby(level="seed").mean()
    ci95 = (
        1.96 * float(seed_delta.std(ddof=1)) / np.sqrt(len(seed_delta))
        if len(seed_delta) > 1
        else 0.0
    )
    return {
        "mean_delta": float(seed_delta.mean()),
        "ci95": float(ci95),
        "ci_lower": float(seed_delta.mean() - ci95),
        "seed_wins": int((seed_delta > 0.0).sum()),
        "episode_wins": int((episode_delta > 0.0).sum()),
        "n_seeds": int(len(seed_delta)),
        "n_episodes": int(len(episode_delta)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", type=Path)
    parser.add_argument("--baseline", default="fim")
    args = parser.parse_args()

    frame = add_utilities(pd.read_csv(args.csv))
    variants = [
        value for value in sorted(frame["mpc_variant"].unique())
        if value != args.baseline
    ]
    metrics = [
        "mission_utility",
        "control_utility",
        "capture_success_medium",
        "formation_score",
        "final_performance",
        "target_inside_fraction",
        "aoi",
        "per",
        "outcome_escape_medium",
        "outcome_collision_medium",
        "outcome_border_medium",
        "full_mpc_fallback_rate",
        "full_mpc_residual_rate",
        "full_mpc_priority_extras",
    ]
    overall = frame.groupby("mpc_variant")[metrics].mean(numeric_only=True)
    print("OVERALL")
    print(overall.round(6).to_string())
    print("\nBY SCENARIO")
    print(
        frame.groupby(["scenario", "mpc_variant"])[metrics]
        .mean(numeric_only=True)
        .round(6)
        .to_string()
    )

    for variant in variants:
        print(f"\nPAIRED {variant} - {args.baseline}")
        for metric in ("control_utility", "mission_utility"):
            print(metric, paired_summary(frame, variant, args.baseline, metric))
        scenario = frame.pivot_table(
            index="scenario",
            columns="mpc_variant",
            values=["control_utility", "mission_utility"],
        )
        rows = []
        for scenario_name in sorted(frame["scenario"].unique()):
            row = {"scenario": scenario_name}
            for metric in ("control_utility", "mission_utility"):
                row[f"delta_{metric}"] = float(
                    scenario.loc[scenario_name, (metric, variant)]
                    - scenario.loc[scenario_name, (metric, args.baseline)]
                )
            rows.append(row)
        print(pd.DataFrame(rows).set_index("scenario").round(6).to_string())


if __name__ == "__main__":
    main()
